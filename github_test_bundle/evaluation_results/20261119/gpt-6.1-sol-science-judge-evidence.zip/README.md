# GPT 6.1 Sol 自动 Judge

用户已明确要求对完成的 GPT 6.1 Sol 全量轨迹启动 judge，并限制内存。裁判采用已空闲的 `gpt-6.1-sol-science`；这是同模型自动语义评审，输出标记 provisional/self_evaluation，不声明已完成独立裁判校准或人工确认。

615 个配置按冻结 job 清单分成四条互不重叠的 lane（160/150/160/145）。四条原 lane 保持运行；新增辅助调度器从已准备批次的尾部提前审核未处理案例，写回对应原 lane 的审核目录。初期辅助最多两路；用户再次要求加速后，现辅助最多四路，总并发上限八路，均按内存余量准入。裁判调用使用 GPT 模型额度，Opus 行为评测继续运行。

## 内存与恢复

- 每个本地进程使用 RLIMIT_AS=512 MiB；judge scope 另配置 MemoryMax=1024M，但本容器没有可确认的 cgroup 内存计数，按进程地址空间限额和实测 RSS 报告。
- 图片重建、CPU 回放准备和官方汇总共用文件锁，重操作最多一路；达到约 1400 MiB 的全评测 RSS 准入水位会等待，不暂停 Opus。
- 新增调用共享逐案例进程锁，原 lane 后续直接复用已验证的判断，避免重复付费或覆盖结果。未来原 lane 和辅助 judge_case 进程在 Python 启动时进入 FIFO 内存预约队列；预计全评测 RSS 加未兑现预约不超过 1344 MiB 才准入，辅助调度器还使用 1120 MiB 的 RSS 准入水位。这是保守调度估计，不是已验证的全进程硬内存上限。图片案例的预约更高，必要时等待已有请求完成再准入。
- 本 venv 会执行启动 .pth 两次；启动锁及预约现为幂等，每个进程只登记一次。更新只影响启动锁与内存准入，原裁判、提示、证据、16384 输出预算保持原值。
- 普通 judge 实测 RSS 约 38–50 MiB；真实长图/SVG 历史传输重建压力测试峰值 357.8 MiB，在 512 MiB 限制下通过。
- 每题单独原子保存判断、原始可见响应、用量、API请求SHA及状态。网络错误会退避重试；结构/证据错误最多三轮重新审查。新的恢复调用保留旧原始记录，已验证判断续跑时直接复用。
- API key 只在继承的环境和内存中，不写入配置、命令行或产物。

## 评分口径与证据

原 `evaluate --prepare` 入口执行冻结回放并生成审核包；API 裁判阅读实际全部动作、观察、文本、最终状态、真实世界事实及冻结 rubric，不提供模型旧分数或指定参考轨迹。

审核包重复结构用无损 RFC6901 引用表示，每份提交包先解码并比较原完整 JSON。首例从 1,288,195 字符降到约 228,024 字符，所有证据和调用仍保留。图片按真实输入引用及传输 ledger 重建原实际 PNG，包括 v2/v3 默认 PNG 编码和 v4+ 优化编码，逐图核对实际发送 SHA；不偷偷换成更高分辨率。

每条 API 判断须通过原 scoring_v2 计算和额外证据校验：case/轨迹/输入 SHA 绑定、全部目标和关键条目覆盖、六维整数分、实际证据 RFC6901 路径、可选精确引用、限时分类及全部窗口、整数虚拟截止时间与实际完成时间。完成与按时分别判断，迟到完成保留 GCR 完成分，由原评分器判 LCR/严格 TSR 失败。

每批完成后使用原 `redact_bench.py evaluate --partial` 官方入口再次验证并汇总；总报告从所有逐题 rows 汇总，不能平均四个 lane 的平均值。A/B 使用冻结配对清单的 `configuration` 字段，支持 `/B/A` 及 `/contrast/A` 等不同路径，不依赖后缀猜测。CQ 在本包未提供可校准锚点，保留 not_scorable/null，不创造新总分。

有证据/场景歧义的项目列在 needs_primary_review；缺失或无效审核不补零。进度以 status.json 的 completed_cases 为准，总质量分覆盖范围以 summary.json 的 officially_aggregated_shards/overall.scored_episodes 为准，批次仍在审核时二者可能不同。

## 文件

- status.json：全量进度、每条 lane、内存与失败/需复核项。
- parallel-status.json、parallel-binding.json：辅助任务进度、源码快照绑定及六/八路准入设置。
- summary.json：官方 v2 的 GCR/TSR/LCR/六维/CQ/Efficiency 和 A/B/无配对主情境覆盖。
- lanes/<lane>/reviews/<shard>/judgments：逐题判断及证据。
- lanes/<lane>/reviews/<shard>/raw-responses：原始可见 API 结果、用量和校验/网络错误。
- lanes/<lane>/reviews/<shard>/metrics-v2.json、per-episode-v2.csv：官方逐批评分。
- judge-binding.json、lane judge-binding.json、source-snapshots：裁判、输出预算、评分/源码 SHA 和版本。

运行 scope：redactbench-gpt-judge-20261120.scope 承载四条原 API lane；redactbench-gpt-judge-parallel-summary-20261120.scope 承载汇总协调器；redactbench-gpt-judge-eight-20261120.scope 承载扩容后的辅助调度器。旧 redactbench-gpt-judge-extra-20261120.scope 中已发出的 grader 请求保留运行，由新调度器监控其 PID 并预留并发槽；它们的逐题结果继续进入唯一案例进度。原四条 lane、grader 请求和 Opus 未重启或中断。

已验证：5 项回归覆盖绑定/证据/虚拟时间拒绝、真实20包的无损往返、按逐题数及限时目标分母汇总、两类 A/B 路径分类；真实长图/SVG 传输重建；首条真实 API 判断通过原官方汇总入口。

并发新增 4 项离线回归覆盖文本/图片预约估计、未兑现预约计算、同案例进程互斥和重复启动幂等。新增两路已分别在约 98/101 秒内完成真实案例，判断通过原 scoring_v2 和证据校验；上线检查全评测 RSS 约 0.95 GiB。辅助结果完成立即计入唯一案例进度，官方质量汇总仍以各批次 evaluate --partial 输出为准。

八路扩容时保留在途 grader PID 502275/502460，只替换辅助调度器 PID 498692；新调度器 PID 502673 采用两条在途请求后启动另外两条，实测全评测 RSS 约 1.0 GiB。新增采用请求预留槽回归后共 5 项并发测试通过。配置现在可在任务之间重读，后续调整并发或内存准入无需重启调度器；在途进程保留其启动时内存预约设置。

live-quality-snapshot.json 是某一时刻所有已验证逐题指标的临时质量汇总，覆盖可能大于官方已结束批次汇总；它不包含调用成本指标，不是全615题最终成绩。所有自动分数继续标记 provisional/self_evaluation。

## 全量自动评分已完成

615/615 个配置全部完成推理与 judge，32 个批次全部进入官方汇总，无缺失或运行失败的 judge。全量 GCR=91.5141%、TSR=69.2683%、LCR=91.8106%、六维=93.8862/100。62 题标记 needs_primary_review，关键违规3题；status=partial 表示仍有待复核项，不能理解为缺少任务。所有分数仍为同模型自动自评，尚未人工确认。

live-quality-snapshot.json 已更新为全量官方 summary 的副本，并明确执行/评分已完成、人工复核待处理；此前临时快照保存在 source-snapshots/live-quality-before-full-615.json。可读报告位于 output/results/gpt-6.1-sol-science-score-report.md。
