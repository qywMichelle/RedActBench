# 后台评测记录

启动日期：2026-11-19（香港时间）。测试包固定在 commit `30b38196ab972c4a81f636c8946ec8272c7923b0`，原代码、数据及冻结清单未修改。

范围：全部 615 个不同配置 = 配对清单的 215 对 A/B（430 个配置）+ 185 个没有 B 配置的主情境。共 32 个批次，每批最多 20 个配置。两份清单重叠的主配置不重复测试。

| 用户指定模型 | 实际代理 ID | 上游接口 | 启动状态 |
|---|---|---|---|
| Opus 5.5 | `claude-opus-5-5-science` | `https://mp.z01.normandyfunc.com/v1/messages` | 已启动 |
| GPT 6.1 Sol | `gpt-6.1-sol-science` | `https://mp.z01.normandyfunc.com/v1/responses` | 已启动 |
| Sonnet 5.5 | `claude-sonnet-5-5` | 尚待确认 | 代理返回模型已下线，等待可用 ID/地址 |

`models-proxy.stepfun-inc.com` 在本机无法解析，使用用户提供的备用域名。
原运行器连到本机 `127.0.0.1:18765`，外层适配转发到表中原生协议；模型接收的可见提示及已揭示图片保持一致，私有推理不当作动作。
接口适配代码 SHA 和实际发送参数固定在 `transport-binding.json`；`upstream-requests.jsonl` 逐请求记录上游请求 SHA、ID、用量和延迟，不存请求正文或凭据。

## 运行参数与内存

- 单轮输出预算 16384 token；每题最多 200 次请求；完整提示上限 200000 字符，不截断历史。
- 最多两个模型同时运行，各模型内部串行，每批结束后退出评测子进程并释放该批轨迹内存。
- 评测子进程和主管进程均使用 Linux `RLIMIT_AS=512 MiB` 硬限制；三个常驻进程的地址空间上限合计 1.5 GiB。刚启动时合计 RSS 约 94–98 MiB。
- systemd scope 另设置 `MemoryMax=1536M`；当前容器不能提供该 scope 的 cgroup 内存统计，因此以已核验的进程地址空间限制作为可确认的限制。详见 `memory-enforcement.json`。
- Opus 原生请求发 `temperature=1.0`；GPT 使用服务默认采样配置，省略不受支持的 `temperature/top_p/seed`。两个模型均不依赖 seed 可复现性。
- 最终瞬时接口/网络错误可自动续跑最多 3 次，等待 30/60/90 秒；使用原绑定，已终止题目跳过。永久错误停止对应模型并写 `needs_attention`。
- API key 只保存在进程环境和内存，未写入代码、文档、配置、轨迹、日志或 Git。

## 查看与停止

从 `/data/project/RedActBench` 执行：

```bash
PYTHONDONTWRITEBYTECODE=1 github_test_bundle/.venv/bin/python status_background.py \
  --directory github_test_bundle/output/ab-eval-20261119

systemctl --user status redactbench-20261119.scope
```

各模型的 `status.json` 记录当前批次；`logs/` 保存运行日志，`runs/` 保存逐轮原子落盘的轨迹。
每批结束自动执行 `check-run` 和 `export`，ZIP 放在该模型的 `exports/`。

需要停止时：

```bash
systemctl --user stop redactbench-20261119.scope
```

保持原代码、数据、地址与配置，使用同一个输出目录恢复：

```bash
PYTHONDONTWRITEBYTECODE=1 github_test_bundle/.venv/bin/python launch_background.py \
  --directory github_test_bundle/output/ab-eval-20261119 \
  --scope all --unit redactbench-20261119
```

启动器隐藏提示输入凭据，不把凭据放到 shell 命令。更改代码或参数需要另开目录。

适配层 4 项离线集成测试通过；两个模型的真实图片探测通过。真实轨迹已开始保存。
`complete` / `behavior_complete` 只表示行为执行终止，不代表质量达标；质量分仍需对实际轨迹执行语义审核，当前后台任务不自动生成语义成绩。

## 2026-11-19 恢复记录

第一次后台运行在 Opus 完成 99 个配置、GPT 完成 256 个配置后停止。Opus 连续收到上游 500，GPT 的 `batch_015/t4-02/B/A` 揭示了一张 2200×18240 长图，原生接口报告 39330 patches 超过 30000 的上限。

当前后台 unit 改为 `redactbench-images-20261119.scope`。原运行器、题目、CLI 配置、冻结清单和已经终止的轨迹均保持原样。
`resume_with_image_budget.py` 在原生 API 的图片发送层增加版本化处理：超过 29900 个 32×32 图像块的 PNG 按比例缩小，保留全画布，不裁切、不生成新内容；普通图片保持原字节。
该规则对本轮两个模型均适用。上游请求日志逐轮记录 `transport_revision`、`image_resizes`、原始/实际发送 PNG SHA、尺寸及图像块数。`transport-revisions/` 保留版本和源码 SHA；基准的原请求体及检查点绑定仍可按原运行器重建。

修复后的图片分辨率会低于原图，质量报告需披露这个传输差异，不能声称所有上游收到的图片字节始终相同。原导出 ZIP 之外还应保留该目录的传输说明和日志，供评阅时核验实际图片输入。

恢复查看和停止命令：

```bash
systemctl --user status redactbench-images-20261119.scope
systemctl --user stop redactbench-images-20261119.scope
```

下一次应使用新的图片适配启动器，继续同一输出目录：

```bash
PYTHONDONTWRITEBYTECODE=1 github_test_bundle/.venv/bin/python launch_image_budget.py \
  --directory github_test_bundle/output/ab-eval-20261119 \
  --unit redactbench-images-next
```

新规则和原适配层共 6 项离线测试通过，测试在 512 MiB 地址空间限制下执行。重试查看发现 Opus science 路由仍返回 500，hc 路由超时；该错误不作为模型质量失败评分。

## 第二次修复：已确认恢复真实调用

当前 unit 为 `redactbench-recovered-20261119.scope`，传输版本为 `full-canvas-image-patches-v2-strip-resize-hc-route`。

第一次图片适配只验证了单独图片处理，遗漏了完整 HTTP 请求叠加后的内存峰值。现改为 128 行分条 LANCZOS 缩放，保留 RGB/RGBA 和全画布，图片处理串行，转换缓存严格限制为 16 MiB。实际长图是 RGB；RGBA 用作额外压力覆盖。
真实断点的 13379362 字节请求通过了完整 HTTP 链路回归，峰值 RSS 约 364 MiB，512 MiB 地址空间限制保持不变。8 项图片/原适配测试及 2 项真实请求/路由身份测试通过。

Opus 原 `claude-opus-5-5-science` 路由仍返回 500；实测 `claude-opus-5-5-hc` 可用。后续原生请求切至 hc，原运行器配置和前 99 个 science 配置结果保留。
每轮真实响应保留实际 `reported_model`，上游日志增加 `routed_model`。质量报告必须披露路由变化；断点题前 9 轮为 science、后续为 hc，应单列为混合路由轨迹，不能声称所有 Opus 轨迹来自同一个代理后端。

两个原断点已经返回真实 200 并结束执行，后台已进入后续配置。GPT 长图实际发送尺寸为 1918×15903，29820 patches，原始与实际发送 PNG SHA 都在上游日志中。
已完成批次通过原导出 SHA 校验后直接跳过；遇到暂时接口错误，在原有短重试之外还可按 5/10/20 分钟做最多 3 次恢复，沿用原检查点。

查看或停止当前任务：

```bash
systemctl --user status redactbench-recovered-20261119.scope
systemctl --user stop redactbench-recovered-20261119.scope
```

以后用 `launch_image_budget.py` 和同一输出目录恢复，指定新的 unit 名；已有冻结数据和已终止轨迹继续保留。

## 第三次恢复：请求节流与持续等待

第二次恢复后 Opus 已结束 165 个配置（163 个 complete、2 个 request_limit），GPT 已结束 327 个配置。随后 Opus 上游返回 `invalid_grant`，GPT 的限流重试耗尽，旧后台退出。

最新 unit 为 `redactbench-paced-20261119.scope`，使用 `resume_with_rate_control.py`，传输版本 `full-canvas-image-patches-v3-paced-recovery`。Opus hc 路由再次探测可用；GPT 小输出请求成功，但 16384 输出预算请求仍可能被限流。
GPT 请求起始间隔至少 45 秒；Opus 至少 2 秒。限流等待单独记录为 `rate_wait_seconds`，总往返延迟仍保留，另记录扣除限流等待后的延迟。题目输入、图片处理规则及输出上限 16384 均保留。

临时 HTTP 错误和上游 `invalid_grant` 在原短重试之外，以 5/10/15 分钟间隔继续恢复原检查点，最长等待恢复窗口为 72 小时。错误 API key（401）和不支持的参数等永久错误不自动重试，也不自动更换用户密钥。
6 项请求节流、预算保持和错误分类测试通过。新后台已经保存了两个模型的真实续跑回合，Opus 的原断点已经再次结束执行；GPT 仍可能间歇限流，应查看实际记录更新时间，不能把等待状态当作一直推进。

查看或停止最新任务：

```bash
systemctl --user status redactbench-paced-20261119.scope
systemctl --user stop redactbench-paced-20261119.scope
```

以后用带节流的启动器恢复同一目录：

```bash
PYTHONDONTWRITEBYTECODE=1 github_test_bundle/.venv/bin/python launch_rate_control.py \
  --directory github_test_bundle/output/ab-eval-20261119 \
  --unit redactbench-paced-next --opus-route claude-opus-5-5-hc
```

单进程地址空间限制仍为 512 MiB，scope 配置内存上限仍为 1536 MiB。源码快照与策略记录保存在 `transport-revisions/`，已完成配置继续跳过。

## 2026-11-20：图片字节与尺寸限制已通过真实调用

Opus 在已结束 256 个配置后遇到 Claude 的单张图片 base64 字段 10 MiB 限制；修复字节限制后又确认单边尺寸上限为 8000 像素。
当前传输版本为 `full-canvas-image-patches-v5-byte-dimension-budget-adaptive-pacing`，unit 为 `redactbench-live-20261120.scope`。

原图片先做保持完整画布的 PNG 优化和必要等比缩小，使图像块不超过 29900、base64 不超过 9 MiB。Claude 仍超长的图片以带坐标标记的连续片段发送，单边不超过 7900，边界重叠 16 像素，合并覆盖完整画布。片段 SHA、矩形坐标和原始画布尺寸保存在 `image_tiles`，原图与缩放结果的 SHA 保存在 `image_resizes`。GPT Responses 保持完整画布单图发送。
实际断点长图完整 HTTP 回归通过，在 512 MiB 地址空间限制下峰值 RSS 约 466 MiB；真实 Claude 调用也已返回 200，并从原 2 轮检查点继续保存新的动作。

GPT 从 20 秒请求间隔开始，每连续 20 次成功将间隔乘 0.85，最低 12 秒；遇到限流重新加大间隔，最高 45 秒。输出预算保持 16384，任务数据和已有轨迹继续保留。

查看和停止最新任务：

```bash
systemctl --user status redactbench-live-20261120.scope
systemctl --user stop redactbench-live-20261120.scope
```

仍使用 `launch_rate_control.py` 恢复同一目录，指定新的 unit 名。正式报告应披露分辨率、连续分片和代理路由变化，并保留原导出 ZIP 之外的传输元数据。


## 2026-11-20：并发辅助评测已上线

原 scope redactbench-live-20261120.scope 保持运行；新增 redactbench-accelerated-20261120-fair.scope。每模型额外 2 个独立进程运行未来批次，不改变题目、模型输入、采样和预算。原任务继续使用旧桥接和节流；新链路共享公平请求槽并逐步降低间隔，429 时自动让出配额。独占写锁和导出锁保证两个调度器不会覆盖或重复执行同一轨迹。

原 upstream-requests.jsonl 保留；额外真实请求在 upstream-requests-accelerated.jsonl，质量审核必须同时保留两份 ledger、acceleration-binding.json 和 transport-revisions/。正式 ZIP 仍在各模型 exports/。性能和等价性证据见 ../performance/CONCURRENCY.md。


## GPT 已全量完成，Opus 并发收尾

GPT 的 615 个配置均 complete，32 个官方 ZIP 逐文件 SHA 核验通过，汇总包在 ../results/gpt-6.1-sol-science-all615.zip；这是行为轨迹，尚未执行正式语义评分。

GPT 辅助任务已释放，本次以新增 redactbench-opus-finish-20261120.scope 把两路容量用于 Opus 尚未启动的 paired-020/021。继续复用既有桥接、共享限流器、原独占轨迹锁及官方导出锁，全部旧 Opus 任务保持运行。extra-opus-status.json 记录额外任务与含所有评测进程的实时 RSS，额外任务结束自动退出。


## GPT 自动 judge 已启动

用户明确要求对完成的 GPT 6.1 Sol 轨迹启动评分。四条低内存 API judge lane 已在后台工作，普通进程约 38–50 MiB，重操作串行、每进程 512 MiB 限制。使用 gpt-6.1-sol-science，结果标记同模型自动评审/待确认，不提供参考轨迹给裁判。原 Opus 任务继续运行。进度及完整规则见 gpt-6.1-sol-science/judge-v2-api-20261120/status.json、README.md。

## GPT judge 并发扩容

新增 redactbench-gpt-judge-extra-20261120.scope，提前审核已准备批次的尾部案例。原四条 API lane 和所有 Opus 行为评测保留既有 PID；只有无状态汇总协调器换为 redactbench-gpt-judge-parallel-summary-20261120.scope。Opus 运行期间辅助最多两路，总并发上限六路；Opus behavior_complete 后且内存允许时辅助最多四路，总并发上限八路。

逐案例文件锁保证原 lane 和辅助进程不重复调用；已验证判断写回原审核目录，原 lane 后续复用。图片/回放/官方汇总重操作仍串行，单进程地址空间仍为 512 MiB。新增 FIFO 内存预约使用 1220 MiB 预计水位，辅助新增调用还检查 1040 MiB 实测 RSS 水位；无可确认的 cgroup 计数，不声明已经验证全进程硬内存上限。本 venv 两次执行 .pth 的重复预约问题已修复为幂等启动。

裁判模型、提示、完整证据及 16384 输出预算保持原值。新增两路已完成真实案例并通过原 scoring_v2 和证据校验，上线检查全评测 RSS 约 0.95 GiB。并发 4 项离线回归通过；进度按唯一完成案例计数，不直接相加可能重叠的 lane/辅助数量。自动语义成绩继续标为 provisional/self_evaluation，官方汇总覆盖与逐案例完成数分别报告。

### 后续八路扩容

用户再次要求提速后，辅助并发提高到四路，总上限八路，Opus 同时继续运行。内存预约预计水位调整为 1344 MiB、辅助 RSS 准入水位为 1120 MiB；单进程 512 MiB 和重操作串行保留。图片案例需要更高预约，内存不足时等待，不承诺一直满八路。

新增 redactbench-gpt-judge-eight-20261120.scope 采用旧辅助调度器的两个在途 grader PID（502275/502460），只替换调度器，没有取消其模型请求；采用请求占用并发槽，避免扩容时超发。原四条 lane 和所有 Opus 进程保持运行。扩容后实测全评测 RSS 约 1.0 GiB，并发回归共5项通过，提示、证据和评分预算保持原值。新辅助调度器在任务之间重新读取配置，以后无需重启即可调整准入参数。

## GPT 全量评分完成与 Opus 末批恢复

GPT 的615/615个配置全部完成 judge 并进入32批官方汇总，62题标记待复核，所有分数仍为同模型自动自评。summary/status 的 partial 表示待复核，并非缺少任务；全量分数及 A/B/无配对分组见 results/gpt-6.1-sol-science-score-report.md 和原 summary.json。

Opus 在 paired-019 遇到原 200000 字符输入上限后，另一个续跑调度器到达同批；旧18765桥接已退出，保存的原地址仍被访问，导致 Connection refused 并持续退避。现有33209加速桥接健康，已在 acceleration-control.json 设置 redirect_legacy=true，将原请求字节和参数转给同一个现存桥接。新 redactbench-opus-bridge-recovery-20261120.scope 对原目录执行 run --resume；已观察到真实200及断点新增回合，原冻结参数和已终止轨迹保留。

恢复入口 run_opus_finish_recovery.py 在所有配置终止后执行原 check-run/export，并逐批核对官方 ZIP SHA。原 input_budget_exceeded 轨迹和两个 request_limit 结果继续保留，不能算成功或更改预算重跑。实时恢复状态在 opus-finish-recovery-status.json；单进程地址空间仍为512MiB。桥接配置旧版和说明保存在 transport-revisions/。
