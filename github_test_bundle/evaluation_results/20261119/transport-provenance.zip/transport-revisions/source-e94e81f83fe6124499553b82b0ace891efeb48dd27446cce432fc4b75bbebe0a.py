"""Versioned native-image adaptation; frozen bench prompts/configs remain unchanged."""
import base64
from datetime import datetime, timezone
import hashlib
import io
import json
import math
from pathlib import Path
import struct
import sys
import threading

from PIL import Image, __version__ as PIL_VERSION
import provider_bridge
import run_background

PATCH_SIZE = 32
MAX_PATCHES = 29900
REVISION = 'full-canvas-image-patches-v1'
ORIGINAL_TRANSLATE = provider_bridge.translate
ORIGINAL_RECORD = provider_bridge.Server.record
LOCAL = threading.local()


def patches(width, height):
    return math.ceil(width / PATCH_SIZE) * math.ceil(height / PATCH_SIZE)


def fit_png(data):
    if not data.startswith(b'\x89PNG\r\n\x1a\n'):
        raise ValueError('Expected PNG image')
    width, height = struct.unpack('>II', data[16:24])
    if patches(width, height) <= MAX_PATCHES:
        return data, None
    factor = math.sqrt(MAX_PATCHES / patches(width, height))
    target_width = max(1, int(width * factor))
    target_height = max(1, int(height * factor))
    while patches(target_width, target_height) > MAX_PATCHES:
        factor *= .999
        target_width = max(1, int(width * factor))
        target_height = max(1, int(height * factor))
    with Image.open(io.BytesIO(data)) as original:
        original.thumbnail((target_width, target_height), Image.Resampling.LANCZOS)
        output = io.BytesIO()
        original.save(output, format='PNG')
        resized = output.getvalue()
        actual_width, actual_height = original.size
    binding = {'original_png_sha256': hashlib.sha256(data).hexdigest(),
               'transmitted_png_sha256': hashlib.sha256(resized).hexdigest(),
               'original_size': [width, height], 'transmitted_size': [actual_width, actual_height],
               'original_patches': patches(width, height),
               'transmitted_patches': patches(actual_width, actual_height),
               'conversion': 'full-canvas-proportional-lanczos', 'cropped': False}
    return resized, binding


def translate(body):
    LOCAL.resizes = []
    protocol, upstream = ORIGINAL_TRANSLATE(body)
    for message in upstream['messages' if protocol == 'messages' else 'input']:
        for index, part in enumerate(message['content']):
            if protocol == 'responses' and part['type'] == 'input_image':
                url = part['image_url']
                prefix, encoded = url.split(',', 1)
                if prefix != 'data:image/png;base64':
                    raise ValueError('Expected PNG data URL')
            elif protocol == 'messages' and part['type'] == 'image':
                encoded = part['source']['data']
            else:
                continue
            data, binding = fit_png(base64.b64decode(encoded, validate=True))
            if binding is not None:
                encoded = base64.b64encode(data).decode()
                if protocol == 'responses':
                    part['image_url'] = 'data:image/png;base64,' + encoded
                else:
                    part['source']['data'] = encoded
                LOCAL.resizes.append(dict(binding, content_index=index))
    return protocol, upstream


def record(server, row):
    row['transport_revision'] = REVISION
    row['image_resizes'] = getattr(LOCAL, 'resizes', [])
    ORIGINAL_RECORD(server, row)
    LOCAL.resizes = []


def main():
    # The baseline binding and files remain intact. The supplementary record
    # declares the new native-image preprocessing for reviewers.
    index = sys.argv.index('--directory')
    directory = Path(sys.argv[index + 1]).resolve()
    baseline = json.loads((directory / 'transport-binding.json').read_text())
    root = Path(__file__).resolve().parent
    for name, expected in baseline['adapter_files'].items():
        if hashlib.sha256((root / name).read_bytes()).hexdigest() != expected:
            raise ValueError('Original frozen adapter changed: ' + name)
    revision = {'revision': REVISION, 'activated_at': datetime.now(timezone.utc).isoformat(),
                'baseline_binding_sha256': hashlib.sha256((directory / 'transport-binding.json').read_bytes()).hexdigest(),
                'source_file': str(Path(__file__).resolve()),
                'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                'pillow_version': PIL_VERSION, 'max_patches_per_image': MAX_PATCHES,
                'patch_size': PATCH_SIZE, 'applies_to_models': list(provider_bridge.MODELS),
                'full_canvas_preserved': True, 'frozen_runner_and_case_files_changed': False,
                'prior_trajectories_resampled': False,
                'scope': 'Native provider image payloads only; original bench request SHA and checkpoint bindings unchanged.',
                'limitation': 'Oversized images have lower pixel resolution after this revision; disclose in quality reports.'}
    history = directory / 'transport-revisions'
    history.mkdir(exist_ok=True)
    path = history / (datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S') + '-image-budget.json')
    path.write_text(json.dumps(revision, indent=2) + '\n')
    provider_bridge.translate = translate
    provider_bridge.Server.record = record
    run_background.main()


if __name__ == '__main__':
    main()
