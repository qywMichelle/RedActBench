"""Parallel, resumable API judging of the 200 frozen hard-case trajectories."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import fcntl
import getpass
import hashlib
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import math
import os
from pathlib import Path
import queue
import re
import shutil
import signal
import socket
import struct
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import zipfile

MIB = 1024**2
STOP = threading.Event()
PROJECT = Path('/data/project/RedActBench')
MODELS = ['opus-5.5', 'gemini-3.8-flash', 'gpt-6.1-sol', 'kimi-3.1-pro']


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(MIB), b''):
            h.update(chunk)
    return h.hexdigest()


def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(compact(value) + '\n'); temporary.replace(path)


def memory(root):
    found = {}
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            argv = proc.joinpath('cmdline').read_bytes().split(b'\0')
            if not any(a == str(root).encode() or a.startswith(str(root).encode() + b'/') for a in argv):
                continue
            found[int(proc.name)] = next(int(line.split()[1]) * 1024 for line in
                proc.joinpath('status').read_text().splitlines() if line.startswith('VmRSS:'))
        except (OSError, StopIteration):
            pass
    return found


class Relay(ThreadingHTTPServer):
    daemon_threads = True
    def __init__(self, address, output, key, binding):
        super().__init__(address, Handler)
        self.output, self.key, self.binding = output, key, binding
        self.condition = threading.Condition(); self.ledger_lock = threading.Lock()
        self.charges = {}; self.next_identity = 0; self.cooldown = 0.; self.factor = .35
        self.active = 0; self.limits = 0; self.completed = 0; self.last_headers = {}

    def reserve(self, characters, maximum, deadline):
        with self.condition:
            while not STOP.is_set() and time.monotonic() < deadline:
                now = time.monotonic()
                self.charges = {k: v for k, v in self.charges.items() if v['pending'] or v['expires'] > now}
                estimate = int(characters * self.factor * 1.15) + maximum
                if estimate > 800000:
                    raise ValueError('Full judge packet exceeds relay token budget; evidence was not truncated')
                if now >= self.cooldown and self.active < 8 and sum(v['tokens'] for v in self.charges.values()) + estimate <= 800000:
                    self.next_identity += 1; identity = self.next_identity
                    self.charges[identity] = {'tokens': estimate, 'pending': True, 'expires': now + 60}
                    self.active += 1
                    return identity
                self.condition.wait(1)
        raise TimeoutError('Judge relay admission deadline reached')

    def complete(self, identity, usage, characters, retry_after=None, headers=None):
        with self.condition:
            self.active -= 1; now = time.monotonic(); entry = self.charges[identity]
            if retry_after is not None:
                # Retain the attempted reservation for a minute; rejected requests may affect proxy counters.
                entry.update(pending=False, expires=now + 60)
                self.cooldown = max(self.cooldown, now + retry_after + .5); self.limits += 1
            else:
                incoming = usage.get('input_tokens', usage.get('prompt_tokens', 0)) or 0
                outgoing = usage.get('output_tokens', usage.get('completion_tokens', 0)) or 0
                total = max(incoming + outgoing, usage.get('total_tokens', 0) or 0)
                entry.update(tokens=total or entry['tokens'], pending=False, expires=now + 60)
                if incoming and characters:
                    self.factor = max(.18, min(.6, self.factor * .7 + incoming / characters * .3))
                self.completed += 1
            self.last_headers = {k: v for k, v in (headers or {}).items()
                                 if any(s in k.lower() for s in ['ratelimit', 'retry-after'])}
            self.condition.notify_all()

    def record(self, row):
        with self.ledger_lock, (self.output / 'judge-api-requests.jsonl').open('a') as stream:
            stream.write(compact(row).replace(self.key, '[REDACTED]') + '\n')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def reply(self, status, body):
        try:
            payload = compact(body).replace(self.server.key, '[REDACTED]').encode()
            self.send_response(status); self.send_header('Content-Type', 'application/json')
            self.send_header('Content-Length', str(len(payload))); self.end_headers(); self.wfile.write(payload)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_POST(self):
        if self.path != '/v1/responses' or not hmac.compare_digest(self.headers.get('Authorization', ''), 'Bearer ' + self.server.key):
            self.reply(401, {'error': 'Invalid local judge request'}); return
        started = time.monotonic(); deadline = started + 1100; identity = None
        row = {'started_at': time.time(), 'status': 502, 'retry_events': [], 'token_wait_seconds': 0.}
        try:
            length = int(self.headers['Content-Length'])
            if not 0 < length <= 8 * MIB:
                raise ValueError('Judge request byte budget exceeded')
            payload = self.rfile.read(length); body = json.loads(payload)
            if body['model'] != self.server.binding['judge_model']:
                raise ValueError('Frozen judge model mismatch')
            row.update(model=body['model'], request_sha256=hashlib.sha256(payload).hexdigest(), request_bytes=length)
            characters = len(payload.decode())
            for attempt in range(12):
                wait = time.monotonic(); identity = self.server.reserve(characters, body['max_output_tokens'], deadline)
                row['token_wait_seconds'] += round(time.monotonic() - wait, 3)
                native = urllib.request.Request(self.server.binding['upstream_endpoint'], payload,
                    {'Authorization': 'Bearer ' + self.server.key, 'Content-Type': 'application/json'})
                try:
                    with urllib.request.urlopen(native, timeout=min(600, max(1, deadline - time.monotonic()))) as response:
                        raw = json.load(response); headers = dict(response.headers)
                    self.server.complete(identity, raw.get('usage', {}), characters, headers=headers); identity = None
                    row.update(status=200, attempts=attempt + 1, usage=raw.get('usage'), reported_model=raw.get('model'))
                    self.reply(200, raw); break
                except urllib.error.HTTPError as error:
                    message = error.read(2000).decode(errors='replace').replace(self.server.key, '[REDACTED]')
                    headers = dict(error.headers)
                    delay_header = error.headers.get('Retry-After') or error.headers.get('Ratelimit-Reset')
                    match = re.search(r'retry after (\d+) seconds?', message, re.I)
                    try:
                        delay = math.ceil(float(delay_header)) if delay_header else int(match.group(1)) if match else 30
                    except ValueError:
                        delay = 30
                    self.server.complete(identity, {}, characters, retry_after=delay, headers=headers); identity = None
                    row['retry_events'].append({'status': error.code, 'retry_after_seconds': delay, 'error': message,
                        'headers': {k: v for k, v in headers.items() if any(s in k.lower() for s in ['ratelimit', 'retry-after'])}})
                    row.update(status=error.code, attempts=attempt + 1)
                    if error.code not in {429, 500, 502, 503, 504} or attempt == 11 or time.monotonic() >= deadline:
                        self.reply(error.code, {'error': message}); break
        except Exception as error:
            if identity is not None:
                self.server.complete(identity, {}, 0, retry_after=5)
            row.update(status=502, error=type(error).__name__ + ': ' + str(error).replace(self.server.key, '[REDACTED]'))
            self.reply(502, {'error': row['error']})
        finally:
            row['seconds'] = round(time.monotonic() - started, 3); self.server.record(row)


def freeze(args):
    output = args.output.resolve(); cohort = args.cohort.resolve()
    if (output / 'judge-binding.json').exists():
        return json.loads((output / 'judge-binding.json').read_text())
    if output.exists() and any(output.iterdir()) and {p.name for p in output.iterdir()} != {'source-snapshots'}:
        raise ValueError('Use a new judge output directory')
    completion = json.loads((cohort / 'completion-summary.json').read_text())
    assert completion['complete_configurations'] == completion['verified_exports'] == 200
    output.mkdir(parents=True, exist_ok=True)
    sources = ['script/score_hard_cases.py', 'script/hard_case_judge_child.py', 'script/judge_case.py',
               'script/judge_protocol.py', 'script/judge_packet_codec.py', 'github_test_bundle/eval/scoring_v2.py',
               'github_test_bundle/eval/rubric.json', 'script/provider_bridge.py']
    hashes = {}
    for relative in sources:
        source = PROJECT / relative; destination = output / 'source-snapshots' / relative.replace('github_test_bundle/', '')
        destination.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(source, destination); hashes[relative] = sha(source)
    sys.path.insert(0, str(output / 'source-snapshots/script')); sys.path.insert(0, str(output / 'source-snapshots/eval'))
    import judge_protocol
    session = json.loads((cohort / 'session-binding.json').read_text()); jobs = []
    for entry in session['episodes']:
        for model in MODELS:
            export = cohort / model / 'exports' / (entry['collection_id'] + '.zip')
            jobs.append({'model': model, 'case': entry['collection_id'], 'world_case': entry['case'],
                         'family': entry['family'], 'export_sha256': sha(export)})
    binding = {'schema': 'hard-case-api-judge-v2', 'judge_model': args.judge_model,
        'behavior_session_sha256': sha(cohort / 'session-binding.json'), 'cohort': str(cohort), 'jobs': jobs,
        'sources': hashes, 'system_prompt_sha256': hashlib.sha256(judge_protocol.SYSTEM.encode()).hexdigest(),
        'scoring_version': 'redact-scoring-v2', 'maximum_case_workers': args.workers,
        'maximum_upstream_concurrency': 8, 'memory_admission_limit_mib': 1280,
        'per_process_address_space_mib': 512, 'max_output_tokens': 16384,
        'local_base_url': 'http://127.0.0.1:18953/v1', 'upstream_endpoint': 'https://mp.z01.normandyfunc.com/v1/responses',
        'reference_trajectories_in_prompt': False, 'candidate_identity_in_prompt': False,
        'candidate_history_window': 20, 'judge_evidence': 'All recorded candidate calls and full source final record',
        'critical_criteria_mapping': 'Verbatim frozen goal/check boundary strings with source pointers',
        'provisional_automated_scores': True, 'human_confirmed': False,
        'self_evaluation_models': ['gpt-6.1-sol'] if args.judge_model == 'gpt-6.1-sol-science' else [],
        'cq': 'not_scorable: original bundle has no calibrated CQ anchors'}
    write(output / 'judge-binding.json', binding); write(output / 'empty-image-delivery.json', {})
    (output / 'README.md').write_text('本轮按原项目v2评分协议评审四模型各50条、共200条hard case。'
        '裁判gpt-6.1-sol-science；全部候选调用和实际交付均保留，候选模型身份与作者参考轨迹不进入评分输入。'
        '六维锚点与GCR/TSR/LCR计算沿用原项目。关键边界按冻结rubric原文映射并保留源指针。'
        'GPT候选属于同模型自动评审，汇总中单独标记；所有评分尚未经人工确认。\n'
        '16个case工作者上限，最多8个上游调用；内存准入1280 MiB，每子进程地址空间512 MiB。'
        '响应头Retry-After/Ratelimit-Reset优先于错误文本，拒绝请求也保留一分钟预算，避免密集重试。\n'
        'status.json为进度；summary.json和score-report.md为汇总；各模型目录保留judge-inputs、judgments、'
        'raw-responses、case-status和packet-bindings。完整评分结束后生成judge-evidence.zip。\n')
    return binding


class Coordinator:
    def __init__(self, args, binding):
        self.args, self.binding = args, binding; self.output = args.output.resolve(); self.cohort = args.cohort.resolve()
        self.guard = threading.Lock(); self.children = {}; self.reservations = {}; self.workers = {}; self.failed = {}
        self.relay = Relay(('127.0.0.1', 18953), self.output, os.environ['REDACT_API_KEY'], binding)
        sys.path.insert(0, str(self.output / 'source-snapshots/eval'))
        from scoring_v2 import aggregate
        self.aggregate = aggregate

    def execute(self, job):
        run = self.cohort / job['model'] / 'runs' / job['case']
        source_size = sum((run / n).stat().st_size for n in ['world-record.json', 'turns.jsonl'])
        charge = min(448 * MIB, 48 * MIB + source_size * 14)
        while not STOP.is_set():
            with self.guard:
                observed = memory(self.output)
                outstanding = sum(max(0, amount - observed.get(pid, 0)) for pid, amount in self.reservations.items())
                if sum(observed.values()) + outstanding + charge <= 1280 * MIB:
                    log = self.output / 'logs' / (job['model'] + '-' + job['case'] + '.log'); log.parent.mkdir(exist_ok=True)
                    command = ['prlimit', '--as=536870912', '--core=0', '--', str(PROJECT / 'github_test_bundle/.venv/bin/python'),
                        str(self.output / 'source-snapshots/script/hard_case_judge_child.py'), 'judge',
                        '--output', str(self.output), '--cohort', str(self.cohort), '--model', job['model'], '--case', job['case']]
                    with log.open('a') as stream:
                        child = subprocess.Popen(command, cwd=PROJECT, env=dict(os.environ, MALLOC_ARENA_MAX='2', PYTHONUNBUFFERED='1'),
                            stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT)
                    self.children[child.pid] = job; self.reservations[child.pid] = charge; break
            STOP.wait(1)
        else:
            return 130
        try:
            while child.poll() is None:
                STOP.wait(1)
            return child.returncode
        finally:
            with self.guard:
                self.children.pop(child.pid, None); self.reservations.pop(child.pid, None)

    def worker(self, index, pending):
        while not STOP.is_set():
            try:
                job = pending.get_nowait()
            except queue.Empty:
                return
            identity = job['model'] + '/' + job['case']
            for attempt in range(12):
                with self.guard:
                    self.workers[str(index)] = {'job': identity, 'status': 'judging', 'attempt': attempt + 1}
                code = self.execute(job)
                destination = self.output / job['model'] / 'judgments' / (job['case'] + '.json')
                if code == 0 and destination.exists():
                    break
                status_path = self.output / job['model'] / 'case-status' / (job['case'] + '.json')
                status = json.loads(status_path.read_text()) if status_path.exists() else {}
                if status.get('status') == 'needs_review' and attempt >= 2:
                    break
                if STOP.wait(min(120, 15 * (attempt + 1))):
                    return
            with self.guard:
                if not destination.exists():
                    self.failed[identity] = {'exit_code': code, 'error': status.get('error', 'Judge did not produce a valid judgment')}
                self.workers[str(index)] = {'job': identity, 'status': 'complete' if destination.exists() else 'needs_attention'}

    def save(self, final=False):
        by_model = {}; rows = []; pending_review = []; completed = 0
        for model in MODELS:
            model_rows = []
            for job in self.binding['jobs']:
                if job['model'] != model:
                    continue
                status_path = self.output / model / 'case-status' / (job['case'] + '.json')
                if not status_path.exists():
                    continue
                case = json.loads(status_path.read_text())
                if case.get('status') != 'complete':
                    continue
                costs = json.loads((self.output / model / 'packet-bindings' / (job['case'] + '.json')).read_text())['costs']
                row = dict(case=job['case'], family=job['family'], **costs, **case['metrics'])
                model_rows.append(row); completed += 1
                if case.get('needs_primary_review'):
                    pending_review.append({'model': model, 'case': job['case'], 'issues': case['needs_primary_review']})
            by_model[model] = {'planned_cases': 50, 'completed_cases': len(model_rows),
                'self_evaluation': model in self.binding['self_evaluation_models'], 'metrics': self.aggregate(model_rows)}
            rows.extend(model_rows)
        observed = memory(self.output)
        with self.guard, self.relay.condition:
            done = completed == 200 and not self.failed
            status = {'status': 'scoring_complete' if final and done else 'needs_attention' if final else 'running',
                'pid': os.getpid(), 'judge_model': self.binding['judge_model'], 'planned_cases': 200, 'completed_cases': completed,
                'by_model': {m: {'completed': d['completed_cases'], 'planned': 50} for m, d in by_model.items()},
                'maximum_case_workers': self.args.workers, 'active_case_processes': len(self.children),
                'workers': self.workers, 'failed_cases': self.failed, 'rss_mib': round(sum(observed.values()) / MIB, 2),
                'memory_admission_limit_mib': 1280, 'active_upstream_requests': self.relay.active,
                'upstream_429_events': self.relay.limits, 'successful_upstream_requests': self.relay.completed,
                'remaining_quota_wait_seconds': round(max(0, self.relay.cooldown - time.monotonic()), 1),
                'last_rate_headers': self.relay.last_headers, 'updated_at': time.time()}
            write(self.output / 'status.json', status)
            summary = {'status': 'complete' if final and done else 'partial', 'scoring_complete': final and done,
                'judge_model': self.binding['judge_model'], 'scoring_version': 'redact-scoring-v2',
                'planned_cases': 200, 'completed_cases': completed, 'by_model': by_model,
                'overall': self.aggregate(rows), 'needs_primary_review': pending_review, 'failed_cases': self.failed,
                'provisional_automated_scores': True, 'human_confirmed': False,
                'interpretation': 'Original v2 anchors and deterministic scorer; missing reviews are not zero scores. Same-model GPT review is flagged. CQ and reference-relative efficiency remain null without calibrated anchors or verified author trajectories.'}
            write(self.output / 'summary.json', summary)
        return summary

    def finish(self):
        # Revalidate every saved judgment against its full expanded packet before final aggregation.
        sys.path.insert(0, str(self.output / 'source-snapshots/script'))
        import judge_protocol
        for job in self.binding['jobs']:
            directory = self.output / job['model']; destination = directory / 'judgments' / (job['case'] + '.json')
            if destination.exists():
                packet = json.loads((directory / 'judge-inputs' / (job['case'] + '.json')).read_text())
                judge_protocol.validate(json.loads(destination.read_text()), packet)
        summary = self.save(final=True)
        if not summary['scoring_complete']:
            return
        lines = ['# Hard case 200条自动评分', '', '裁判：gpt-6.1-sol-science；沿用原项目v2锚点与评分器。', '',
                 '| 模型 | 已评分 | 六维总分 | GCR | TSR | LCR |', '|---|---:|---:|---:|---:|---:|']
        def fmt(value, suffix=''):
            return 'N/A' if value is None else f'{value:.2f}' + suffix
        for model, item in summary['by_model'].items():
            values = item['metrics']
            lines.append(f"| {model} | {item['completed_cases']}/50 | {fmt(values['six_dimension_total'], '/100')} | {fmt(values['GCR'], '%')} | {fmt(values['TSR'], '%')} | {fmt(values['LCR'], '%')} |")
        lines += ['', f"{len(summary['needs_primary_review'])}条含待负责人复核事项。全部属于自动评分，尚未经人工确认；GPT候选是同模型评审。CQ无校准锚点、作者参考轨迹未提供，相关结果保持null。"]
        (self.output / 'score-report.md').write_text('\n'.join(lines) + '\n')
        with zipfile.ZipFile(self.output / 'judge-evidence.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(self.output.rglob('*')):
                if path.is_file() and path.name != 'judge-evidence.zip' and (path.suffix in {'.json', '.md', '.py'}):
                    archive.write(path, str(path.relative_to(self.output)))

    def run(self):
        lock = (self.output / '.coordinator.lock').open('a+'); fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        threading.stack_size(MIB); threading.Thread(target=self.relay.serve_forever, daemon=True).start()
        pending = queue.Queue()
        for job in self.binding['jobs']:
            pending.put(job)
        try:
            with ThreadPoolExecutor(max_workers=self.args.workers) as pool:
                futures = [pool.submit(self.worker, index, pending) for index in range(self.args.workers)]
                while any(not future.done() for future in futures):
                    self.save(); STOP.wait(5)
                for future in futures:
                    future.result()
            self.finish()
        finally:
            self.relay.shutdown(); self.relay.server_close()


def launch(args):
    key = getpass.getpass('Existing evaluation API key (hidden): ')
    if not key:
        raise ValueError('Credential input is empty')
    socket_path = Path('/tmp') / ('hard-judge-key-' + str(time.time_ns()) + '.sock')
    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM); server.bind(str(socket_path))
    os.chmod(socket_path, 0o600); server.listen(1); server.settimeout(30)
    unit = 'hard-case-200-judge-' + str(time.time_ns())
    try:
        command = ['systemd-run', '--user', '--unit=' + unit, '--property=Type=exec', '--property=MemoryMax=1536M',
            '--property=WorkingDirectory=' + str(PROJECT), '--property=StandardOutput=append:' + str(args.output / 'supervisor.log'),
            '--property=StandardError=append:' + str(args.output / 'supervisor.log'), '--setenv=MALLOC_ARENA_MAX=2',
            '--setenv=PYTHONUNBUFFERED=1', str(PROJECT / 'github_test_bundle/.venv/bin/python'),
            str(args.output / 'source-snapshots/script/score_hard_cases.py'), '--output', str(args.output),
            '--cohort', str(args.cohort), '--workers', str(args.workers), '--judge-model', args.judge_model,
            '--credential-socket', str(socket_path)]
        result = subprocess.run(command, capture_output=True, text=True, timeout=20)
        if result.returncode:
            raise RuntimeError('Judge service launch failed: ' + result.stderr)
        with server.accept()[0] as client:
            pid, uid, _ = struct.unpack('3i', client.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))
            if uid != os.getuid():
                raise RuntimeError('Unexpected credential recipient')
            client.sendall(key.encode())
        write(args.output / 'launcher.json', {'pid': pid, 'unit': unit + '.service', 'started_at': time.time(),
            'maximum_case_workers': args.workers, 'maximum_upstream_concurrency': 8})
        print(compact({'status': 'launched', 'pid': pid, 'output': str(args.output), 'maximum_case_workers': args.workers}))
    finally:
        server.close(); socket_path.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--cohort', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--workers', type=int, default=16)
    parser.add_argument('--judge-model', default='gpt-6.1-sol-science')
    parser.add_argument('--launch', action='store_true')
    parser.add_argument('--prepare-only', action='store_true')
    parser.add_argument('--credential-socket')
    args = parser.parse_args(); args.output = args.output.resolve(); args.cohort = args.cohort.resolve()
    binding = freeze(args)
    for relative, expected in binding['sources'].items():
        frozen = args.output / 'source-snapshots' / relative.replace('github_test_bundle/', '')
        if sha(frozen) != expected:
            raise ValueError('Frozen judge implementation changed: ' + relative)
    if args.prepare_only:
        print(compact({'status': 'frozen', 'jobs': len(binding['jobs']), 'output': str(args.output)})); return
    if args.launch:
        launch(args); return
    if args.credential_socket:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.connect(args.credential_socket); key = bytearray()
            while len(key) <= 1024:
                chunk = client.recv(1024)
                if not chunk:
                    break
                key.extend(chunk)
        if not key or len(key) > 1024:
            raise ValueError('Invalid credential delivery')
        os.environ['REDACT_API_KEY'] = key.decode()
    if not os.environ.get('REDACT_API_KEY'):
        raise ValueError('Authorized API credential is required')
    signal.signal(signal.SIGTERM, lambda *_: STOP.set())
    Coordinator(args, binding).run()


if __name__ == '__main__':
    main()
