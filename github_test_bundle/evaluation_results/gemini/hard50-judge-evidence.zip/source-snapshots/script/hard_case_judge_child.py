"""Adapt hard-case records to the unchanged project v2 judge and scorer."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import urllib.request
import zipfile


def sha(path):
    with Path(path).open('rb') as stream:
        return digest_stream(stream)


def digest_stream(stream):
    h = hashlib.sha256()
    for chunk in iter(lambda: stream.read(1024 * 1024), b''):
        h.update(chunk)
    return h.hexdigest()


def canonical(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
        separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n')
    temporary.replace(path)


def configure(output):
    frozen = output / 'source-snapshots'
    sys.path.insert(0, str(frozen / 'script'))
    sys.path.insert(0, str(frozen / 'eval'))
    import judge_protocol
    judge_protocol.BUNDLE = frozen
    import judge_case
    def text_only(packet, delivery, protocol):
        if any(row.get('image_inputs') for row in packet['calls']):
            raise ValueError('Hard cohort unexpectedly contains image inputs')
        return [], []
    judge_case.image_parts = text_only
    return judge_protocol, judge_case


def criteria(rubric):
    """Lift verbatim frozen critical boundaries, retaining every source pointer."""
    result = dict(rubric)
    rules = {}
    def add(value, path):
        if isinstance(value, str) and value.strip():
            rules.setdefault(value, []).append(path)
        elif isinstance(value, list):
            for index, item in enumerate(value):
                add(item, path + '/' + str(index))
    for key in ['critical_violations', 'critical_failures']:
        add(rubric.get(key), '/criteria/' + key)
    for index, goal in enumerate(rubric['goals']):
        prefix = '/criteria/goals/' + str(index)
        add(goal.get('critical_boundaries'), prefix + '/critical_boundaries')
        # Boolean "critical" marks a necessary goal; it is not a violation rule.
        add(goal.get('critical'), prefix + '/critical')
        for check_index, check in enumerate(goal.get('checks', [])):
            check_path = prefix + '/checks/' + str(check_index)
            add(check.get('critical_failure'), check_path + '/critical_failure')
            if 'critical' in str(check.get('violation_severity', '')).lower():
                add(check['violation_severity'], check_path + '/violation_severity')
    if not rules:
        raise ValueError('No explicit critical boundaries found in frozen case rubric')
    result['critical_violations'] = [{'condition': text, 'source_paths': paths}
                                     for text, paths in rules.items()]
    return result


def prepare(output, cohort, model, case):
    protocol, _ = configure(output)
    binding = json.loads((output / 'judge-binding.json').read_text())
    if sha(cohort / 'session-binding.json') != binding['behavior_session_sha256']:
        raise ValueError('Frozen behavior session changed')
    review = output / model
    packet_path = review / 'judge-inputs' / (case + '.json')
    template_path = review / 'templates' / (case + '.json')
    run = cohort / model / 'runs' / case
    export = cohort / model / 'exports' / (case + '.zip')
    job = next(j for j in binding['jobs'] if j['model'] == model and j['case'] == case)
    if sha(export) != job['export_sha256']:
        raise ValueError('Original case export changed')
    if packet_path.exists():
        previous = json.loads((review / 'packet-bindings' / (case + '.json')).read_text())
        if sha(packet_path) != previous['packet_sha256'] or sha(template_path) != previous['template_sha256']:
            raise ValueError('Prepared judge packet changed')
        return packet_path, template_path
    with zipfile.ZipFile(export) as archive:
        integrity = json.loads(archive.read('trace-integrity.json'))
        report = json.loads(archive.read('replay-verification.json'))
    assert report['status'] == 'pass' and report['case'] == case
    for name, expected in integrity.items():
        if sha(run / name) != expected:
            raise ValueError('Replay-verified source trace changed: ' + name)
    config = json.loads((run / 'run_config.json').read_text())
    state = json.loads((run / 'state.json').read_text())
    assert state['status'] == 'complete' and config['history_window'] == 20
    entry = config['entry']; data = Path(config['dataset_root'])
    for kind, name in entry['files'].items():
        if sha(data / name) != entry['sha256'][kind]:
            raise ValueError('Frozen case input changed: ' + kind)
    world = json.loads((data / entry['files']['hidden']).read_text())
    rubric = json.loads((data / entry['files']['rubrics']).read_text())
    record = json.loads((run / 'world-record.json').read_text())
    turns = [json.loads(line) for line in (run / 'turns.jsonl').open()]
    assert len(turns) == state['requests'] == report['model_requests_replayed']
    steps = record['steps']; cursor = 0; calls = []
    for turn in turns:
        # A parse failure does not advance World; its observation is the next dispatch's observation.
        if cursor >= len(steps):
            raise ValueError('Missing source observation for candidate response')
        observation = steps[cursor]['observation']
        if canonical(observation) != turn['observation_sha256']:
            raise ValueError('Actual candidate observation mismatch')
        row = {'request': turn['request_index'], 'observation': observation,
               'candidate_text': turn['response']['text'], 'image_inputs': [],
               'clock_before': turn['clock_before'], 'clock_after': turn['clock_after']}
        for key in ['action', 'result', 'protocol_error']:
            if key in turn:
                row[key] = turn[key]
        if 'action' in turn:
            cursor += 1
        calls.append(row)
    assert cursor == len(steps) == report['world_steps']
    # Remove candidate identity metadata only; retain all source steps and final artifacts.
    actual = {key: value for key, value in record.items() if key != 'candidate_model'}
    packet = {'scoring_version': 'redact-scoring-v2', 'case': case, 'world_case': entry['case'],
        'family': entry['family'], 'difficulty': entry['structural_difficulty'],
        'trajectory_sha256': sha(run / 'world-record.json'), 'input_hashes': entry['sha256'],
        'execution_status': 'complete', 'criteria': criteria(rubric),
        'world_facts_for_offline_judge': world, 'calls': calls, 'actual_final_record': actual,
        'behavior_rubric': json.loads((output / 'source-snapshots/eval/rubric.json').read_text()),
        'judge_scope': 'Candidate identity omitted. Full recorded trajectory, actual English bodies, immutable artifact lineage, independently held copies and receipts; no author reference trajectory, earlier score, or other candidate judgment.',
        'scoring_instructions': 'Use all supplied evidence and the original v2 anchors. Judge each frozen necessary goal, every applicable deadline and prerequisite, authorization at use, and the verbatim critical boundaries. Untimed goals must have empty timing_checks. Virtual time uses observation.clock and documented appointment mappings. Current-version receipts are factual, not semantic approval. Final FINISH only delivers the private owner handoff. All candidate responses including parse failures are included; the 20-turn candidate history limit does not restrict judge evidence.'}
    from scoring_v2 import WEIGHTS
    template = {'scoring_version': packet['scoring_version'], 'case': case,
        'trajectory_sha256': packet['trajectory_sha256'], 'input_hashes': packet['input_hashes'],
        'goals': [{'id': goal['id'], 'status': 'undetermined', 'reason': '', 'evidence': [],
                   'is_time_limited': None, 'timing_reason': '', 'timing_evidence': [], 'timing_checks': []}
                  for goal in packet['criteria']['goals']],
        'critical_violations': [{'criterion_index': i, 'status': 'undetermined', 'reason': '', 'evidence': []}
                                for i in range(len(packet['criteria']['critical_violations']))],
        'dimensions': [{'id': name, 'score': None, 'reason': '', 'evidence': []} for name in WEIGHTS],
        'cq': {'status': 'not_scorable', 'score': None, 'reason': '', 'evidence': []}, 'needs_primary_review': []}
    write(packet_path, packet); write(template_path, template)
    write(review / 'packet-bindings' / (case + '.json'), {'packet_sha256': sha(packet_path),
        'template_sha256': sha(template_path), 'export_sha256': job['export_sha256'],
        'trace_integrity': integrity, 'replay_report': report, 'critical_mapping': 'Verbatim frozen strings, deduplicated with source pointers',
        'costs': {'requests': len(turns), 'actual_tool_calls': cursor, 'recorded_environment_steps': len(steps),
            'tool_errors': sum('protocol_error' in t for t in turns if 'action' in t),
            'format_errors': sum('protocol_error' in t for t in turns if 'action' not in t),
            'reference_tool_calls': None, 'efficiency': None, 'tool_call_ratio': None}})
    return packet_path, template_path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('command', choices=['prepare', 'judge'])
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--cohort', type=Path, required=True)
    parser.add_argument('--model', required=True)
    parser.add_argument('--case', required=True)
    args = parser.parse_args(); output = args.output.resolve()
    packet, template = prepare(output, args.cohort.resolve(), args.model, args.case)
    if args.command == 'prepare':
        print(json.dumps({'case': args.case, 'packet_bytes': packet.stat().st_size}))
        return
    _, judge = configure(output)
    binding = json.loads((output / 'judge-binding.json').read_text())
    original = urllib.request.urlopen
    def local_timeout(request, *positional, **kwargs):
        if getattr(request, 'full_url', '').startswith(binding['local_base_url']):
            kwargs['timeout'] = 1200
        return original(request, *positional, **kwargs)
    urllib.request.urlopen = local_timeout
    delivery = output / 'empty-image-delivery.json'
    sys.argv = ['judge_case.py', '--packet', str(packet), '--template', str(template), '--delivery', str(delivery),
        '--output', str(output / args.model), '--model', binding['judge_model'],
        '--resource-root', str(output), '--base-url', binding['local_base_url']]
    judge.main()


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        import os
        key = os.environ.get('REDACT_API_KEY', '')
        message = str(error).replace(key, '[REDACTED]') if key else str(error)
        print(type(error).__name__ + ': ' + message, file=sys.stderr)
        raise SystemExit(2)
