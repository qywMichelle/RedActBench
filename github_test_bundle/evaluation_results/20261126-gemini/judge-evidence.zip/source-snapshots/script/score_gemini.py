"""Score completed Gemini traces using the original v2 rubric and API judge protocol."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import csv
import fcntl
import getpass
import hashlib
import json
import os
from pathlib import Path
import queue
import signal
import subprocess
import sys
import threading
import time
import uuid
import zipfile

ROOT = Path(__file__).resolve().parent.parent
BUNDLE = ROOT / 'github_test_bundle'
PYTHON = BUNDLE / '.venv/bin/python'
sys.path.insert(0, str(BUNDLE / 'eval'))
sys.path.insert(0, str(ROOT / 'script'))
import judge_protocol
judge_protocol.BUNDLE = BUNDLE
from scoring_v2 import aggregate

MIB = 1024 * 1024
STOP = threading.Event()


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(data, ensure_ascii=False, separators=(',', ':'), allow_nan=False) + '\n')
    temp.replace(path)


def rss(pid):
    try:
        return next(int(s.split()[1]) * 1024 for s in Path(f'/proc/{pid}/status').read_text().splitlines() if s.startswith('VmRSS:'))
    except (OSError, StopIteration):
        return 0


def alive(pid):
    try:
        return not any(s.startswith('State:') and '\tZ' in s for s in Path(f'/proc/{pid}/status').read_text().splitlines())
    except OSError:
        return False


class Coordinator:
    def __init__(self, args, plan):
        self.args, self.plan = args, plan
        self.output, self.directory = args.output.resolve(), args.directory.resolve()
        self.model = plan['model']
        self.children, self.pending = {}, []
        self.condition = threading.Condition()
        self.prepare_guard = threading.Lock()
        self.state_guard = threading.Lock()
        self.workers, self.failed = {}, {}
        self.peak = 0
        pilot_file = self.output / 'initial-pilot.json'
        self.pilot = json.loads(pilot_file.read_text()) if pilot_file.exists() else {}
        pairs = json.loads((BUNDLE / 'data/current-counterfactual-manifest.json').read_text())['episodes']
        self.variants = {e['case']: e['configuration'] for e in pairs}

    def execute(self, command, charge, log):
        ticket = uuid.uuid4().hex
        with self.condition:
            self.pending.append(ticket)
            while not STOP.is_set():
                external = max(128 * MIB, rss(self.pilot['pid'])) if self.pilot.get('pid') and alive(self.pilot['pid']) else 0
                current = rss(os.getpid()) + external + sum(max(value, rss(pid)) for pid, value in self.children.items())
                if self.pending[0] == ticket and current + charge <= self.args.memory_mib * MIB:
                    break
                self.condition.wait(timeout=1)
            self.pending.remove(ticket)
            if STOP.is_set():
                self.condition.notify_all()
                return 130
            with log.open('a') as stream:
                child = subprocess.Popen(['prlimit', '--as=536870912', '--core=0', '--', *map(str, command)],
                    cwd=ROOT, env=dict(os.environ, MALLOC_ARENA_MAX='2', PYTHONUNBUFFERED='1',
                                      GEMINI_JUDGE_IMAGE_CACHE=str(self.directory / 'image-cache')),
                    stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT)
            self.children[child.pid] = charge
            self.condition.notify_all()
        try:
            while child.poll() is None:
                if STOP.wait(1):
                    child.terminate()
                    try:
                        child.wait(timeout=15)
                    except subprocess.TimeoutExpired:
                        child.kill()
                    break
            return child.wait()
        finally:
            with self.condition:
                self.children.pop(child.pid, None)
                self.condition.notify_all()

    def heavy(self, command, log):
        # The memory token is granted before the child acquires the image-work lock.
        wrapper = [PYTHON, ROOT / 'script/gemini_judge_prepare.py', self.output,
                   self.directory / 'image-cache', BUNDLE / 'redact_bench.py', *command]
        with self.prepare_guard:
            return self.execute(wrapper, 512 * MIB, log)

    def worker(self, worker_id, jobs):
        while not STOP.is_set():
            try:
                job = jobs.get_nowait()
            except queue.Empty:
                return
            review = self.output / 'reviews' / job['name']
            run = self.directory / self.model / 'runs' / job['name']
            log = self.output / 'logs' / (job['name'] + '.log')
            log.parent.mkdir(parents=True, exist_ok=True)
            with self.state_guard:
                self.workers[worker_id] = {'shard': job['name'], 'status': 'preparing'}
            packets = list((review / 'judge-inputs').rglob('*.json'))
            if len(packets) != len(job['cases']):
                code = self.heavy(['evaluate', '--run', run, '--output', review, '--prepare'], log)
                if code:
                    with self.state_guard:
                        self.failed[job['name']] = {'shard': job['name'], 'stage': 'prepare', 'exit_code': code}
                    continue
            for case in job['cases']:
                if STOP.is_set():
                    break
                if self.pilot.get('case') == case and self.pilot.get('pid'):
                    while alive(self.pilot['pid']) and not STOP.is_set():
                        with self.state_guard:
                            self.workers[worker_id].update(status='waiting_pilot', case=case)
                        STOP.wait(1)
                    if STOP.is_set():
                        break
                packet = review / 'judge-inputs' / (case + '.json')
                template = review / 'templates' / (case + '.json')
                trajectory = run / 'trajectories' / (case + '.json')
                prepared = json.loads(packet.read_text())
                if prepared['trajectory_sha256'] != sha(trajectory):
                    raise RuntimeError('Prepared review no longer matches the original trajectory: ' + case)
                images = any(c.get('image_inputs') for c in prepared['calls'])
                del prepared
                delivery = review / 'delivery' / (case + '.json')
                write(delivery, {})  # Gemini received original PNG bytes, with no resize ledger.
                command = [PYTHON, ROOT / 'script/gemini_judge_case.py', '--packet', packet,
                           '--template', template, '--delivery', delivery, '--output', review,
                           '--model', self.args.judge_model, '--resource-root', self.output]
                charge = (384 if images else 128) * MIB
                charge += min(64 * MIB, packet.stat().st_size * 4)
                result_path = review / 'case-status' / (case + '.json')
                for attempt in range(3):
                    with self.state_guard:
                        self.workers[worker_id].update(status='judging', case=case, retry=attempt)
                    code = self.execute(command, charge, log)
                    result = json.loads(result_path.read_text()) if result_path.exists() else {}
                    if not code and result.get('status') == 'complete':
                        with self.state_guard:
                            self.failed.pop(case, None)
                        break
                    if STOP.is_set():
                        break
                    if STOP.wait(15 * (attempt + 1)):
                        break
                else:
                    with self.state_guard:
                        self.failed[case] = {'case': case, 'stage': 'judge', 'exit_code': code,
                                             'status': result.get('status', 'missing')}
            if STOP.is_set():
                break
            with self.state_guard:
                self.workers[worker_id]['status'] = 'aggregating'
            code = self.heavy(['evaluate', '--run', run, '--output', review, '--partial'], log)
            with self.state_guard:
                if code:
                    self.failed[job['name']] = {'shard': job['name'], 'stage': 'aggregate', 'exit_code': code}
                else:
                    self.failed.pop(job['name'], None)
                self.workers[worker_id]['status'] = 'finished' if not code else 'needs_attention'
            self.collect()

    def collect(self):
        with self.state_guard:
            completed, needs_review = {}, set()
            for p in (self.output / 'reviews').glob('*/case-status/**/*.json'):
                result = json.loads(p.read_text())
                if result.get('status') == 'complete':
                    completed[result['case']] = result
                    if result.get('needs_primary_review'):
                        needs_review.add(result['case'])
                elif result.get('status') == 'needs_review':
                    needs_review.add(result['case'])
            reports = []
            for p in (self.output / 'reviews').glob('*/metrics-v2.json'):
                report = json.loads(p.read_text())
                if report['overall']['scored_episodes']:
                    reports.append(report)
            rows = [row for report in reports for row in report['rows']]
            if len({r['case'] for r in rows}) != len(rows):
                raise RuntimeError('Duplicate case in official score aggregation')
            with self.condition:
                pilot_alive = self.pilot.get('pid') and alive(self.pilot['pid'])
                memory = rss(os.getpid()) + sum(rss(pid) for pid in self.children) + (rss(self.pilot['pid']) if pilot_alive else 0)
                self.peak = max(self.peak, memory)
                active = len(self.children) + int(bool(pilot_alive))
            failures = [v for k, v in self.failed.items() if k not in completed]
            state = {'status': 'running' if not STOP.is_set() else 'stopping',
                     'judge_model': self.args.judge_model, 'scored_model': self.model,
                     'planned_cases': 615, 'completed_cases': len(completed),
                     'officially_aggregated_shards': sum(
                         r['overall']['scored_episodes'] == r['planned_episodes'] and
                         not any(r.get(k) for k in ['validation_errors', 'unreviewed', 'missing_trajectories', 'quality_excluded'])
                         for r in reports),
                     'needs_primary_review': sorted(needs_review), 'failed_cases': failures,
                     'workers': self.workers, 'maximum_judge_workers': self.args.workers,
                     'active_processes': active, 'rss_mib': round(memory / MIB, 2),
                     'peak_rss_mib': round(self.peak / MIB, 2), 'memory_admission_limit_mib': self.args.memory_mib,
                     'pid': os.getpid(), 'updated_at': time.time()}
            write(self.output / 'status.json', state)
            summary = {'scoring_version': 'redact-scoring-v2', 'status': 'partial',
                'judge_model': self.args.judge_model, 'scored_model': self.model,
                'provisional_automated_scores': True, 'self_evaluation': self.args.judge_model == self.model,
                'human_confirmed': False, 'planned_cases': 615, 'completed_cases': len(completed),
                'overall': aggregate(rows),
                'by_variant': {label: aggregate([r for r in rows if self.variants.get(r['case']) == value])
                    for label, value in [('paired_A', 'A'), ('paired_B', 'B')]},
                'by_family': {key: aggregate([r for r in rows if r['family'] == key]) for key in sorted({r['family'] for r in rows})},
                'needs_primary_review': sorted(needs_review), 'failed_cases': failures,
                'officially_aggregated_shards': state['officially_aggregated_shards'],
                'scoring_complete': len(completed) == 615 and aggregate(rows)['scored_episodes'] == 615 and
                                    state['officially_aggregated_shards'] == 32,
                'interpretation': 'Original project rubric and scorer; API judgments are provisional. Missing reviews are not zero scores.'}
            summary['by_variant']['unpaired_primary'] = aggregate([r for r in rows if r['case'] not in self.variants])
            write(self.output / 'summary.json', summary)
            return state, summary

    def finish(self, state, summary):
        done = summary['scoring_complete'] and not state['failed_cases']
        state['status'] = 'stopped' if STOP.is_set() else ('scoring_complete' if done else 'needs_attention')
        summary['status'] = 'partial' if summary['needs_primary_review'] or not done else 'complete'
        write(self.output / 'status.json', state)
        write(self.output / 'summary.json', summary)
        if not done:
            return
        rows = ['# Gemini 3.8 Flash 全量自动评分', '',
                f"615/615 个配置已评分，裁判 `{self.args.judge_model}`，被测模型 `{self.model}`。", '',
                '使用原项目 v2 rubric 和官方评分器；这是模型裁判评分，尚未人工确认。', '',
                '| 数据 | 数量 | GCR | TSR | LCR | 六维总分 |', '|---|---:|---:|---:|---:|---:|']
        for label, values in [('总体', summary['overall']), ('配对 A', summary['by_variant']['paired_A']),
                              ('配对 B', summary['by_variant']['paired_B']), ('无配对主情境', summary['by_variant']['unpaired_primary'])]:
            rows.append(f"| {label} | {values['scored_episodes']} | {values['GCR']:.2f}% | {values['TSR']:.2f}% | {values['LCR']:.2f}% | {values['six_dimension_total']:.2f}/100 |")
        rows += ['', f"{len(summary['needs_primary_review'])} 个配置待人工复核；自动裁判判定关键违规 {summary['overall']['critical_violation_n']} 个配置。CQ 无校准锚点，保持 null。", '',
                 '全部维度、目标状态、实际证据、裁判可见响应、版本与 SHA 绑定保存在本目录。超长图片仅做完整覆盖的无损分块；Gemini 候选轨迹和图片输入没有改动。']
        (self.output / 'score-report.md').write_text('\n'.join(rows) + '\n')
        archive = self.output / 'judge-evidence.zip'
        if not archive.exists():
            with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED) as z:
                for p in sorted(self.output.rglob('*')):
                    if not p.is_file() or p == archive:
                        continue
                    rel = p.relative_to(self.output)
                    if (len(rel.parts) == 1 and p.suffix in {'.json', '.md'}) or any(x in rel.parts for x in ['judgments', 'raw-responses', 'case-status', 'source-snapshots']) or p.name in {'metrics-v2.json', 'per-episode-v2.csv', 'scoring-config.json'}:
                        z.write(p, str(rel))

    def run(self):
        threading.stack_size(MIB)
        lifetime = (self.output / '.coordinator.lock').open('a+')
        fcntl.flock(lifetime, fcntl.LOCK_EX | fcntl.LOCK_NB)
        jobs = queue.Queue()
        for job in self.plan['jobs']:
            jobs.put(job)
        with ThreadPoolExecutor(max_workers=self.args.workers) as pool:
            futures = [pool.submit(self.worker, str(i), jobs) for i in range(self.args.workers)]
            while any(not f.done() for f in futures):
                self.collect()
                STOP.wait(5)
            for future in futures:
                future.result()
        self.finish(*self.collect())


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--directory', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--judge-model', default='gpt-6.1-sol-science')
    p.add_argument('--workers', type=int, default=8)
    p.add_argument('--memory-mib', type=int, default=1280)
    p.add_argument('--foreground', action='store_true')
    args = p.parse_args()
    if not 1 <= args.workers <= 8 or not 768 <= args.memory_mib <= 1536:
        p.error('Workers must be 1..8 and memory admission budget 768..1536 MiB')
    args.directory, args.output = args.directory.resolve(), args.output.resolve()
    args.output.mkdir(parents=True, exist_ok=True)
    plan = json.loads((args.directory / 'plan.json').read_text())
    files = [Path(__file__), ROOT / 'script/gemini_judge_case.py', ROOT / 'script/gemini_judge_prepare.py',
             ROOT / 'script/judge_case.py', ROOT / 'script/judge_protocol.py', ROOT / 'script/judge_packet_codec.py',
             ROOT / 'script/gemini_memory_child.py', BUNDLE / 'eval/scoring_v2.py',
             BUNDLE / 'eval/rubric.json', BUNDLE / 'eval/review_current_local.py', BUNDLE / 'SHA256SUMS.json']
    binding = {'schema': 'redact-gemini-api-judge-v1', 'judge_model': args.judge_model, 'scored_model': plan['model'],
               'system_prompt_sha256': hashlib.sha256(judge_protocol.SYSTEM.encode()).hexdigest(),
               'sources': {str(f.relative_to(ROOT)): sha(f) for f in files},
               'source_manifests': {j['name']: sha(args.directory / plan['model'] / 'runs' / j['name'] / 'frozen-manifest.json') for j in plan['jobs']},
               'max_output_tokens': 16384, 'api_base': 'https://mp.z01.normandyfunc.com/v1',
               'maximum_workers': args.workers, 'memory_admission_limit_mib': args.memory_mib,
               'per_process_address_space_limit_mib': 512, 'provisional_automated_scores': True,
               'self_evaluation': args.judge_model == plan['model'], 'reference_trajectories_in_prompt': False,
               'image_policy': 'Actual candidate-visible pixels; oversized images use lossless overlapping tiles'}
    previous = args.output / 'judge-binding.json'
    if previous.exists() and json.loads(previous.read_text()) != binding:
        raise RuntimeError('Judge configuration/source binding changed')
    write(previous, binding)
    snapshot = args.output / 'source-snapshots'
    for f in files:
        target = snapshot / f.relative_to(ROOT)
        target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists():
            target.write_bytes(f.read_bytes())
    key = os.environ.get('REDACT_API_KEY')
    if not key:
        if args.foreground or not sys.stdin.isatty():
            raise RuntimeError('Provider key missing from inherited environment')
        key = getpass.getpass('Provider API key (hidden): ')
    if not args.foreground:
        unit = 'redactbench-gemini-judge-' + str(time.time_ns())
        command = ['systemd-run', '--user', '--scope', '--unit=' + unit,
                   '--property=MemoryMax=1536M', '--property=MemorySwapMax=0', '--property=CPUWeight=20',
                   'prlimit', '--as=536870912', '--core=0', '--', str(PYTHON), str(Path(__file__)),
                   '--foreground', '--directory', str(args.directory), '--output', str(args.output),
                   '--judge-model', args.judge_model, '--workers', str(args.workers), '--memory-mib', str(args.memory_mib)]
        with (args.output / 'supervisor.log').open('a') as log:
            child = subprocess.Popen(command, cwd=ROOT, env=dict(os.environ, REDACT_API_KEY=key, MALLOC_ARENA_MAX='2', PYTHONUNBUFFERED='1'),
                stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        write(args.output / 'launcher.json', {'pid': child.pid, 'unit': unit + '.scope', 'started_at': time.time(),
              'judge_model': args.judge_model, 'scored_model': plan['model'], 'maximum_workers': args.workers})
        print(json.dumps({'status': 'launched', 'pid': child.pid, 'output': str(args.output), 'judge_model': args.judge_model}))
        return
    signal.signal(signal.SIGINT, lambda *_: STOP.set())
    signal.signal(signal.SIGTERM, lambda *_: STOP.set())
    try:
        Coordinator(args, plan).run()
    except Exception as exc:
        STOP.set()
        write(args.output / 'status.json', {'status': 'needs_attention', 'error': str(exc).replace(key, '[REDACTED]')[:1000], 'updated_at': time.time()})
        raise SystemExit(2)


if __name__ == '__main__':
    main()
