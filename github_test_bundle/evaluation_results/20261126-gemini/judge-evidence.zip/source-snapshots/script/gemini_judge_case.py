"""Use the original judge protocol with Gemini run paths and lossless image tiles."""
import base64
import io
import json
import math
from pathlib import Path
import struct
import sys

ROOT = Path(__file__).resolve().parent.parent
BUNDLE = ROOT / 'github_test_bundle'
sys.path.insert(0, str(BUNDLE / 'eval'))
sys.path.insert(0, str(ROOT / 'script'))
import judge_protocol
judge_protocol.BUNDLE = BUNDLE
import judge_case
import run_judge
run_judge.ENTRY = BUNDLE / 'redact_bench.py'
run_judge.PYTHON = BUNDLE / '.venv/bin/python'


def lossless_tiles(parts, metadata):
    """Preserve every original image pixel; split only images exceeding proxy limits."""
    from PIL import Image
    import hashlib
    result = []
    for part in parts:
        if part.get('type') != 'input_image':
            result.append(part)
            continue
        encoded = part['image_url'].split(',', 1)[1]
        data = base64.b64decode(encoded)
        width, height = struct.unpack('>II', data[16:24])
        if math.ceil(width / 32) * math.ceil(height / 32) <= 29900 and len(encoded) <= 9 * 1024 * 1024:
            result.append(part)
            continue
        original_sha = hashlib.sha256(data).hexdigest()
        tile_metadata = []
        with Image.open(io.BytesIO(data)) as image:
            rectangles = [(left, top, min(width, left + 4096), min(height, top + 4096))
                          for top in range(0, height, 4080) for left in range(0, width, 4080)]
            for index, rectangle in enumerate(rectangles, 1):
                with image.crop(rectangle) as tile:
                    output = io.BytesIO()
                    tile.save(output, format='PNG', compress_level=6)
                    pixels_sha = hashlib.sha256(tile.tobytes()).hexdigest()
                    png = output.getvalue()
                tile_metadata.append({'rectangle': list(rectangle), 'png_sha256': hashlib.sha256(png).hexdigest(),
                                      'pixel_sha256': pixels_sha})
                label = {'judge_image_view': 'lossless_overlapping_tile', 'tile': index,
                         'total_tiles': len(rectangles), 'rectangle': list(rectangle),
                         'full_canvas_size': [width, height], 'original_png_sha256': original_sha,
                         'full_canvas_covered': True,
                         'interpretation': 'All tiles are parts of the same original candidate-visible image; every pixel is preserved.'}
                result.extend([{'type': 'input_text', 'text': json.dumps(label, separators=(',', ':'))},
                               {'type': 'input_image', 'image_url': 'data:image/png;base64,' + base64.b64encode(png).decode()}])
        for item in metadata:
            if item.get('transmitted_png_sha256') == original_sha:
                item.update(judge_view='lossless_overlapping_tiles', full_canvas_size=[width, height], tiles=tile_metadata)
    return result, metadata


def main():
    # Keep original scorer and judge source files intact; only repair relocated paths.
    import evidence_images
    import gemini_memory_child
    cache = Path(__import__('os').environ['GEMINI_JUDGE_IMAGE_CACHE'])
    gemini_memory_child.install_image_cache(type('Bench', (), {'ROOT': BUNDLE, 'images': evidence_images}), cache)
    original = judge_case.image_parts

    def image_parts(packet, delivery, protocol):
        parts, metadata = original(packet, delivery, protocol)
        return lossless_tiles(parts, metadata) if protocol == 'responses' else (parts, metadata)

    judge_case.image_parts = image_parts
    sys.argv = [str(ROOT / 'script/judge_case.py'), *sys.argv[1:]]
    try:
        judge_case.main()
    except Exception as exc:
        key = __import__('os').environ.get('REDACT_API_KEY', '')
        message = str(exc).replace(key, '[REDACTED]') if key else str(exc)
        print(type(exc).__name__ + ': ' + message, file=sys.stderr)
        raise SystemExit(2)


if __name__ == '__main__':
    main()
