"""Grant memory first, then serialize the unchanged official review preparation."""
import fcntl
from pathlib import Path
import sys


def main():
    if len(sys.argv) < 5:
        raise SystemExit('Usage: gemini_judge_prepare.py RESOURCE_ROOT IMAGE_CACHE BENCH_ENTRY COMMAND ...')
    resource, cache, entry = Path(sys.argv[1]), sys.argv[2], sys.argv[3]
    resource.mkdir(parents=True, exist_ok=True)
    with (resource / '.judge-heavy.lock').open('a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        sys.argv = [sys.argv[0], cache, entry, *sys.argv[4:]]
        import gemini_memory_child
        gemini_memory_child.main()


if __name__ == '__main__':
    main()
