"""Run the unchanged benchmark with byte-verified PNG caching and one renderer."""
from collections import OrderedDict
import fcntl
import functools
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

CACHE_LIMIT = 16 * 1024 * 1024


def install_image_cache(bench, directory):
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    original = bench.images.image_bytes
    uncached = getattr(original, '__wrapped__', original)
    renderer_binding = hashlib.sha256((bench.ROOT / 'eval/evidence_images.py').read_bytes()).hexdigest()
    cache, used = OrderedDict(), 0

    @functools.wraps(original)
    def image_bytes(path, expected):
        nonlocal used
        path = Path(path)
        source = path.read_bytes()
        if hashlib.sha256(source).hexdigest() != expected:
            raise ValueError('Image changed after input verification')
        key = hashlib.sha256((str(path.resolve()) + expected + renderer_binding).encode()).hexdigest()
        if key in cache:
            value = cache.pop(key)
            cache[key] = value
            return value
        with (directory / '.render.lock').open('a+') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            png, metadata = directory / (key + '.png'), directory / (key + '.json')
            if png.exists() and metadata.exists():
                binding = json.loads(metadata.read_text())
                value = png.read_bytes()
                if (binding.get('source_sha256') != expected or
                        binding.get('renderer_source_sha256') != renderer_binding or
                        hashlib.sha256(value).hexdigest() != binding.get('png_sha256')):
                    raise ValueError('Shared image cache integrity mismatch')
            else:
                # This is the original scale=2 rendering function, unchanged.
                del source
                value = uncached(str(path), expected)
                temporary = png.with_suffix('.tmp')
                temporary.write_bytes(value)
                temporary.replace(png)
                metadata_temp = metadata.with_suffix('.tmp.json')
                metadata_temp.write_text(json.dumps({'source_sha256': expected,
                    'renderer_source_sha256': renderer_binding,
                    'png_sha256': hashlib.sha256(value).hexdigest(), 'source_path': str(path.resolve())}) + '\n')
                metadata_temp.replace(metadata)
            if not value.startswith(b'\x89PNG\r\n\x1a\n'):
                raise ValueError('Invalid cached PNG evidence')
        if len(value) <= CACHE_LIMIT:
            while cache and used + len(value) > CACHE_LIMIT:
                _, previous = cache.popitem(last=False)
                used -= len(previous)
            cache[key] = value
            used += len(value)
        return value

    def clear():
        nonlocal used
        cache.clear()
        used = 0
        original.cache_clear()

    image_bytes.cache_clear = clear
    image_bytes.cache_info = original.cache_info
    bench.images.image_bytes = image_bytes


def main():
    if len(sys.argv) < 4:
        raise SystemExit('Usage: gemini_memory_child.py CACHE_DIRECTORY BENCH_ENTRY COMMAND ...')
    cache_directory, entry = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
    sys.argv = [str(entry), *sys.argv[3:]]
    spec = importlib.util.spec_from_file_location('redact_gemini_memory_child', entry)
    bench = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bench)
    install_image_cache(bench, cache_directory)
    bench.main()


if __name__ == '__main__':
    main()
