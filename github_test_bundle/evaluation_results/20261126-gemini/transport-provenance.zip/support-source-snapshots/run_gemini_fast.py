"""Resume the bound Gemini evaluation with more workers and bounded image rendering."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import getpass
import importlib.util
import json
import os
from pathlib import Path
import queue
import signal
import subprocess
import sys
import threading
import time
from types import SimpleNamespace
import zipfile
import hashlib

ROOT = Path(__file__).resolve().parent.parent
ORIGINAL = ROOT / 'script/run_gemini_eval.py'
CHILD = ROOT / 'script/gemini_memory_child.py'
MIB = 1024 * 1024
spec = importlib.util.spec_from_file_location('bound_gemini_supervisor', ORIGINAL)
bound = importlib.util.module_from_spec(spec)
spec.loader.exec_module(bound)


def verified_export(directory, model, job):
    run = directory / model / 'runs' / job['name']
    archive = directory / model / 'exports' / (job['name'] + '.zip')
    if not archive.exists():
        return False
    try:
        with zipfile.ZipFile(archive) as z:
            report = json.loads(z.read('replay-verification.json'))
            if report['status'] != 'pass' or report['missing_cases'] or set(report['cases']) != set(job['cases']):
                raise ValueError('Existing export coverage differs: ' + job['name'])
            for relative, expected in json.loads(z.read('trace-integrity.json')).items():
                path = run / relative
                if (Path(relative).is_absolute() or '..' in Path(relative).parts or path.is_symlink() or
                        not path.resolve().is_relative_to(run.resolve()) or bound.sha(path) != expected or
                        hashlib.sha256(z.read(relative)).hexdigest() != expected):
                    raise ValueError('Existing export bytes differ: ' + job['name'])
    except zipfile.BadZipFile:
        # A stopped exporter may leave an incomplete ZIP. Preserve it for inspection.
        quarantine = archive.parent / 'incomplete'
        quarantine.mkdir(exist_ok=True)
        archive.replace(quarantine / (archive.stem + '-' + str(time.time_ns()) + '.zip'))
        return False
    return True


class FastSupervisor(bound.Supervisor):
    def __init__(self, args, key, jobs):
        super().__init__(args, key, jobs)
        previous_state = json.loads((self.directory / 'status.json').read_text())
        previous_pacing = previous_state.get('pacing', {})
        self.bridge.pacer.interval = max(.05, min(30., float(previous_pacing.get('interval_seconds', .25))))
        self.bridge.pacer.limited = int(previous_pacing.get('rate_limits', 0))
        self.cache_directory = self.directory / 'image-cache'
        self.cache_directory.mkdir(exist_ok=True, mode=0o700)
        self.original_jobs = jobs
        self.jobs = []
        for job in jobs:
            if verified_export(self.directory, args.model, job):
                self.results[job['name']] = 'exported'
            else:
                self.jobs.append(dict(job, reserved_memory_mib=72))

    def memory(self):
        actual, reserved = super().memory()
        # All renders share one process lock. Only one renderer needs peak headroom.
        return actual, reserved + 320 * MIB

    def save(self):
        super().save()
        with self.condition:
            state = json.loads((self.directory / 'status.json').read_text())
            state.update(acceleration='shared-png-cache-12-workers-v1',
                         image_rendering_serialized=True, renderer_headroom_mib=320,
                         per_child_base_reservation_mib=72)
            bound.atomic(self.directory / 'status.json', state)

    def execute(self, command, charge, log, worker_id):
        wrapped = [command[0], str(CHILD), str(self.cache_directory), command[1], *command[2:]]
        return super().execute(wrapped, 72 * MIB, log, worker_id)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, required=True)
    parser.add_argument('--workers', type=int, default=12)
    parser.add_argument('--foreground', action='store_true')
    args = parser.parse_args()
    if not 8 <= args.workers <= 12:
        parser.error('Workers must be 8..12')
    directory = args.directory.resolve()
    plan = json.loads((directory / 'plan.json').read_text())
    if bound.sha(ORIGINAL) != plan['supervisor_source_sha256']:
        raise RuntimeError('Original supervisor source changed')
    if bound.sha(bound.BUNDLE / 'SHA256SUMS.json') != plan['frozen_inventory_sha256']:
        raise RuntimeError('Frozen benchmark inventory changed')
    binding = {'version': 'shared-png-cache-12-workers-v1', 'workers': args.workers,
               'rss_admission_limit_mib': plan['rss_admission_limit_mib'],
               'per_process_address_space_limit_mib': 512,
               'renderer_headroom_mib': 320, 'per_child_base_reservation_mib': 72,
               'image_cache_per_child_limit_mib': 16, 'malloc_arena_max': 2,
               'original_plan_sha256': bound.sha(directory / 'plan.json'),
               'original_supervisor_sha256': bound.sha(ORIGINAL),
               'acceleration_source_sha256': bound.sha(Path(__file__)),
               'child_wrapper_source_sha256': bound.sha(CHILD),
               'model_visible_request_changed': False, 'model_budgets_changed': False}
    path = directory / 'acceleration-binding.json'
    if path.exists() and json.loads(path.read_text()) != binding:
        raise RuntimeError('Acceleration source/configuration changed')
    key = os.environ.get(plan['api_key_env']) or os.environ.get('REDACT_API_KEY')
    if not key:
        if args.foreground or not sys.stdin.isatty():
            raise RuntimeError('Missing provider key in inherited environment')
        key = getpass.getpass('Provider API key (hidden): ')
    if not args.foreground:
        state = json.loads((directory / 'status.json').read_text())
        if state.get('pid') and Path('/proc/' + str(state['pid'])).exists():
            raise RuntimeError('Original supervisor is still active; stop it gracefully before acceleration')
        bound.atomic(path, binding)
        env = dict(os.environ, REDACT_API_KEY=key, MALLOC_ARENA_MAX='2', PYTHONUNBUFFERED='1')
        env[plan['api_key_env']] = key
        unit = 'redactbench-gemini38-fast-' + str(time.time_ns())
        command = ['systemd-run', '--user', '--scope', '--unit=' + unit,
                   '--property=MemoryMax=1536M', '--property=MemorySwapMax=0', '--property=CPUWeight=20',
                   'prlimit', '--as=536870912', '--core=0', '--', str(bound.PYTHON), str(Path(__file__)),
                   '--foreground', '--directory', str(directory), '--workers', str(args.workers)]
        with (directory / 'supervisor-fast.log').open('a') as log:
            child = subprocess.Popen(command, cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                                     stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        bound.atomic(directory / 'launcher.json', {'launcher_pid': child.pid, 'systemd_unit': unit + '.scope',
            'directory': str(directory), 'workers': args.workers, 'rss_admission_limit_mib': plan['rss_admission_limit_mib'],
            'malloc_arena_max': 2, 'systemd_memory_max_mib': 1536, 'systemd_limit_verified': False,
            'supervisor_log': 'supervisor-fast.log', 'started_at': time.time()})
        print(json.dumps({'status': 'launched', 'pid': child.pid, 'workers': args.workers, 'directory': str(directory)}))
        return
    bound.atomic(path, binding)
    os.environ['REDACT_API_KEY'] = key
    signal.signal(signal.SIGTERM, lambda *_: bound.STOP.set())
    signal.signal(signal.SIGINT, lambda *_: bound.STOP.set())
    settings = SimpleNamespace(directory=directory, model=plan['model'], port=plan['local_port'],
        protocol=plan['protocol'].split('-')[0], upstream_endpoint=plan['upstream_endpoint'],
        concurrency=args.workers, rss_limit_mib=plan['rss_admission_limit_mib'])
    try:
        FastSupervisor(settings, key, plan['jobs']).run()
    except Exception as exc:
        bound.STOP.set()
        bound.atomic(directory / 'status.json', {'status': 'needs_attention', 'model': plan['model'],
                     'error': str(exc).replace(key, '[REDACTED]')[:1000], 'updated_at': time.time()})
        raise SystemExit(2)


if __name__ == '__main__':
    main()
