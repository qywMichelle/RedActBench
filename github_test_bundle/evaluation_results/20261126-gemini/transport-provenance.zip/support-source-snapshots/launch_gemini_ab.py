"""Start a fresh full Gemini A/B run using the already verified bounded runner."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import socket
import sys
import time

PROJECT = Path('/data/project/RedActBench')
sys.path.insert(0, str(PROJECT / 'script'))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temporary.replace(path)


def prepare(directory):
    import run_gemini_eval as original
    model = 'gemini-3.8-flash-lucas'
    endpoint = 'https://mp.z01.normandyfunc.com/gemini/v1beta/models/gemini-3.8-flash-lucas:generateContent'
    diagnostics = json.loads((directory / 'api-diagnostics.json').read_text())
    selected = next(row for row in diagnostics['results'] if row['model'] == model and
                    row['protocol'] == 'gemini' and row.get('compatible') and row['status'] == 200)
    if selected['reported_model'] != 'gemini-3.8-flash':
        raise ValueError('Unexpected reported Gemini model version')
    old_argv = sys.argv
    sys.argv = [str(PROJECT / 'script/run_gemini_eval.py'), '--directory', str(directory),
                '--model', model, '--protocol', 'gemini', '--upstream-endpoint', endpoint,
                '--concurrency', '12', '--rss-limit-mib', '1280', '--port', '18839', '--prepare']
    try:
        original.main()
    finally:
        sys.argv = old_argv
    write(directory / 'api-preflight.json', selected)
    write(directory / 'connection-resolution.json', {'selected_model': model,
        'reported_model': selected['reported_model'], 'selected_protocol': 'gemini', 'endpoint': endpoint,
        'reason': 'Use the same route as the earlier 615-case Gemini run. The supplied key supports native Gemini; Gemini aliases reject OpenAI chat.',
        'api_key_source': 'Hidden input, subsequently transferred via an ephemeral Unix socket',
        'configuration_count': 615, 'independent_primary_cases': 400, 'paired_A': 215, 'paired_B': 215,
        'unpaired_primary': 185, 'previous_run': 'gemini38-flash-20261123', 'created_at': time.time()})
    sources = {}
    for name in ['run_gemini_eval.py', 'run_gemini_fast.py', 'gemini_memory_child.py', 'launch_gemini_ab.py']:
        source = PROJECT / 'script' / name; destination = directory / 'support-source-snapshots' / name
        destination.parent.mkdir(parents=True, exist_ok=True); shutil.copyfile(source, destination); sources[name] = sha(source)
    write(directory / 'launch-binding.json', {'sources': sources, 'workers': 12,
        'original_plan_sha256': sha(directory / 'plan.json'), 'memory_admission_limit_mib': 1280,
        'image_rendering_serialized': True, 'renderer_headroom_mib': 320,
        'per_process_address_space_limit_mib': 512, 'previous_results_reused': False})
    (directory / 'README.md').write_text('# Gemini 3.8 Flash 主情境与 A/B 重新测试\n\n'
        '用户于2026-11-26授权用新key重新运行400道主情境及其215个B配置，总计615次：215对A/B，另有185道无配对主情境。'
        '旧gemini38-flash-20261123结果保留，本轮使用新目录、全部重新调用。\n\n'
        'OpenAI Chat接口明确不支持Gemini别名；Gemini原生端点已通过实测。沿用旧轮的gemini-3.8-flash-lucas路由，'
        '实报模型gemini-3.8-flash。请求仅包含已揭示观察、公开工具协议和原官方History编码；隐藏世界、rubric和作者参考轨迹不加入候选输入。\n\n'
        '使用原官方redact_bench.py入口、相同max output16384、每题max requests200、输入上限200000字符、temperature1、topP0.95、seed0。'
        '12个工作者，RSS准入1280 MiB，每进程地址空间512 MiB，图片使用原像素与SHA校验的共享PNG缓存并串行渲染。\n\n'
        'status.json提供进度和内存；plan.json绑定615个选择；connection-resolution.json保存协议诊断；'
        'upstream-requests.jsonl保存路由、模型、请求SHA、usage、错误与延迟；gemini-3.8-flash-lucas/runs保存完整轨迹，'
        'exports保存通过check-run的导出ZIP。全部完成后生成all615.zip。本轮当前仅运行行为测试。\n')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--directory', type=Path, required=True)
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--credential-socket')
    args = parser.parse_args(); directory = args.directory.resolve()
    if args.prepare:
        prepare(directory)
        return
    binding = json.loads((directory / 'launch-binding.json').read_text())
    for name, expected in binding['sources'].items():
        if sha(PROJECT / 'script' / name) != expected:
            raise ValueError('Bound launch source changed: ' + name)
    if not args.credential_socket:
        raise ValueError('An authorized credential socket is required')
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
        client.connect(args.credential_socket); key = bytearray()
        while len(key) <= 1024:
            chunk = client.recv(1024)
            if not chunk:
                break
            key.extend(chunk)
    if not key or len(key) > 1024:
        raise ValueError('Credential delivery failed')
    os.environ['REDACT_API_KEY'] = key.decode()
    import run_gemini_fast
    sys.argv = [str(PROJECT / 'script/run_gemini_fast.py'), '--directory', str(directory), '--workers', '12', '--foreground']
    run_gemini_fast.main()


if __name__ == '__main__':
    main()
