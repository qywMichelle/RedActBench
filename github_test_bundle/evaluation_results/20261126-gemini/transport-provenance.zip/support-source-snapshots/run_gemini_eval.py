"""Run the frozen 615 configurations through the existing provider, with bounded concurrency."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
import getpass
import hashlib
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import queue
import signal
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import urllib.parse
import zipfile

ROOT = Path(__file__).resolve().parent.parent
BUNDLE = ROOT / 'github_test_bundle'
PYTHON = BUNDLE / '.venv/bin/python'
MIB = 1024 * 1024
UPSTREAM = 'https://mp.z01.normandyfunc.com/v1'
TERMINAL = {'complete', 'request_limit', 'action_budget_exhausted', 'input_budget_exceeded'}
STOP = threading.Event()


def atomic(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n')
    temp.replace(path)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def make_plan():
    paired = json.loads((BUNDLE / 'data/current-counterfactual-manifest.json').read_text())['episodes']
    main = json.loads((BUNDLE / 'data/current-english-manifest.json').read_text())['episodes']
    paired_bases = {e['base_case'] for e in paired}
    groups = [('paired', paired), ('unpaired', [e for e in main if e['case'] not in paired_bases])]
    jobs = []
    for label, entries in groups:
        for start in range(0, len(entries), 20):
            selected = entries[start:start + 20]
            packages = {BUNDLE / 'data' / Path(e['package_manifest']).parent for e in selected}
            has_images = any(any((p / 'assets').rglob('*.svg')) or any((p / 'assets').rglob('*.png')) for p in packages)
            jobs.append({'name': f'{label}-{start // 20:03d}', 'paired': label == 'paired',
                         'cases': [e['case'] for e in selected], 'has_images': has_images,
                         'reserved_memory_mib': 512 if has_images else 128})
    assert len(jobs) == 32 and len({c for j in jobs for c in j['cases']}) == 615
    return jobs


def process_memory(pid):
    """Read only this evaluation's process memory, never process environments."""
    try:
        lines = Path(f'/proc/{pid}/status').read_text().splitlines()
        return next(int(s.split()[1]) * 1024 for s in lines if s.startswith('VmRSS:'))
    except (OSError, StopIteration):
        return 0


class Pacer:
    def __init__(self):
        self.lock = threading.Lock()
        self.interval, self.next_slot, self.cooldown = .25, 0., 0.
        self.successes = self.limited = 0

    def acquire(self):
        started = time.monotonic()
        while not STOP.is_set():
            with self.lock:
                now = time.monotonic()
                ready = max(self.next_slot, self.cooldown)
                if now >= ready:
                    self.next_slot = now + self.interval
                    return now - started
            STOP.wait(min(.25, max(.01, ready - now)))
        raise InterruptedError('Supervisor stopped')

    def notice(self, status):
        with self.lock:
            if status == 429:
                self.limited += 1
                self.successes = 0
                self.interval = min(30., max(1., self.interval * 2))
                self.cooldown = max(self.cooldown, time.monotonic() + max(10., self.interval))
            elif status == 200:
                self.successes += 1
                if self.successes >= 20:
                    self.interval = max(.05, self.interval * .8)
                    self.successes = 0

    def snapshot(self):
        with self.lock:
            return {'interval_seconds': self.interval, 'rate_limits': self.limited}


class Bridge(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, key, directory, port, upstream=UPSTREAM, protocol='openai', endpoint=None):
        super().__init__(('127.0.0.1', port), Handler)
        self.key, self.directory, self.upstream = key, directory, upstream
        self.protocol = protocol
        self.endpoint = endpoint or upstream + '/chat/completions'
        self.local_path = '/v1beta/models/:generateContent' if protocol == 'gemini' else '/v1/chat/completions'
        self.pacer, self.guard = Pacer(), threading.Lock()
        self.upload_condition = threading.Condition()
        self.upload_used = 0

    @contextmanager
    def upload(self, length):
        charge = min(64 * MIB, max(MIB, length * 6))
        with self.upload_condition:
            self.upload_condition.wait_for(lambda: self.upload_used + charge <= 64 * MIB or STOP.is_set())
            if STOP.is_set():
                raise InterruptedError('Supervisor stopped')
            self.upload_used += charge
        try:
            yield
        finally:
            with self.upload_condition:
                self.upload_used -= charge
                self.upload_condition.notify_all()

    def record(self, value):
        data = json.dumps(value, ensure_ascii=False).replace(self.key, '[REDACTED]')
        with self.guard, (self.directory / 'upstream-requests.jsonl').open('a') as stream:
            stream.write(data + '\n')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass

    def reply(self, status, payload):
        self.send_response(status)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(payload)))
        self.end_headers()
        try:
            self.wfile.write(payload)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def do_GET(self):
        if self.path == '/health':
            self.reply(200, json.dumps({'status': 'ready', 'pacing': self.server.pacer.snapshot()}).encode())
        else:
            self.reply(404, b'{"error":"Unknown endpoint"}')

    def do_POST(self):
        if self.path != self.server.local_path:
            self.reply(404, b'{"error":"Unknown endpoint"}')
            return
        auth_header = 'api-key' if self.server.protocol == 'gemini' else 'Authorization'
        expected = self.server.key if self.server.protocol == 'gemini' else 'Bearer ' + self.server.key
        if not hmac.compare_digest(self.headers.get(auth_header, ''), expected):
            self.reply(401, b'{"error":"Invalid local authorization"}')
            return
        row = {'started_at': time.time(), 'protocol': self.server.protocol + '-passthrough-v1'}
        started = time.monotonic()
        try:
            length = int(self.headers.get('Content-Length', '0'))
            if not 0 < length <= 32 * MIB:
                raise ValueError('Bridge request byte budget exceeded')
            with self.server.upload(length):
                body = self.rfile.read(length)
                if len(body) != length:
                    raise ValueError('Incomplete local request')
                data = json.loads(body)
                row.update(model=data['model'], request_bytes=length,
                           local_request_sha256=hashlib.sha256(body).hexdigest(),
                           upstream_request_sha256=hashlib.sha256(body).hexdigest())
                row['rate_wait_seconds'] = round(self.server.pacer.acquire(), 3)
                req = urllib.request.Request(self.server.endpoint, body,
                    {'Authorization': 'Bearer ' + self.server.key, 'Content-Type': 'application/json'})
                try:
                    with urllib.request.urlopen(req, timeout=300) as response:
                        payload = response.read(16 * MIB + 1)
                    if len(payload) > 16 * MIB:
                        raise ValueError('Provider response byte budget exceeded')
                    raw = json.loads(payload)
                    row.update(status=200, response_sha256=hashlib.sha256(payload).hexdigest(),
                               reported_model=raw.get('modelVersion') if self.server.protocol == 'gemini' else raw.get('model'),
                               upstream_usage=raw.get('usageMetadata') if self.server.protocol == 'gemini' else raw.get('usage'))
                    self.server.pacer.notice(200)
                    self.reply(200, payload.replace(self.server.key.encode(), b'[REDACTED]'))
                except urllib.error.HTTPError as exc:
                    row['status'] = exc.code
                    self.server.pacer.notice(exc.code)
                    payload = exc.read(4096).replace(self.server.key.encode(), b'[REDACTED]')
                    self.reply(exc.code, payload)
        except Exception as exc:
            row.update(status=502, error_type=type(exc).__name__)
            self.reply(502, json.dumps({'error': type(exc).__name__}).encode())
        finally:
            row['latency_seconds'] = round(time.monotonic() - started, 3)
            self.server.record(row)


class Supervisor:
    def __init__(self, args, key, jobs):
        self.args, self.directory, self.jobs = args, args.directory.resolve(), jobs
        self.condition = threading.Condition()
        self.children, self.workers, self.results = {}, {}, {}
        self.trace_status_cache = {}
        self.check_lock = threading.Lock()
        self.peak_rss = 0
        self.bridge = Bridge(key, self.directory, args.port, protocol=args.protocol, endpoint=args.upstream_endpoint)

    def memory(self):
        actual = process_memory(os.getpid()) + sum(process_memory(pid) for pid in self.children)
        reserved = process_memory(os.getpid()) + sum(max(charge, process_memory(pid)) for pid, charge in self.children.items())
        self.peak_rss = max(self.peak_rss, actual)
        return actual, reserved

    def save(self):
        with self.condition:
            rss, reserved = self.memory()
            counts = {}
            for p in (self.directory / self.args.model / 'runs').glob('*/trajectories/**/*.json'):
                try:
                    stamp = p.stat()
                    signature = (stamp.st_mtime_ns, stamp.st_size)
                    cached = self.trace_status_cache.get(p)
                    if cached is None or cached[0] != signature:
                        cached = (signature, json.loads(p.read_text())['status'])
                        self.trace_status_cache[p] = cached
                    status = cached[1]
                    counts[status] = counts.get(status, 0) + 1
                except (OSError, ValueError, KeyError):
                    continue
            atomic(self.directory / 'status.json', {
                'status': 'running' if not STOP.is_set() else 'stopping', 'pid': os.getpid(),
                'model': self.args.model, 'planned_configurations': 615,
                'recorded_configurations': sum(counts.values()), 'trajectory_statuses': counts,
                'terminal_configurations': sum(v for k, v in counts.items() if k in TERMINAL),
                'max_concurrency': self.args.concurrency, 'running_children': len(self.children),
                'rss_mib': round(rss / MIB, 2), 'peak_rss_mib': round(self.peak_rss / MIB, 2),
                'reserved_mib': round(reserved / MIB, 2), 'rss_admission_limit_mib': self.args.rss_limit_mib,
                'per_child_address_space_limit_mib': 512, 'workers': self.workers,
                'completed_shards': [k for k, v in self.results.items() if v == 'exported'],
                'needs_attention_shards': [k for k, v in self.results.items() if v != 'exported'],
                'pacing': self.bridge.pacer.snapshot(), 'updated_at': time.time()})

    def execute(self, command, charge, log, worker_id):
        with self.condition:
            while not STOP.is_set():
                _, reserved = self.memory()
                if reserved + charge <= self.args.rss_limit_mib * MIB:
                    break
                self.workers[worker_id]['status'] = 'memory_wait'
                self.condition.wait(timeout=2)
            if STOP.is_set():
                return 130
            self.workers[worker_id]['status'] = 'running'
            with log.open('a') as stream:
                child = subprocess.Popen(['prlimit', '--as=536870912', '--core=0', '--', *command],
                    cwd=ROOT, stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT,
                    env=dict(os.environ, PYTHONUNBUFFERED='1', PYTHONDONTWRITEBYTECODE='1'))
            self.children[child.pid] = charge
        try:
            while child.poll() is None:
                if STOP.wait(1):
                    child.terminate()
                    try:
                        child.wait(timeout=15)
                    except subprocess.TimeoutExpired:
                        child.kill()
                    break
            return child.wait()
        finally:
            with self.condition:
                self.children.pop(child.pid, None)
                self.condition.notify_all()

    def worker(self, worker_id, pending):
        while not STOP.is_set():
            try:
                job = pending.get_nowait()
            except queue.Empty:
                return
            with self.condition:
                self.workers[worker_id] = {'shard': job['name'], 'status': 'starting'}
            run = self.directory / self.args.model / 'runs' / job['name']
            log = self.directory / self.args.model / 'logs' / (job['name'] + '.log')
            log.parent.mkdir(parents=True, exist_ok=True)
            succeeded = False
            for attempt in range(12):
                command = [str(PYTHON), str(BUNDLE / 'redact_bench.py'), 'run', '--output', str(run)]
                if (run / 'run_config.json').exists():
                    command += ['--resume']
                else:
                    command += ['--protocol', self.args.protocol,
                        '--url', f'http://127.0.0.1:{self.args.port}' + self.bridge.local_path,
                        '--model', self.args.model, '--max-tokens', '16384', '--max-requests', '200',
                        '--max-prompt-chars', '200000', '--timeout', '300']
                    if job['paired']:
                        command += ['--paired']
                    for case in job['cases']:
                        command += ['--case', case]
                code = self.execute(command, job['reserved_memory_mib'] * MIB, log, worker_id)
                records = []
                for path in (run / 'trajectories').rglob('*.json'):
                    record = json.loads(path.read_text())
                    records.append({'case': record['case'], 'status': record['status'], 'error': record.get('error', '')})
                    del record
                if {r['case'] for r in records} == set(job['cases']) and all(r['status'] in TERMINAL for r in records):
                    succeeded = True
                    break
                if STOP.is_set():
                    break
                errors = [r.get('error', '') for r in records if r['status'] == 'infrastructure_error']
                # A preserved terminal input-budget outcome may leave later cases unstarted.
                can_continue = any(r['status'] == 'input_budget_exceeded' for r in records) and not errors
                transient = any(any(s in e for s in ['HTTP 429', 'HTTP 500', 'HTTP 502', 'HTTP 503',
                    'HTTP 504', 'URLError', 'timed out', 'TimeoutError', 'ConnectionResetError']) for e in errors)
                if not can_continue and not transient:
                    break
                with self.condition:
                    self.workers[worker_id].update(status='retry_wait', attempt=attempt + 1, last_exit_code=code)
                if not can_continue and STOP.wait(min(120, 10 * 2 ** min(attempt, 4))):
                    break
            archive = self.directory / self.args.model / 'exports' / (job['name'] + '.zip')
            if succeeded:
                with self.check_lock:
                    check = [str(PYTHON), str(BUNDLE / 'redact_bench.py'), 'check-run', '--run', str(run)]
                    if self.execute(check, 512 * MIB if job['has_images'] else 128 * MIB, log, worker_id):
                        succeeded = False
                    elif not archive.exists():
                        export = [str(PYTHON), str(BUNDLE / 'redact_bench.py'), 'export', '--run', str(run), '--output', str(archive)]
                        if self.execute(export, 512 * MIB if job['has_images'] else 128 * MIB, log, worker_id):
                            succeeded = False
            with self.condition:
                self.results[job['name']] = 'exported' if succeeded else 'needs_attention'
                self.workers[worker_id]['status'] = self.results[job['name']]
            self.save()

    def run(self):
        threading.stack_size(MIB)
        threading.Thread(target=self.bridge.serve_forever, daemon=True).start()
        pending = queue.Queue()
        for job in self.jobs:
            pending.put(job)
        with ThreadPoolExecutor(max_workers=self.args.concurrency) as pool:
            futures = [pool.submit(self.worker, str(i), pending) for i in range(self.args.concurrency)]
            while any(not f.done() for f in futures):
                self.save()
                STOP.wait(5)
            for future in futures:
                future.result()
        self.save()
        self.bridge.shutdown()
        self.bridge.server_close()
        state = json.loads((self.directory / 'status.json').read_text())
        state['status'] = 'stopped' if STOP.is_set() else ('behavior_complete' if all(v == 'exported' for v in self.results.values()) and len(self.results) == 32 else 'needs_attention')
        state['semantic_scoring'] = False
        if state['status'] == 'behavior_complete':
            path = self.directory / (self.args.model + '-all615.zip')
            if not path.exists():
                with zipfile.ZipFile(path, 'x', compression=zipfile.ZIP_STORED) as z:
                    for p in sorted((self.directory / self.args.model / 'exports').glob('*.zip')):
                        z.write(p, 'exports/' + p.name)
            state['all_trajectories_zip'] = str(path)
            state['all_trajectories_sha256'] = sha(path)
        atomic(self.directory / 'status.json', state)


def probe(key, model, protocol='openai', endpoint=None):
    headers = {'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'}
    with urllib.request.urlopen(urllib.request.Request(UPSTREAM + '/models', headers=headers), timeout=30) as response:
        ids = [m['id'] for m in json.load(response).get('data', [])]
    catalog_model_present = model in ids
    text = 'Return exactly the JSON object {"ok":true}.'
    if protocol == 'gemini':
        body = {'model': model, 'contents': [{'role': 'user', 'parts': [{'text': text}]}],
                'generationConfig': {'maxOutputTokens': 16384, 'temperature': 1., 'topP': .95, 'seed': 0}}
    else:
        body = {'model': model, 'messages': [{'role': 'user', 'content': [{'type': 'text', 'text': text}]}],
                'max_tokens': 1024, 'temperature': 1.0, 'top_p': .95, 'seed': 0}
    with urllib.request.urlopen(urllib.request.Request(endpoint or UPSTREAM + '/chat/completions', json.dumps(body).encode(), headers), timeout=90) as response:
        raw = json.load(response)
    if protocol == 'gemini':
        text = ''.join(p.get('text', '') for candidate in raw.get('candidates', [])
                       for p in candidate.get('content', {}).get('parts', []) if not p.get('thought'))
    else:
        text = raw['choices'][0]['message'].get('content') or ''
    if not text:
        raise RuntimeError('Provider returned no visible text in compatibility probe')
    return {'status': 'pass', 'model': model,
            'reported_model': raw.get('modelVersion') if protocol == 'gemini' else raw.get('model'),
            'protocol': protocol, 'endpoint': endpoint, 'catalog_model_present': catalog_model_present,
            'visible_response_characters': len(text),
            'sampling': {'temperature': 1., 'top_p': .95, 'seed': 0}, 'checked_at': time.time()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, required=True)
    parser.add_argument('--model', default='gemini-3.8-flash-lucas')
    parser.add_argument('--concurrency', type=int, default=8)
    parser.add_argument('--rss-limit-mib', type=int, default=1280)
    parser.add_argument('--port', type=int, default=18838)
    parser.add_argument('--api-key-env', default='REDACT_API_KEY')
    parser.add_argument('--protocol', choices=['openai', 'gemini'], default='gemini')
    parser.add_argument('--upstream-endpoint')
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--foreground', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    if not 1 <= args.concurrency <= 12 or not 640 <= args.rss_limit_mib <= 1536:
        parser.error('Concurrency must be 1..12 and RSS admission budget 640..1536 MiB')
    args.upstream_endpoint = args.upstream_endpoint or (
        'https://mp.z01.normandyfunc.com/gemini/v1beta/models/' + urllib.parse.quote(args.model, safe='') + ':generateContent' if args.protocol == 'gemini'
        else UPSTREAM + '/chat/completions')
    parsed = urllib.parse.urlsplit(args.upstream_endpoint)
    if parsed.scheme != 'https' or not parsed.netloc or parsed.username or parsed.password or parsed.query or parsed.fragment:
        parser.error('Upstream endpoint must be HTTPS without embedded credentials, query or fragment')
    args.directory = args.directory.resolve()
    args.directory.mkdir(parents=True, exist_ok=True)
    jobs = make_plan()
    plan = {'model': args.model, 'upstream': UPSTREAM, 'upstream_endpoint': args.upstream_endpoint,
            'protocol': args.protocol + '-passthrough-v1',
            'configurations': 615, 'jobs': jobs, 'max_concurrency': args.concurrency,
            'rss_admission_limit_mib': args.rss_limit_mib, 'per_child_address_space_limit_mib': 512,
            'max_output_tokens': 16384, 'max_requests': 200, 'max_prompt_characters': 200000,
            'frozen_inventory_sha256': sha(BUNDLE / 'SHA256SUMS.json'), 'supervisor_source_sha256': sha(Path(__file__)),
            'api_key_env': args.api_key_env, 'local_port': args.port, 'semantic_scoring': False}
    plan_path = args.directory / 'plan.json'
    if plan_path.exists() and json.loads(plan_path.read_text()) != plan:
        # Offline preparation is editable; a real API preflight or model run seals it.
        sealed = (args.directory / 'api-preflight.json').exists() or any(args.directory.glob('*/runs/*/run_config.json'))
        launcher = args.directory / 'launcher.json'
        if launcher.exists():
            sealed |= Path('/proc/' + str(json.loads(launcher.read_text())['launcher_pid'])).exists()
        if sealed:
            raise RuntimeError('Session configuration changed; use its original settings or a fresh directory')
    atomic(plan_path, plan)
    if args.prepare:
        if not (args.directory / 'status.json').exists():
            atomic(args.directory / 'status.json', {'status': 'awaiting_credentials', 'model': args.model,
                'planned_configurations': 615, 'max_concurrency': args.concurrency, 'paid_api_calls': 0})
        print(json.dumps({'status': 'prepared', 'directory': str(args.directory), 'configurations': 615, 'max_concurrency': args.concurrency}))
        return
    key = os.environ.get(args.api_key_env)
    if not key:
        if args.foreground or not sys.stdin.isatty():
            raise RuntimeError('Missing ' + args.api_key_env + '; launch from an interactive terminal for hidden key input')
        key = getpass.getpass('Previous provider API key (hidden): ')
    if not key:
        raise RuntimeError('API key is empty')
    if not args.foreground:
        existing = args.directory / 'launcher.json'
        if existing.exists() and Path('/proc/' + str(json.loads(existing.read_text())['launcher_pid'])).exists():
            raise RuntimeError('A launcher is already active for this directory')
        env = dict(os.environ, **{args.api_key_env: key, 'REDACT_API_KEY': key, 'PYTHONUNBUFFERED': '1'})
        command = ['systemd-run', '--user', '--scope', '--unit=redactbench-gemini38-' + str(int(time.time())),
            '--property=MemoryMax=1536M', '--property=MemorySwapMax=0', '--property=CPUWeight=20',
            'prlimit', '--as=536870912', '--core=0', '--', str(PYTHON), str(Path(__file__)),
            '--foreground', '--directory', str(args.directory), '--model', args.model,
            '--concurrency', str(args.concurrency), '--rss-limit-mib', str(args.rss_limit_mib),
            '--port', str(args.port), '--api-key-env', args.api_key_env,
            '--protocol', args.protocol, '--upstream-endpoint', args.upstream_endpoint]
        with (args.directory / 'supervisor.log').open('a') as log:
            child = subprocess.Popen(command, env=env, cwd=ROOT, stdin=subprocess.DEVNULL,
                stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        atomic(existing, {'launcher_pid': child.pid, 'directory': str(args.directory), 'started_at': time.time(),
                          'systemd_memory_max_mib': 1536, 'systemd_limit_verified': False})
        print(json.dumps({'status': 'launched', 'launcher_pid': child.pid, 'directory': str(args.directory)}))
        return
    os.environ['REDACT_API_KEY'] = key
    signal.signal(signal.SIGTERM, lambda *_: STOP.set())
    signal.signal(signal.SIGINT, lambda *_: STOP.set())
    try:
        atomic(args.directory / 'status.json', {'status': 'api_preflight', 'pid': os.getpid(),
            'model': args.model, 'planned_configurations': 615, 'updated_at': time.time()})
        atomic(args.directory / 'api-preflight.json', probe(key, args.model, args.protocol, args.upstream_endpoint))
        Supervisor(args, key, jobs).run()
    except Exception as exc:
        error = str(exc).replace(key, '[REDACTED]')[:1000]
        if isinstance(exc, urllib.error.HTTPError):
            error = 'HTTP ' + str(exc.code) + ': ' + exc.read(1000).decode(errors='replace').replace(key, '[REDACTED]')
        STOP.set()
        atomic(args.directory / 'status.json', {'status': 'needs_attention', 'error': error,
            'model': args.model, 'updated_at': time.time()})
        raise SystemExit(2)


if __name__ == '__main__':
    main()
