"""Durable launcher for the unchanged official Gemini v2 judge pipeline."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import time
import urllib.error
import urllib.request

PROJECT = Path('/data/project/RedActBench')
STOP = False


def write(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n'); temporary.replace(path)


def probe(key):
    body = {'model': 'gpt-6.1-sol-science', 'input': [{'role': 'user', 'content': [{'type': 'input_text', 'text': 'Return exactly {"ok":true}.'}]}],
            'max_output_tokens': 256, 'store': False}
    request = urllib.request.Request('https://mp.z01.normandyfunc.com/v1/responses', json.dumps(body).encode(),
        {'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            data = json.load(response)
        return {'status': 200, 'available': data.get('model') == 'gpt-6.1-sol-science'}
    except urllib.error.HTTPError as error:
        return {'status': error.code, 'available': False,
                'error': error.read(2000).decode(errors='replace').replace(key, '[REDACTED]')}
    except Exception as error:
        return {'status': type(error).__name__, 'available': False, 'error': str(error).replace(key, '[REDACTED]')}


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--directory', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True); parser.add_argument('--credential-socket', required=True)
    args = parser.parse_args(); args.directory = args.directory.resolve(); args.output = args.output.resolve()
    completion = json.loads((args.directory / 'completion-summary.json').read_text())
    if completion['completed_configurations'] != 615 or not completion['hard_case_50_excluded']:
        raise ValueError('Expected the completed regular 615-case run, excluding hard_case_50')
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
        client.connect(args.credential_socket); data = bytearray()
        while len(data) <= 1024:
            part = client.recv(1024)
            if not part:
                break
            data.extend(part)
    if not data or len(data) > 1024:
        raise ValueError('Credential delivery failed')
    key = data.decode()
    source_names = ['score_gemini.py', 'gemini_judge_case.py', 'gemini_judge_prepare.py',
                    'judge_case.py', 'judge_protocol.py', 'judge_packet_codec.py', 'gemini_memory_child.py', 'provider_bridge.py']
    sources = {name: hashlib.sha256((PROJECT / 'script' / name).read_bytes()).hexdigest() for name in source_names}
    write(args.output / 'background-binding.json', {'source_sha256': sources,
        'behavior_completion_sha256': hashlib.sha256((args.directory / 'completion-summary.json').read_bytes()).hexdigest(),
        'judge_model': 'gpt-6.1-sol-science', 'workers': 8, 'memory_admission_mib': 1280,
        'hard_case_50_excluded': True, 'reuses_valid_judgments_on_restart': True})
    def stop(*_):
        global STOP
        STOP = True
    signal.signal(signal.SIGTERM, stop)
    for attempt in range(3):
        if STOP:
            return
        for name, expected in sources.items():
            if hashlib.sha256((PROJECT / 'script' / name).read_bytes()).hexdigest() != expected:
                raise ValueError('Original judge source changed: ' + name)
        command = ['prlimit', '--as=536870912', '--core=0', '--',
            str(PROJECT / 'github_test_bundle/.venv/bin/python'), str(PROJECT / 'script/score_gemini.py'),
            '--directory', str(args.directory), '--output', str(args.output), '--judge-model', 'gpt-6.1-sol-science',
            '--workers', '8', '--memory-mib', '1280', '--foreground']
        child = subprocess.Popen(command, cwd=PROJECT,
            env=dict(os.environ, REDACT_API_KEY=key, MALLOC_ARENA_MAX='2', PYTHONUNBUFFERED='1'),
            stdin=subprocess.DEVNULL)
        while child.poll() is None:
            write(args.output / 'background-status.json', {'status': 'judging', 'pid': os.getpid(),
                'coordinator_pid': child.pid, 'attempt': attempt + 1, 'updated_at': time.time()})
            for _ in range(5):
                if child.poll() is not None:
                    break
                if STOP:
                    child.terminate(); child.wait(); return
                time.sleep(1)
        summary_path = args.output / 'summary.json'
        summary = json.loads(summary_path.read_text()) if summary_path.exists() else {}
        if summary.get('scoring_complete') and not summary.get('failed_cases'):
            write(args.output / 'background-status.json', {'status': 'scoring_complete', 'pid': os.getpid(),
                'completed_cases': 615, 'updated_at': time.time()})
            return
        while not STOP:
            available = probe(key)
            if available['available']:
                break
            write(args.output / 'background-status.json', {'status': 'waiting_for_provider', 'pid': os.getpid(),
                'probe': available, 'next_check_at': time.time() + 600, 'updated_at': time.time()})
            for _ in range(600):
                if STOP:
                    return
                time.sleep(1)
    write(args.output / 'background-status.json', {'status': 'needs_attention', 'pid': os.getpid(),
        'reason': 'Three complete recovery passes exhausted; valid judgments retained', 'updated_at': time.time()})


if __name__ == '__main__':
    main()
