"""Keep the bound Gemini run resumable across temporary API budget outages."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import struct
import subprocess
import time
import urllib.error
import urllib.request

PROJECT = Path('/data/project/RedActBench')
STOP = False


def write(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n'); temporary.replace(path)


def active(directory):
    for name, field in [('status.json', 'pid'), ('launcher.json', 'launcher_pid')]:
        state = json.loads((directory / name).read_text())
        proc = Path('/proc') / str(state.get(field, 0))
        try:
            args = proc.joinpath('cmdline').read_bytes().split(b'\0')
            if str(directory).encode() in args and any(b'launch_gemini_ab.py' in a or b'run_gemini_fast.py' in a for a in args):
                return int(proc.name)
        except OSError:
            pass
    return None


def validate(directory):
    binding = json.loads((directory / 'launch-binding.json').read_text())
    for name, digest in binding['sources'].items():
        if hashlib.sha256((PROJECT / 'script' / name).read_bytes()).hexdigest() != digest:
            raise ValueError('Original source changed: ' + name)
    if hashlib.sha256((directory / 'plan.json').read_bytes()).hexdigest() != binding['original_plan_sha256']:
        raise ValueError('Original plan changed')
    plan = json.loads((directory / 'plan.json').read_text())
    if hashlib.sha256((PROJECT / 'github_test_bundle/SHA256SUMS.json').read_bytes()).hexdigest() != plan['frozen_inventory_sha256']:
        raise ValueError('Original benchmark inventory changed')


def probe(plan, key):
    body = {'model': plan['model'], 'contents': [{'role': 'user', 'parts': [{'text': 'Return exactly {"ok":true}.'}]}],
            'generationConfig': {'maxOutputTokens': 16384, 'temperature': 1., 'topP': .95, 'seed': 0}}
    request = urllib.request.Request(plan['upstream_endpoint'], json.dumps(body).encode(),
        {'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json'})
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            data = json.load(response)
        text = ''.join(p.get('text', '') for c in data.get('candidates', [])
                       for p in c.get('content', {}).get('parts', []) if not p.get('thought'))
        return {'available': data.get('modelVersion') == 'gemini-3.8-flash' and bool(text.strip()), 'status': 200}
    except urllib.error.HTTPError as error:
        return {'available': False, 'status': error.code,
                'error': error.read(2000).decode(errors='replace').replace(key, '[REDACTED]')}
    except Exception as error:
        return {'available': False, 'status': type(error).__name__, 'error': str(error).replace(key, '[REDACTED]')}


def resume(directory, key):
    address = Path('/tmp') / ('gemini-auto-resume-' + str(time.time_ns()) + '.sock')
    server = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM); server.bind(str(address))
    os.chmod(address, 0o600); server.listen(1); server.settimeout(30)
    unit = 'gemini38-auto-resume-' + str(time.time_ns())
    try:
        command = ['systemd-run', '--user', '--unit=' + unit, '--property=Type=exec', '--property=MemoryMax=1536M',
            '--property=WorkingDirectory=' + str(PROJECT), '--property=StandardOutput=append:' + str(directory / 'supervisor.log'),
            '--property=StandardError=append:' + str(directory / 'supervisor.log'), '--setenv=MALLOC_ARENA_MAX=2',
            '--setenv=PYTHONUNBUFFERED=1', 'prlimit', '--as=536870912', '--core=0', '--',
            str(PROJECT / 'github_test_bundle/.venv/bin/python'), str(PROJECT / 'script/launch_gemini_ab.py'),
            '--directory', str(directory), '--credential-socket', str(address)]
        result = subprocess.run(command, capture_output=True, text=True, timeout=20)
        if result.returncode:
            raise RuntimeError('Automatic resume launch failed: ' + result.stderr)
        with server.accept()[0] as client:
            pid, uid, _ = struct.unpack('3i', client.getsockopt(socket.SOL_SOCKET, socket.SO_PEERCRED, 12))
            if uid != os.getuid():
                raise RuntimeError('Unexpected credential recipient')
            client.sendall(key.encode())
        write(directory / 'launcher.json', {'launcher_pid': pid, 'systemd_unit': unit + '.service',
            'workers': 12, 'rss_admission_limit_mib': 1280, 'started_at': time.time(), 'resumed_by_budget_watchdog': True})
    finally:
        server.close(); address.unlink(missing_ok=True)


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--directory', type=Path, required=True)
    parser.add_argument('--credential-socket', required=True); args = parser.parse_args(); directory = args.directory.resolve()
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
        client.connect(args.credential_socket); key = bytearray()
        while len(key) <= 1024:
            part = client.recv(1024)
            if not part:
                break
            key.extend(part)
    if not key or len(key) > 1024:
        raise ValueError('Credential delivery failed')
    key = key.decode(); validate(directory); plan = json.loads((directory / 'plan.json').read_text())
    def stop(*_):
        global STOP
        STOP = True
    signal.signal(signal.SIGTERM, stop)
    while not STOP:
        state = json.loads((directory / 'status.json').read_text())
        if state.get('status') == 'behavior_complete':
            write(directory / 'budget-watchdog-status.json', {'status': 'complete', 'pid': os.getpid(), 'updated_at': time.time()})
            return
        running = active(directory); delay = 60; result = None
        if running is None:
            validate(directory); result = probe(plan, key)
            if result['available']:
                resume(directory, key)
            else:
                delay = 600
        write(directory / 'budget-watchdog-status.json', {'status': 'monitoring_run' if running else 'resuming' if result['available'] else 'waiting_for_budget' if result['status'] == 402 else 'waiting_for_provider',
            'pid': os.getpid(), 'runner_pid': running, 'probe': result, 'next_check_at': time.time() + delay, 'updated_at': time.time()})
        for _ in range(delay):
            if STOP:
                return
            time.sleep(1)


if __name__ == '__main__':
    main()
