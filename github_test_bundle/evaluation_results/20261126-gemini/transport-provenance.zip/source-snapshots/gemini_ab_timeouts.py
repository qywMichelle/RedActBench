"""Extend transport waits only for this bound Gemini A/B session."""
import sys


def configure():
    from pathlib import Path
    parent_entry = Path('/data/project/RedActBench/script/launch_gemini_ab.py')
    child_entry = Path('/data/project/RedActBench/script/gemini_memory_child.py')
    if not sys.argv or Path(sys.argv[0]).resolve() not in {parent_entry, child_entry}:
        return
    import hashlib
    import json
    import os
    import urllib.request
    root = Path('/data/project/RedActBench/github_test_bundle/output/gemini38-flash-ab-20261126')
    control_path = root / 'transport-timeout-control.json'
    if not control_path.exists():
        return
    control = json.loads(control_path.read_text())
    if not control.get('enabled'):
        return
    if Path(sys.argv[0]).resolve() == parent_entry:
        if '--directory' not in sys.argv or Path(sys.argv[sys.argv.index('--directory') + 1]).resolve() != root:
            return
        role = 'parent'
    else:
        if len(sys.argv) < 2 or Path(sys.argv[1]).resolve() != root / 'image-cache':
            return
        role = 'child'
    if hashlib.sha256(Path(__file__).read_bytes()).hexdigest() != control['source_sha256']:
        os._exit(72)
    if role == 'parent':
        original = urllib.request.urlopen
        def open_upstream(request, *args, **kwargs):
            if getattr(request, 'full_url', request) == control['upstream_endpoint']:
                kwargs['timeout'] = control['upstream_timeout_seconds']
            return original(request, *args, **kwargs)
        urllib.request.urlopen = open_upstream
    else:
        original = urllib.request.OpenerDirector.open
        def open_local(opener, request, data=None, timeout=None):
            if getattr(request, 'full_url', request) == control['local_endpoint']:
                timeout = control['local_timeout_seconds']
            if timeout is None:
                import socket
                timeout = socket._GLOBAL_DEFAULT_TIMEOUT
            return original(opener, request, data, timeout)
        urllib.request.OpenerDirector.open = open_local
