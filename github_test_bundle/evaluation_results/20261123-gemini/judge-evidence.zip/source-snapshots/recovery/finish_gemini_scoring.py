"""Recover remaining Gemini reviews and complete original official score aggregation."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import os
from pathlib import Path
import queue
import signal
import socket
import sys
import threading
import time

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'script'))
import score_gemini as original
import judge_protocol


class Finisher(original.Coordinator):
    def collect(self):
        state, summary = super().collect()
        original.write(self.output / 'acceleration-status.json', dict(state,
            acceleration='remaining-cases-recovery-v1', active_judge_processes=state['active_processes'],
            total_grading_rss_mib=state['rss_mib'], helper_pid=None))
        return state, summary

    def execute(self, command, charge, log):
        if Path(command[1]).name == 'gemini_judge_case.py':
            packet = Path(command[command.index('--packet') + 1])
            charge = 64 * original.MIB + min(48 * original.MIB, packet.stat().st_size * 4)
        return super().execute(command, charge, log)

    def case_worker(self, index, pending):
        while not original.STOP.is_set():
            try:
                job, case = pending.get_nowait()
            except queue.Empty:
                return
            review = self.output / 'reviews' / job['name']
            packet = review / 'judge-inputs' / (case + '.json')
            template = review / 'templates' / (case + '.json')
            delivery = review / 'delivery' / (case + '.json')
            original.write(delivery, {})
            command = [original.PYTHON, ROOT / 'script/gemini_judge_case.py', '--packet', packet,
                       '--template', template, '--delivery', delivery, '--output', review,
                       '--model', self.args.judge_model, '--resource-root', self.output]
            log = self.output / 'recovery-logs' / ('worker-' + str(index) + '.log')
            log.parent.mkdir(exist_ok=True)
            result_file = review / 'case-status' / (case + '.json')
            for retry in range(3):
                with self.state_guard:
                    self.workers[str(index)] = {'status': 'judging', 'case': case, 'shard': job['name'], 'retry': retry}
                code = self.execute(command, 64 * original.MIB, log)
                result = json.loads(result_file.read_text()) if result_file.exists() else {}
                if code == 0 and result.get('status') == 'complete':
                    with self.state_guard:
                        self.failed.pop(case, None)
                    break
                if original.STOP.wait(15 * (retry + 1)):
                    break
            else:
                with self.state_guard:
                    self.failed[case] = {'case': case, 'stage': 'judge', 'exit_code': code, 'status': result.get('status')}
            with self.state_guard:
                self.workers[str(index)]['status'] = 'finished'

    def aggregate_ready(self, cases_finished):
        aggregated = set()
        while not original.STOP.is_set():
            waiting = False
            for job in self.plan['jobs']:
                if job['name'] in aggregated:
                    continue
                review = self.output / 'reviews' / job['name']
                report_path = review / 'metrics-v2.json'
                if report_path.exists():
                    report = json.loads(report_path.read_text())
                    if report['overall']['scored_episodes'] == len(job['cases']) and not any(report.get(k) for k in ['validation_errors', 'unreviewed', 'missing_trajectories', 'quality_excluded']):
                        aggregated.add(job['name'])
                        continue
                if not all((review / 'judgments' / (case + '.json')).exists() for case in job['cases']):
                    waiting = True
                    continue
                run = self.directory / self.model / 'runs' / job['name']
                log = self.output / 'recovery-logs' / (job['name'] + '-aggregate.log')
                log.parent.mkdir(exist_ok=True)
                code = self.heavy(['evaluate', '--run', run, '--output', review, '--partial'], log)
                if code:
                    with self.state_guard:
                        self.failed[job['name']] = {'shard': job['name'], 'stage': 'aggregate', 'exit_code': code}
                else:
                    aggregated.add(job['name'])
                self.collect()
            if len(aggregated) == 32 or cases_finished.is_set():
                return
            original.STOP.wait(2)

    def run(self):
        import fcntl
        threading.stack_size(original.MIB)
        lock = (self.output / '.coordinator.lock').open('a+')
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        pending = queue.Queue()
        reused = 0
        for job in self.plan['jobs']:
            review = self.output / 'reviews' / job['name']
            for case in job['cases']:
                packet_file = review / 'judge-inputs' / (case + '.json')
                if not packet_file.exists() or not (review / 'templates' / (case + '.json')).exists():
                    raise RuntimeError('Required prepared review missing: ' + case)
                destination = review / 'judgments' / (case + '.json')
                packet = json.loads(packet_file.read_text())
                if packet['trajectory_sha256'] != original.sha(self.directory / self.model / 'runs' / job['name'] / 'trajectories' / (case + '.json')):
                    raise RuntimeError('Original trajectory binding changed: ' + case)
                if destination.exists():
                    judgment = json.loads(destination.read_text())
                    metrics = judge_protocol.validate(judgment, packet)
                    result_file = review / 'case-status' / (case + '.json')
                    result = json.loads(result_file.read_text()) if result_file.exists() else {}
                    result.update(status='complete', case=case, metrics=metrics, needs_primary_review=judgment['needs_primary_review'], recovered_validated=True)
                    original.write(result_file, result)
                    reused += 1
                else:
                    pending.put((job, case))
                del packet
        original.write(self.output / 'recovery-summary.json', {'validated_reused_cases': reused,
            'remaining_cases': pending.qsize(), 'judge_model': self.args.judge_model,
            'workers': self.args.workers, 'memory_mib': self.args.memory_mib, 'started_at': time.time()})
        finished = threading.Event()
        with ThreadPoolExecutor(max_workers=self.args.workers + 1) as pool:
            workers = [pool.submit(self.case_worker, i, pending) for i in range(self.args.workers)]
            aggregator = pool.submit(self.aggregate_ready, finished)
            while any(not f.done() for f in workers):
                self.collect()
                original.STOP.wait(5)
            for f in workers:
                f.result()
            finished.set()
            aggregator.result()
        # A case may finish just after its shard was skipped by the live aggregator.
        for job in self.plan['jobs']:
            review = self.output / 'reviews' / job['name']
            report = json.loads((review / 'metrics-v2.json').read_text())
            if report['overall']['scored_episodes'] != len(job['cases']) and all((review / 'judgments' / (c + '.json')).exists() for c in job['cases']):
                log = self.output / 'recovery-logs' / (job['name'] + '-aggregate.log')
                self.heavy(['evaluate', '--run', self.directory / self.model / 'runs' / job['name'],
                            '--output', review, '--partial'], log)
        self.finish(*self.collect())
        final = json.loads((self.output / 'status.json').read_text())
        original.write(self.output / 'acceleration-status.json', dict(final, acceleration='remaining-cases-recovery-v1',
            active_judge_processes=0, total_grading_rss_mib=final['rss_mib'], helper_pid=None))


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--directory', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--workers', type=int, default=14)
    p.add_argument('--credential-socket')
    args = p.parse_args()
    if not 1 <= args.workers <= 14:
        p.error('Workers must be 1..14')
    args.directory, args.output = args.directory.resolve(), args.output.resolve()
    binding = json.loads((args.output / 'judge-binding.json').read_text())
    for name, expected in binding['sources'].items():
        if original.sha(ROOT / name) != expected:
            raise RuntimeError('Original judge/scorer source changed: ' + name)
    plan = json.loads((args.directory / 'plan.json').read_text())
    args.judge_model = binding['judge_model']
    args.memory_mib = binding['memory_admission_limit_mib']
    if args.credential_socket:
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.connect(args.credential_socket)
            data = bytearray()
            while len(data) <= 1024:
                chunk = client.recv(1024)
                if not chunk:
                    break
                data.extend(chunk)
            if not data or len(data) > 1024:
                raise RuntimeError('Hidden credential delivery failed')
            os.environ['REDACT_API_KEY'] = bytes(data).decode()
    key = os.environ.get('REDACT_API_KEY')
    if not key:
        raise RuntimeError('Provider key missing')
    signal.signal(signal.SIGTERM, lambda *_: original.STOP.set())
    signal.signal(signal.SIGINT, lambda *_: original.STOP.set())
    snapshot = args.output / 'source-snapshots/recovery' / Path(__file__).name
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(Path(__file__).read_bytes())
    original.write(args.output / 'recovery-binding.json', {'version': 'remaining-cases-finisher-v1',
        'original_judge_binding_sha256': original.sha(args.output / 'judge-binding.json'),
        'source_sha256': original.sha(Path(__file__)), 'workers': args.workers,
        'memory_admission_limit_mib': args.memory_mib, 'judge_model': args.judge_model,
        'scored_model': plan['model'], 'existing_judgments_regraded': False, 'started_at': time.time()})
    try:
        Finisher(args, plan).run()
    except Exception as exc:
        original.STOP.set()
        original.write(args.output / 'status.json', {'status': 'needs_attention', 'error': str(exc).replace(key, '[REDACTED]')[:1000], 'pid': os.getpid(), 'updated_at': time.time()})
        raise SystemExit(2)


if __name__ == '__main__':
    main()
