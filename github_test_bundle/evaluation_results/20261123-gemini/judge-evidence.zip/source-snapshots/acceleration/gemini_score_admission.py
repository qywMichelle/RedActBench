"""Scoped startup locks and shared memory accounting for this Gemini judge only."""
import sys

HELD = None


def process_memory(output):
    from pathlib import Path
    result = {}
    prefix = str(output).encode()
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            argv = (p / 'cmdline').read_bytes().split(b'\0')
            if not any(a == prefix or a.startswith(prefix + b'/') for a in argv):
                continue
            values = (p / 'status').read_text().splitlines()
            if any(s.startswith('State:') and '\tZ' in s for s in values):
                continue
            result[int(p.name)] = next(int(s.split()[1]) * 1024 for s in values if s.startswith('VmRSS:'))
        except (OSError, StopIteration, ValueError):
            pass
    return result


def configure():
    global HELD
    if HELD is not None or not sys.argv:
        return
    from pathlib import Path
    name = Path(sys.argv[0]).name
    if name not in {'gemini_judge_case.py', 'gemini_judge_prepare.py'}:
        return
    import atexit
    import fcntl
    import hashlib
    import json
    import os
    import time
    try:
        if name == 'gemini_judge_case.py':
            output = Path(sys.argv[sys.argv.index('--resource-root') + 1]).resolve()
            packet = Path(sys.argv[sys.argv.index('--packet') + 1]).resolve()
            if not packet.is_relative_to(output / 'reviews'):
                return
            identity = str(packet)
            charge = 64 * 1024**2 + min(48 * 1024**2, packet.stat().st_size * 4)
        else:
            output = Path(sys.argv[1]).resolve()
            review = Path(sys.argv[sys.argv.index('--output') + 1]).resolve()
            if not review.is_relative_to(output / 'reviews'):
                return
            identity = str(review)
            charge = 64 * 1024**2
        config_path = output / 'score-acceleration-control.json'
        if not config_path.exists():
            return
        config = json.loads(config_path.read_text())
        if not config.get('enabled') or str(output) != config['output']:
            return
        if hashlib.sha256(Path(__file__).read_bytes()).hexdigest() != config['admission_source_sha256']:
            os._exit(72)
    except (OSError, ValueError, IndexError):
        return
    locks = output / '.shared-score-locks'
    locks.mkdir(exist_ok=True)
    HELD = (locks / (hashlib.sha256((name + identity).encode()).hexdigest() + '.lock')).open('a+')
    fcntl.flock(HELD, fcntl.LOCK_EX)
    pid = str(os.getpid())
    ledger = output / 'score-memory-reservations.json'
    while True:
        with (output / '.score-memory.lock').open('a+') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX)
            observed = process_memory(output)
            observed[int(pid)] = next(int(s.split()[1]) * 1024 for s in Path('/proc/self/status').read_text().splitlines() if s.startswith('VmRSS:'))
            state = json.loads(ledger.read_text()) if ledger.exists() else {'charges': {}, 'waiting': []}
            state['charges'] = {p: v for p, v in state['charges'].items() if int(p) in observed}
            state['waiting'] = [p for p in state['waiting'] if int(p) in observed]
            if pid not in state['waiting']:
                state['waiting'].append(pid)
            reserved = sum(observed.values()) + sum(max(0, v - observed.get(int(p), 0)) for p, v in state['charges'].items())
            reserved += config['heavy_headroom_mib'] * 1024**2
            if state['waiting'][0] == pid and reserved + max(0, charge - observed[int(pid)]) <= config['memory_limit_mib'] * 1024**2:
                state['charges'][pid] = charge
                state['waiting'].remove(pid)
                state['updated_at'] = time.time()
                ledger.write_text(json.dumps(state))
                break
            state['updated_at'] = time.time()
            ledger.write_text(json.dumps(state))
        time.sleep(1)

    def release():
        try:
            with (output / '.score-memory.lock').open('a+') as lock:
                fcntl.flock(lock, fcntl.LOCK_EX)
                state = json.loads(ledger.read_text()) if ledger.exists() else {'charges': {}, 'waiting': []}
                state['charges'].pop(pid, None)
                state['waiting'] = [p for p in state['waiting'] if p != pid]
                ledger.write_text(json.dumps(state))
        except (OSError, ValueError):
            pass
        HELD.close()
    atexit.register(release)
