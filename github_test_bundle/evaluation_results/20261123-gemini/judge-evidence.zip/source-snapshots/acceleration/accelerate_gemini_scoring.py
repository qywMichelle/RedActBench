"""Add helpers to the existing judge without interrupting any in-flight reviews."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import threading
import time

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'script'))
import score_gemini as original
from gemini_score_admission import process_memory
STOP = threading.Event()


class Helpers:
    def __init__(self, output, directory, workers):
        self.output, self.directory, self.workers = output, directory, workers
        self.binding = json.loads((output / 'judge-binding.json').read_text())
        self.plan = json.loads((directory / 'plan.json').read_text())
        self.control = json.loads((output / 'score-acceleration-control.json').read_text())
        self.guard = threading.Lock()
        self.claimed, self.finished, self.failed, self.children = set(), set(), {}, {}
        self.worker_status = {}

    def choose(self):
        with self.guard:
            active = set()
            for pid in process_memory(self.output):
                try:
                    argv = [a.decode() for a in Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0') if a]
                    if '--packet' in argv:
                        active.add(argv[argv.index('--packet') + 1])
                except (OSError, ValueError, IndexError):
                    pass
            for job in reversed(self.plan['jobs']):
                review = self.output / 'reviews' / job['name']
                for case in reversed(job['cases']):
                    packet = review / 'judge-inputs' / (case + '.json')
                    if (not packet.exists() or not (review / 'templates' / (case + '.json')).exists() or
                            (review / 'judgments' / (case + '.json')).exists() or str(packet) in self.claimed or
                            str(packet) in active or str(packet) in self.control['unmanaged_packets']):
                        continue
                    self.claimed.add(str(packet))
                    return review, packet, case
            return None

    def execute(self, command, log, worker):
        with log.open('a') as stream:
            child = subprocess.Popen(['prlimit', '--as=536870912', '--core=0', '--', *map(str, command)],
                cwd=ROOT, env=dict(os.environ, MALLOC_ARENA_MAX='2', PYTHONUNBUFFERED='1',
                                  GEMINI_JUDGE_IMAGE_CACHE=str(self.directory / 'image-cache')),
                stdin=subprocess.DEVNULL, stdout=stream, stderr=subprocess.STDOUT)
        with self.guard:
            self.children[child.pid] = worker
        try:
            while child.poll() is None:
                if STOP.wait(1):
                    child.terminate()
                    try:
                        child.wait(timeout=15)
                    except subprocess.TimeoutExpired:
                        child.kill()
                    break
            return child.wait()
        finally:
            with self.guard:
                self.children.pop(child.pid, None)

    def worker(self, index):
        while not STOP.is_set():
            item = self.choose()
            if item is None:
                if self.all_complete():
                    return
                with self.guard:
                    self.worker_status[str(index)] = {'status': 'waiting_prepared_cases'}
                STOP.wait(2)
                continue
            review, packet, case = item
            run = self.directory / self.plan['model'] / 'runs' / review.name
            prepared = json.loads(packet.read_text())
            if prepared['trajectory_sha256'] != original.sha(run / 'trajectories' / (case + '.json')):
                raise RuntimeError('Helper packet is stale: ' + case)
            del prepared
            delivery = review / 'delivery' / (case + '.json')
            original.write(delivery, {})
            log = self.output / 'helper-logs' / ('worker-' + str(index) + '.log')
            log.parent.mkdir(exist_ok=True)
            command = [original.PYTHON, ROOT / 'script/gemini_judge_case.py', '--packet', packet,
                       '--template', review / 'templates' / (case + '.json'), '--delivery', delivery,
                       '--output', review, '--model', self.binding['judge_model'], '--resource-root', self.output]
            for retry in range(3):
                with self.guard:
                    self.worker_status[str(index)] = {'status': 'judging', 'case': case, 'retry': retry}
                code = self.execute(command, log, str(index))
                p = review / 'case-status' / (case + '.json')
                result = json.loads(p.read_text()) if p.exists() else {}
                if not code and result.get('status') == 'complete':
                    with self.guard:
                        self.finished.add(case)
                        self.failed.pop(case, None)
                    break
                if STOP.wait(15 * (retry + 1)):
                    break
            else:
                with self.guard:
                    self.failed[case] = {'case': case, 'exit_code': code, 'status': result.get('status')}

    def prepare(self):
        for job in reversed(self.plan['jobs']):
            if STOP.is_set():
                return
            review = self.output / 'reviews' / job['name']
            if len(list((review / 'judge-inputs').rglob('*.json'))) == len(job['cases']):
                continue
            primary = json.loads((self.output / 'status.json').read_text())
            if any(w.get('shard') == job['name'] for w in primary.get('workers', {}).values()):
                continue
            run = self.directory / self.plan['model'] / 'runs' / job['name']
            log = self.output / 'helper-logs' / (job['name'] + '-prepare.log')
            log.parent.mkdir(exist_ok=True)
            command = [original.PYTHON, ROOT / 'script/gemini_judge_prepare.py', self.output,
                       self.directory / 'image-cache', original.BUNDLE / 'redact_bench.py',
                       'evaluate', '--run', run, '--output', review, '--prepare']
            code = self.execute(command, log, 'prepare')
            if code and not STOP.is_set():
                with self.guard:
                    self.failed[job['name']] = {'shard': job['name'], 'stage': 'prepare', 'exit_code': code}

    def all_complete(self):
        return sum(1 for p in (self.output / 'reviews').glob('*/case-status/**/*.json')
                   if json.loads(p.read_text()).get('status') == 'complete') == 615

    def save(self):
        primary = json.loads((self.output / 'status.json').read_text())
        memory = process_memory(self.output)
        active = 0
        for pid in memory:
            try:
                argv = Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
                if any(a.endswith(b'/gemini_judge_case.py') for a in argv):
                    active += 1
            except OSError:
                pass
        with self.guard:
            status = dict(primary, maximum_judge_workers=8 + self.workers,
                active_judge_processes=active, total_grading_rss_mib=round(sum(memory.values()) / 1024**2, 2),
                helper_pid=os.getpid(), helper_workers=self.worker_status,
                helper_completed_cases=len(self.finished), helper_failed_cases=list(self.failed.values()),
                helper_children=len(self.children), acceleration='shared-case-locks-and-helpers-v1', updated_at=time.time())
        original.write(self.output / 'acceleration-status.json', status)

    def run(self):
        lock = (self.output / '.score-helpers.lock').open('a+')
        import fcntl
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        with ThreadPoolExecutor(max_workers=self.workers + 1) as pool:
            futures = [pool.submit(self.worker, i) for i in range(self.workers)] + [pool.submit(self.prepare)]
            while any(not f.done() for f in futures):
                self.save()
                if self.all_complete():
                    STOP.set()
                STOP.wait(3)
            for f in futures:
                f.result()
        self.save()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--directory', type=Path, required=True)
    p.add_argument('--workers', type=int, default=6)
    p.add_argument('--foreground', action='store_true')
    args = p.parse_args()
    if not 1 <= args.workers <= 6:
        p.error('Helpers must be 1..6')
    args.output, args.directory = args.output.resolve(), args.directory.resolve()
    control = json.loads((args.output / 'score-acceleration-control.json').read_text())
    if hashlib.sha256(Path(__file__).read_bytes()).hexdigest() != control['helper_source_sha256']:
        raise RuntimeError('Helper source binding changed')
    if original.sha(args.output / 'judge-binding.json') != control['original_judge_binding_sha256']:
        raise RuntimeError('Original judge binding changed')
    if not os.environ.get('REDACT_API_KEY'):
        raise RuntimeError('Provider key missing from inherited environment')
    if not args.foreground:
        env = dict(os.environ, MALLOC_ARENA_MAX='2', PYTHONUNBUFFERED='1')
        with (args.output / 'helpers-supervisor.log').open('a') as log:
            child = subprocess.Popen(['prlimit', '--as=536870912', '--core=0', '--', original.PYTHON,
                Path(__file__), '--foreground', '--output', args.output, '--directory', args.directory,
                '--workers', str(args.workers)], cwd=ROOT, env=env, stdin=subprocess.DEVNULL,
                stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        original.write(args.output / 'helpers-launcher.json', {'pid': child.pid, 'workers': args.workers, 'started_at': time.time()})
        print(json.dumps({'status': 'launched', 'helper_pid': child.pid, 'extra_workers': args.workers}))
        return
    signal.signal(signal.SIGTERM, lambda *_: STOP.set())
    signal.signal(signal.SIGINT, lambda *_: STOP.set())
    Helpers(args.output, args.directory, args.workers).run()


if __name__ == '__main__':
    main()
