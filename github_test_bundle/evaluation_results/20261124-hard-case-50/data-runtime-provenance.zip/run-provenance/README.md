# Hard case 50 × 4 models

本轮行为测试已于2026-11-25 08:17:58（Asia/Hong_Kong）完成，实际运行约16小时56分钟。四模型各50条，全部200条状态均为complete；200份check-run回放报告均为pass。再次核验了全部ZIP与本地源轨迹SHA、History20，以及四个all50.zip内的50份案例包一致性，验证结果见completion-summary.json。

用户已于2026-11-25授权对全部200条进行并行judge。评分目录为judge-v2-gpt61-20261125/，沿用原项目v2评分协议、六维锚点与GCR/TSR/LCR计算，裁判gpt-6.1-sol-science。16个case工作者上限、最多8个上游调用，内存准入1280 MiB。各题关键边界从冻结rubric原文映射；评审保留完整轨迹，候选History20不限制judge证据范围。实时进度见该目录status.json，汇总见summary.json，完成后生成score-report.md和judge-evidence.zip。

完整轨迹汇总包：opus-5.5-all50.zip、gemini-3.8-flash-all50.zip、gpt-6.1-sol-all50.zip、kimi-3.1-pro-all50.zip。空闲broker已关闭；仅作用于本轮冻结入口的临时startup模块与.pth经过SHA核对后移除，清理记录见completion-cleanup.json。运行期间的旧状态快照保留为*.before-final.json，最终状态已更新为behavior_complete。

本轮按用户要求测试50个 hard_case_50 案例，每模型50个配置，共200条。数据从远端 main 的 adcf0ca 提交取回，未切换或覆盖当前 ldm 的其他工作。50个初始可见观察与两套源运行时完全一致，上传版的290个文件SHA已核验。GitHub data_only 版本省略了355份作者轨迹；它们未被加入模型输入，也没有以参考回放充当模型成绩。

## 固定模型与接口

| 标签 | 代理 model ID | 实际接口 |
|---|---|---|
| Opus 5.5 | claude-opus-5-5-hc | /v1/messages |
| Gemini 3.8 Flash | gemini-3.8-flash:post-evaluation | /gemini/v1beta/models/...:generateContent |
| GPT 6.1 Sol | gpt-6.1-sol-science | /v1/responses |
| Kimi 3.1 Pro | kimi-k3.1-pro-lucas | /v1/chat/completions |

Gemini lucas 路由在本轮预检连续超时，选用已返回HTTP 200且实际报告模型为gemini-3.8-flash的同版本post-evaluation路由。路由在首次运行前已固定，运行中不自动换模型。Gemini显式禁用原生function calling，因为源运行时要求文本JSON的op操作；其余模型也只通过JSON文本操作虚拟环境。

## History 与运行预算

真正截取最近20个模型/工具回合，使用窗口内无损观察delta；每次都保留完整CURRENT OBSERVATION与该案例允许的公开工具描述。更早的历史不进入请求。历史包含模型回复、工具结果及协议错误；完整模型回合和源环境步骤仍全部写入JSONL，并非只保留20步的评测轨迹。

四个模型均使用相同20轮窗口和16384输出token上限；每案例最多400次模型请求，prompt保护上限600000字符。环境自身的150–180分钟horizon保持原值。Opus仅发送其支持的temperature=1；GPT Responses使用此前代理的provider默认采样，省略不支持的temperature/top_p/seed；Gemini和Kimi发送temperature=1、topP=0.95、seed=0。实际原/上游请求SHA与原始usage保存在ledger中。

这批运行时以op字段驱动，和旧615例的action运行时不同。因此使用独立冻结入口 runner/redact_bench.py，旧benchmark代码、数据、轨迹及分数保持不变。两套源runtime文件原样复制，仅把步骤存储替换成保留全部记录的磁盘journal，已核对与普通列表记录完全等价。

## 资源与恢复

最多12路并发、1280 MiB内存准入预算，每进程512 MiB地址空间限额，MALLOC_ARENA_MAX=2。服务独立托管于用户systemd，密钥经隐藏输入及一次性本机Unix socket传入进程内存，不写入代码或配置。首次准备与服务启动发生过一次顺序冲突，未发起模型调用，相关日志保留；数据冻结完成后服务已正常启动。

模型回合append并fsync；续跑校验原配置、数据、代码与历史prompt SHA，只恢复未终止的案例。损坏的未完成尾行单独备份后恢复；已完成轨迹不重采样。每案例完成后自动check-run与export；每模型全部50份导出完成后自动生成all50.zip。

## 路径

- status.json：四模型分组进度、并发、内存与导出数。
- session-binding.json：200条选择、源版本、接口、固定历史和预算、代码SHA。
- frozen-data/：本轮冻结的hard_case_50原数据副本。
- runner/redact_bench.py：独立的run / check-run / export入口。
- <model>/runs/<h001...h050>/：run_config、全部turns.jsonl、全部steps.jsonl及源world-record.json。
- <model>/exports/：50份通过回放的案例ZIP。
- <model>-all50.zip：该模型全部50份完成后的汇总包。
- upstream-requests.jsonl：实际接口、model、返回model、usage、SHA、错误和延迟，不保存密钥。
- launcher.json、supervisor.log：后台服务与运行日志。

行为运行阶段不自动给语义分；上述独立judge阶段由用户后续授权启动。h001...h050保留原c/h/n/p内部case身份，映射以manifest为准。

离线测试覆盖：两套runtime步骤记录逐字节等价；25轮历史只进入最后20轮；27步真实执行模拟、断点续跑、未完成journal尾行恢复、严格prompt/body回放及ZIP导出。首批真实模型请求已成功，已有真实终止案例通过回放导出。

## 运行中延迟与调度修复

诊断发现共享队列令Kimi占据8/12个槽位，其他三个模型只有1–2路。已新增Opus、Gemini、GPT各2个独立辅助槽位，总上限18，继续使用原冻结入口、原路由与原案例。按内存实时准入，仍限制1280 MiB。当前单请求中位耗时约Opus14秒、Gemini24秒、GPT17秒、Kimi122秒；worker累计CPU时间不足1秒，主要在等待上游。

原本本地中转socket等待300秒，记录中有Kimi请求391秒才完成，导致本地提前超时后重复调用。新增只作用于冻结hard runner的启动钩子，对未来进程延长本地中转等待到1200秒，模型参数和模拟时间不变。旧Kimi worker已请求在当前响应落盘后退出，由原监督器按原断点续跑；不强制中断正在返回的回答。

并发用例锁防止主、辅工作者重复测试同一案例，已验证的导出复用。辅助从尚未启动的尾部案例开始，主程序以后到达时直接复用已完成结果。原200条选择和History20绑定没有变化。

Kimi高吞吐别名也做了诊断：同一历史窗口prompt在旧路由历史耗时38秒，在highspeed路由本次耗时90秒；单样本没有证明替换路由可稳定加速，因此本轮不改Kimi路由。该诊断不计入200条成绩。

合并进度与内存见acceleration-status.json，辅助日志见helpers.log和helper-logs，版本和固定参数证明见acceleration-binding.json。

## 第二次并发扩容

运行约4小时后，用户要求继续提高并发。原服务和6路辅助均保留，新增14路（Opus/Gemini/GPT各2路，Kimi8路），总进程上限32。新增工作者选择尚未启动的中部案例，既有用例锁保证与主、辅服务碰到同一案例时复用结果，原请求未中断。实时内存准入预算仍为1280 MiB，扩容初期实际30路、总RSS约887 MiB。已完成的测试不会重跑，原模型路由、History20、输出和请求预算不变。

实时总并发和全模型进度请看 expanded-status.json；原acceleration-status.json只包含第一次扩容服务的辅助统计。新增服务见 expanded-launcher.json，配置与源码SHA见 expanded-binding.json，日志见 expanded-helpers.log。

## Token 配额与收尾恢复

扩容后，上游明确返回HTTP 429，提示每模型1000000 tokens / 60 seconds。增加worker不能绕过该配额。独立token broker在127.0.0.1:18951按模型预留输入及最大输出预算，成功后按真实usage结算，遵守服务端retry-after；目标窗口为900000 tokens。原native payload、模型路由、History20、冻结runner和数据绑定不变。

启动钩子仅重定向本地传输，并把本地等待上限延长至1200秒。旧worker在当前响应写入journal后按同一配置续跑。两份接口ledger都保留：upstream-requests.jsonl记录原broker，upstream-requests-token-aware.jsonl记录新broker；成功行可能保留已恢复的429信息，以最终status=200为准。token-broker-status.json提供运行状态，token-broker-binding.json保留版本证明。

completion-status.json是独立收尾监督状态。收尾服务在原三组worker池全部退出后，才恢复剩余的未终止案例，避免为现有32路增加并发槽位。它继续使用冻结入口与原目录--resume，复用已验证的导出，对缺少导出的终止案例执行check-run和export，最终生成每模型all50.zip。这样不会因原监督器重试次数耗尽而遗漏案例。

连续429仍会耗尽第一版中转层的4次重试，因此后续请求已重定向到18952的v2 broker。它在中转层最多重试12次，保留每次限流事件，成功回答只记录一次；native socket等待延长到600秒，本地仍为1200秒。除了每模型预算，还增加四模型合计的保守窗口预算，初始850000 tokens，按限流反馈在500000–900000内调节。这是本地调度约束，不代表已证实上游的配额共享方式。

v2按原usage统计Gemini thoughts以及Anthropic cache输入，计入同一key正在收尾的旧broker用量。原请求payload与回复内容保持一致，运行中已有回答完成，新请求自动读取当前本地重定向配置，无需再次中断worker。v2状态和证明分别见token-broker-v2-status.json、token-broker-v2-binding.json；其接口日志单独保存在upstream-requests-token-aware-v2.jsonl。离线验证连续4次429后仍能返回原回答，5次native请求payload一致，且含thinking/cache的token用量结算正确。

## 2026-11-24 晚间排查

21:32核查时仍有99份完成导出，过去约80分钟没有新增完整案例。最近20分钟成功的Opus/GPT请求约95%的时间在配额等待，native执行中位耗时分别约10秒与7秒；以进程存活或HTTP成功数代表案例完成会误导进度判断。

极短的四模型原生请求也均被429拒绝，响应头Ratelimit-Remaining为0；对本轮relay暂停55秒并自动恢复后，极短请求仍显示剩余配额0。该诊断不能单独确定外部共用请求或代理内部扣额原因，报告分别保存为small-prompt-quota-diagnostic.json和quota-reset-diagnostic.json，均不计入200条评测。已向用户核实key是否共用。

新增3个受1280 MiB内存准入控制的优先恢复槽位，专门恢复10分钟以上无人运行的infrastructure_error，优先选择已执行步数较多的案例。总案例槽位上限因此为35；模型API仍统一受原配额broker调度。初选为Opus h020（42步）、Gemini h041（49步）、GPT h020（57步），GPT原57步轨迹已离线回放通过。已完成轨迹继续复用，History20和冻结绑定不变。该服务状态为priority-recovery-status.json；expanded-status.json的最大槽位字段仍属于原32路服务。
