"""Preserve all model payloads while pacing against the proxy's per-model TPM cap."""
import argparse
import json
import os
from pathlib import Path
import re
import signal
import socket
import sys
import threading
import time
import urllib.error
import urllib.request
import uuid

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'github_test_bundle/eval'))
sys.path.insert(0, str(ROOT / 'script'))
import run_hard_case_50 as old
from hard_case_bench import compact, digest, write


class Broker(old.Bridge):
    def __init__(self, address, key, root, routes):
        super().__init__(address, key, root, routes)
        self.RequestHandlerClass = Handler
        self.condition = threading.Condition()
        self.charges = {m: {} for m in routes}
        self.cooldown = {m: 0. for m in routes}
        self.factors = {m: .25 for m in routes}

    def reserve(self, model, text, output_tokens):
        identity = uuid.uuid4().hex
        with self.condition:
            while not old.STOP.is_set():
                now = time.monotonic()
                self.charges[model] = {k: v for k, v in self.charges[model].items() if v['pending'] or v['expires'] > now}
                estimated = int(len(text) * self.factors[model] * 1.1) + output_tokens
                if now >= self.cooldown[model] and sum(v['tokens'] for v in self.charges[model].values()) + estimated <= 900000:
                    self.charges[model][identity] = {'tokens': estimated, 'pending': True, 'expires': now + 60}
                    return identity
                self.condition.wait(1)
        raise InterruptedError('Broker stopped')

    def complete(self, model, identity, usage, text_chars, retry_after=None):
        with self.condition:
            if retry_after is not None:
                self.charges[model].pop(identity, None)
                self.cooldown[model] = max(self.cooldown[model], time.monotonic() + retry_after + 2)
            else:
                input_tokens = usage.get('input_tokens', usage.get('prompt_tokens', usage.get('promptTokenCount', 0))) or 0
                output_tokens = usage.get('output_tokens', usage.get('completion_tokens', usage.get('candidatesTokenCount', 0))) or 0
                if text_chars and input_tokens:
                    measured = input_tokens / text_chars
                    self.factors[model] = max(.15, min(.6, self.factors[model] * .7 + measured * .3))
                entry = self.charges[model].get(identity)
                if entry:
                    entry.update(tokens=input_tokens + output_tokens or entry['tokens'], pending=False, expires=time.monotonic() + 60)
            self.condition.notify_all()

    def record(self, row):
        with self.guard, (self.output / 'upstream-requests-token-aware.jsonl').open('a') as f:
            f.write(compact(row).replace(self.key, '[REDACTED]') + '\n')


class Handler(old.Handler):
    def do_POST(self):
        import hmac
        if self.path != '/v1/chat/completions' or not hmac.compare_digest(self.headers.get('Authorization', ''), 'Bearer ' + self.server.key):
            self.reply(401, {'error': 'Invalid local request'});return
        started = time.monotonic()
        row = {'started_at': time.time(), 'case': self.headers.get('X-Hard-Case'), 'status': 502, 'transport_revision': 'token-aware-v1'}
        identity, model = None, None
        try:
            local = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            model = local['model'];route = self.server.routes[model]
            native = old.translate(route, local);text = local['messages'][0]['content']
            row.update(model_key=model, routed_model=route['model'], prompt_characters=len(text),
                       local_request_sha256=digest(local), upstream_request_sha256=digest(native))
            headers = {'Authorization': 'Bearer ' + self.server.key, 'Content-Type': 'application/json'}
            if route['protocol'] == 'messages':headers.update({'x-api-key': self.server.key, 'anthropic-version': '2023-06-01'})
            for attempt in range(4):
                wait = time.monotonic();identity = self.server.reserve(model, text, local['max_tokens'])
                row['token_wait_seconds'] = round(time.monotonic() - wait, 3)
                try:
                    req = urllib.request.Request(route['endpoint'], compact(native).encode(), headers)
                    with urllib.request.urlopen(req, timeout=300) as response:raw = json.load(response)
                    visible, reported, usage, finish = old.normalize(route, raw)
                    self.server.complete(model, identity, usage, len(text));identity = None
                    row.update(status=200, reported_model=reported, usage=usage, finish_reason=finish, attempts=attempt + 1)
                    self.reply(200, {'model': reported, 'choices': [{'message': {'content': visible, 'role': 'assistant'}, 'finish_reason': finish}], 'usage': usage})
                    break
                except urllib.error.HTTPError as exc:
                    message = exc.read(2000).decode(errors='replace').replace(self.server.key, '[REDACTED]')
                    match = re.search(r'retry after (\d+) seconds', message, re.I)
                    delay = int(match.group(1)) if match else 30
                    self.server.complete(model, identity, {}, len(text), retry_after=delay);identity = None
                    row.update(status=exc.code, error=message)
                    if exc.code != 429 or attempt == 3:
                        self.reply(exc.code, {'error': message});break
        except Exception as exc:
            if identity and model:self.server.complete(model, identity, {}, 0, retry_after=5)
            row.update(status=502, error=type(exc).__name__ + ': ' + str(exc).replace(self.server.key, '[REDACTED]'))
            self.reply(502, {'error': row['error']})
        finally:
            row['seconds'] = round(time.monotonic() - started, 3);self.server.record(row)


def main():
    p = argparse.ArgumentParser();p.add_argument('--output', type=Path, required=True);p.add_argument('--port', type=int, default=18951);p.add_argument('--credential-socket');args=p.parse_args()
    root=args.output.resolve();session=json.loads((root/'session-binding.json').read_text())
    if args.credential_socket:
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as client:
            client.connect(args.credential_socket);data=b''
            while len(data)<=1024:
                chunk=client.recv(1024)
                if not chunk:break
                data+=chunk
            os.environ['REDACT_API_KEY']=data.decode()
    signal.signal(signal.SIGTERM,lambda *_:old.STOP.set());signal.signal(signal.SIGINT,lambda *_:old.STOP.set())
    threading.stack_size(1024*1024)
    server=Broker(('127.0.0.1',args.port),os.environ['REDACT_API_KEY'],root,session['model_routes'])
    threading.Thread(target=server.serve_forever,daemon=True).start()
    while not old.STOP.wait(5):
        with server.condition:
            write(root/'token-broker-status.json',{'pid':os.getpid(),'status':'running','port':args.port,
                 'per_model_limit':1000000,'target_window_tokens':900000,'input_factors':server.factors,
                 'reserved_tokens':{m:sum(v['tokens'] for v in entries.values()) for m,entries in server.charges.items()},'updated_at':time.time()})
    server.shutdown();server.server_close()


if __name__=='__main__':main()
