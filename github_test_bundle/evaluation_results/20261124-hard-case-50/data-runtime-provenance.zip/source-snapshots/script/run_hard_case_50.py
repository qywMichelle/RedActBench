"""Run four requested models over the frozen hard-case collection, 50 cases each."""
import argparse
import base64
from concurrent.futures import ThreadPoolExecutor
import copy
import hashlib
import hmac
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
from pathlib import Path
import queue
import shutil
import signal
import socket
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent.parent
BUNDLE = ROOT / 'github_test_bundle'
PYTHON = BUNDLE / '.venv/bin/python'
STOP = threading.Event()
MIB = 1024 * 1024
sys.path.insert(0, str(BUNDLE / 'eval'))
sys.path.insert(0, str(ROOT / 'script'))
from hard_case_bench import compact, digest, sha, write

ROUTES = {
    'opus-5.5': {'model': 'claude-opus-5-5-hc', 'protocol': 'messages', 'endpoint': 'https://mp.z01.normandyfunc.com/v1/messages'},
    'gemini-3.8-flash': {'model': 'gemini-3.8-flash:post-evaluation', 'protocol': 'gemini', 'endpoint': 'https://mp.z01.normandyfunc.com/gemini/v1beta/models/gemini-3.8-flash%3Apost-evaluation:generateContent'},
    'gpt-6.1-sol': {'model': 'gpt-6.1-sol-science', 'protocol': 'responses', 'endpoint': 'https://mp.z01.normandyfunc.com/v1/responses'},
    'kimi-3.1-pro': {'model': 'kimi-k3.1-pro-lucas', 'protocol': 'chat', 'endpoint': 'https://mp.z01.normandyfunc.com/v1/chat/completions'},
}


def translate(route, local):
    text = local['messages'][0]['content']
    if route['protocol'] == 'messages':
        return {'model': route['model'], 'messages': [{'role': 'user', 'content': [{'type': 'text', 'text': text}]}],
                'max_tokens': local['max_tokens'], 'temperature': 1.}
    if route['protocol'] == 'responses':
        return {'model': route['model'], 'input': [{'role': 'user', 'content': [{'type': 'input_text', 'text': text}]}],
                'max_output_tokens': local['max_tokens'], 'store': False}
    if route['protocol'] == 'gemini':
        return {'model': route['model'], 'contents': [{'role': 'user', 'parts': [{'text': text}]}],
                'generationConfig': {'temperature': 1., 'maxOutputTokens': local['max_tokens'], 'topP': .95, 'seed': 0},
                'toolConfig': {'functionCallingConfig': {'mode': 'NONE'}}}
    return dict(local, model=route['model'])


def normalize(route, raw):
    protocol = route['protocol']
    if protocol == 'gemini':
        candidates = raw.get('candidates', [])
        text = ''.join(p.get('text', '') for c in candidates for p in c.get('content', {}).get('parts', []) if not p.get('thought'))
        return text, raw.get('modelVersion'), raw.get('usageMetadata', {}), candidates[0].get('finishReason') if candidates else raw.get('promptFeedback')
    if protocol == 'messages':
        return ''.join(p.get('text', '') for p in raw.get('content', []) if p.get('type') == 'text'), raw.get('model'), raw.get('usage', {}), raw.get('stop_reason')
    if protocol == 'responses':
        text = ''.join(p.get('text', '') for item in raw.get('output', []) if item.get('type') == 'message' for p in item.get('content', []) if p.get('type') == 'output_text')
        return text, raw.get('model'), raw.get('usage', {}), raw.get('status')
    choice = raw.get('choices', [{}])[0]
    return choice.get('message', {}).get('content') or '', raw.get('model'), raw.get('usage', {}), choice.get('finish_reason')


class Bridge(ThreadingHTTPServer):
    daemon_threads = True
    def __init__(self, address, key, output, routes):
        super().__init__(address, Handler)
        self.key, self.output, self.routes = key, output, routes
        self.guard = threading.Lock()
        self.pacing = {m: {'interval': .1, 'next': 0., 'limits': 0} for m in routes}

    def pace(self, model):
        while not STOP.is_set():
            with self.guard:
                state = self.pacing[model]
                now = time.monotonic()
                if now >= state['next']:
                    state['next'] = now + state['interval']
                    return
                wait = min(.25, state['next'] - now)
            STOP.wait(wait)

    def record(self, row):
        with self.guard:
            if row['status'] == 429:
                state = self.pacing[row['model_key']]
                state['interval'] = min(20., max(1., state['interval'] * 2))
                state['limits'] += 1
                state['next'] = time.monotonic() + 20
            with (self.output / 'upstream-requests.jsonl').open('a') as f:
                f.write(compact(row).replace(self.key, '[REDACTED]') + '\n')


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *_):
        pass
    def reply(self, status, data):
        try:
            payload = compact(data).replace(self.server.key, '[REDACTED]').encode()
            self.send_response(status);self.send_header('Content-Type', 'application/json');self.send_header('Content-Length', str(len(payload)));self.end_headers();self.wfile.write(payload)
        except (BrokenPipeError, ConnectionResetError):
            pass
    def do_POST(self):
        if self.path != '/v1/chat/completions' or not hmac.compare_digest(self.headers.get('Authorization', ''), 'Bearer ' + self.server.key):
            self.reply(401, {'error': 'Invalid local request'});return
        started = time.monotonic()
        row = {'started_at': time.time(), 'case': self.headers.get('X-Hard-Case'), 'status': 502}
        try:
            length = int(self.headers.get('Content-Length', 0))
            if not 0 < length <= 4 * MIB:
                raise ValueError('Request byte budget exceeded')
            local = json.loads(self.rfile.read(length));model = local['model'];route = self.server.routes[model]
            native = translate(route, local);row.update(model_key=model, routed_model=route['model'], protocol=route['protocol'],
                local_request_sha256=digest(local), upstream_request_sha256=digest(native))
            headers = {'Authorization': 'Bearer ' + self.server.key, 'Content-Type': 'application/json'}
            if route['protocol'] == 'messages':headers.update({'x-api-key': self.server.key, 'anthropic-version': '2023-06-01'})
            for attempt in range(3):
                self.server.pace(model)
                try:
                    req = urllib.request.Request(route['endpoint'], compact(native).encode(), headers)
                    with urllib.request.urlopen(req, timeout=300) as response:raw = json.load(response)
                    text, reported, usage, finish = normalize(route, raw)
                    row.update(status=200, reported_model=reported, usage=usage, finish_reason=finish, attempts=attempt + 1)
                    self.reply(200, {'model': reported, 'choices': [{'message': {'role': 'assistant', 'content': text}, 'finish_reason': finish}], 'usage': usage})
                    break
                except urllib.error.HTTPError as exc:
                    detail = exc.read(2000).decode(errors='replace').replace(self.server.key, '[REDACTED]')
                    row.update(status=exc.code, error=detail, attempts=attempt + 1)
                    if exc.code == 429:
                        with self.server.guard:
                            state = self.server.pacing[model];state['interval'] = min(20., max(1., state['interval'] * 2));state['next'] = time.monotonic() + 20;state['limits'] += 1
                    if exc.code not in {429,500,502,503,504} or attempt == 2:
                        self.reply(exc.code, {'error': detail});break
                    STOP.wait(10 * (attempt + 1))
        except Exception as exc:
            row.update(status=502, error=type(exc).__name__ + ': ' + str(exc).replace(self.server.key, '[REDACTED]'))
            self.reply(502, {'error': row['error']})
        finally:
            row['seconds'] = round(time.monotonic() - started, 3)
            self.server.record(row)


class Supervisor:
    def __init__(self, output, session, key, workers, memory_mib):
        self.output, self.session = output, session
        self.workers, self.memory_mib = workers, memory_mib
        self.condition = threading.Condition()
        self.children, self.states = {}, {}
        self.peak = 0
        self.bridge = Bridge(('127.0.0.1', session['local_port']), key, output, session['model_routes'])

    def memory(self):
        def rss(pid):
            try:return next(int(s.split()[1])*1024 for s in Path(f'/proc/{pid}/status').read_text().splitlines() if s.startswith('VmRSS:'))
            except (OSError,StopIteration):return 0
        current = rss(os.getpid()) + sum(rss(pid) for pid in self.children)
        reserved = rss(os.getpid()) + sum(max(96*MIB,rss(pid)) for pid in self.children)
        self.peak = max(self.peak, current)
        return current, reserved

    def execute(self, command, log):
        with self.condition:
            while not STOP.is_set() and self.memory()[1]+96*MIB>self.memory_mib*MIB:self.condition.wait(1)
            if STOP.is_set():return 130
            with log.open('a') as f:
                child=subprocess.Popen(['prlimit','--as=536870912','--core=0','--',*map(str,command)],cwd=ROOT,
                    env=dict(os.environ,MALLOC_ARENA_MAX='2',PYTHONUNBUFFERED='1'),stdin=subprocess.DEVNULL,stdout=f,stderr=subprocess.STDOUT)
            self.children[child.pid]=child
        try:
            while child.poll() is None:
                if STOP.wait(1):
                    child.terminate()
                    try:child.wait(timeout=15)
                    except subprocess.TimeoutExpired:child.kill()
                    break
            return child.wait()
        finally:
            with self.condition:self.children.pop(child.pid,None);self.condition.notify_all()

    def worker(self, index, pending):
        runner=self.output/'runner/redact_bench.py'
        while not STOP.is_set():
            try:model,entry=pending.get_nowait()
            except queue.Empty:return
            case=entry['collection_id'];run=self.output/model/'runs'/case;log=self.output/model/'logs'/(case+'.log');log.parent.mkdir(parents=True,exist_ok=True)
            for attempt in range(6):
                command=[PYTHON,runner,'run','--output',run]
                if (run/'run_config.json').exists():command+=['--resume']
                else:command+=['--session',self.output/'session-binding.json','--model',model,'--case',case]
                with self.condition:self.states[str(index)]={'model':model,'case':case,'status':'running','attempt':attempt}
                code=self.execute(command,log)
                state=json.loads((run/'state.json').read_text()) if (run/'state.json').exists() else {}
                if state.get('status') in {'complete','request_limit','input_budget_exceeded'}:break
                if STOP.is_set():break
                if code and STOP.wait(min(120,15*(attempt+1))):break
            if state.get('status') in {'complete','request_limit','input_budget_exceeded'}:
                if self.execute([PYTHON,runner,'check-run','--run',run],log)==0:
                    archive=self.output/model/'exports'/(case+'.zip')
                    if not archive.exists():self.execute([PYTHON,runner,'export','--run',run,'--output',archive],log)
            with self.condition:self.states[str(index)]={'model':model,'case':case,'status':state.get('status','needs_attention')}

    def save(self):
        counts={m:{} for m in self.session['model_routes']};exports={}
        for m in counts:
            for p in (self.output/m/'runs').glob('*/state.json'):
                try:s=json.loads(p.read_text())
                except (OSError,ValueError):continue
                status=s.get('status');counts[m][status]=counts[m].get(status,0)+1
            exports[m]=len(list((self.output/m/'exports').glob('*.zip')))
        with self.condition:
            current,reserved=self.memory()
            write(self.output/'status.json',{'status':'running' if not STOP.is_set() else 'stopping','pid':os.getpid(),
                'planned_configurations':200,'history_window':20,'by_model':counts,'exported_cases':exports,
                'workers':self.states,'active_processes':len(self.children),'maximum_workers':self.workers,
                'rss_mib':round(current/MIB,2),'peak_rss_mib':round(self.peak/MIB,2),'reserved_mib':round(reserved/MIB,2),
                'memory_admission_limit_mib':self.memory_mib,'updated_at':time.time(),'semantic_scoring':False})

    def run(self):
        threading.stack_size(MIB);threading.Thread(target=self.bridge.serve_forever,daemon=True).start()
        pending=queue.Queue()
        for entry in self.session['episodes']:
            for model in self.session['model_routes']:pending.put((model,entry))
        with ThreadPoolExecutor(max_workers=self.workers) as pool:
            futures=[pool.submit(self.worker,str(i),pending) for i in range(self.workers)]
            while any(not f.done() for f in futures):self.save();STOP.wait(5)
            for f in futures:f.result()
        self.save();self.bridge.shutdown();self.bridge.server_close()
        final=json.loads((self.output/'status.json').read_text());complete=all(final['exported_cases'][m]==50 for m in self.session['model_routes'])
        final['status']='stopped' if STOP.is_set() else ('behavior_complete' if complete else 'needs_attention');write(self.output/'status.json',final)
        if complete:
            for model in self.session['model_routes']:
                archive=self.output/(model+'-all50.zip')
                if not archive.exists():
                    with zipfile.ZipFile(archive,'x',zipfile.ZIP_STORED) as z:
                        for p in sorted((self.output/model/'exports').glob('*.zip')):z.write(p,'exports/'+p.name)


def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--data',type=Path,default=BUNDLE/'data/hard_case_50');p.add_argument('--workers',type=int,default=12);p.add_argument('--memory-mib',type=int,default=1280);p.add_argument('--port',type=int,default=18950);p.add_argument('--credential-socket');p.add_argument('--prepare',action='store_true');args=p.parse_args()
    output=args.output.resolve();output.mkdir(parents=True,exist_ok=True)
    binding_path=output/'session-binding.json'
    if not binding_path.exists():
        frozen=output/'frozen-data';shutil.copytree(args.data.resolve(),frozen)
        runner=output/'runner';runner.mkdir(exist_ok=True);shutil.copyfile(ROOT/'script/hard_case_bench.py',runner/'redact_bench.py');shutil.copyfile(BUNDLE/'eval/revealed_context.py',runner/'revealed_context.py')
        manifest=json.loads((frozen/'manifest.json').read_text())
        session={'schema':'hard-case-four-model-session-v1','dataset_root':str(frozen),'source_data_root':str(args.data.resolve()),
            'manifest_sha256':sha(frozen/'manifest.json'),'distribution_sha256':sha(frozen/'DISTRIBUTION.json'),
            'episodes':manifest['episodes'],'model_routes':ROUTES,'history_window':20,'max_requests':400,
            'max_output_tokens':16384,'max_prompt_chars':600000,'local_port':args.port,
            'local_endpoint':f'http://127.0.0.1:{args.port}/v1/chat/completions',
            'runner_sha256':sha(runner/'redact_bench.py'),'history_encoder_sha256':sha(runner/'revealed_context.py'),
            'supervisor_source_sha256':sha(Path(__file__)),'semantic_scoring':False}
        write(binding_path,session)
    session=json.loads(binding_path.read_text())
    if sha(Path(__file__))!=session['supervisor_source_sha256'] or sha(output/'runner/redact_bench.py')!=session['runner_sha256']:
        raise ValueError('Session source changed; restore the original frozen code')
    if args.prepare:print(compact({'status':'prepared','cases':50,'models':4,'history_window':20,'output':str(output)}));return
    if args.credential_socket:
        with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as client:
            client.connect(args.credential_socket);data=bytearray()
            while len(data)<=1024:
                chunk=client.recv(1024)
                if not chunk:break
                data.extend(chunk)
            if not data or len(data)>1024:raise ValueError('Hidden key transfer failed')
            os.environ['REDACT_API_KEY']=bytes(data).decode()
    key=os.environ['REDACT_API_KEY'];signal.signal(signal.SIGTERM,lambda *_:STOP.set());signal.signal(signal.SIGINT,lambda *_:STOP.set())
    try:Supervisor(output,session,key,args.workers,args.memory_mib).run()
    except Exception as exc:
        STOP.set();write(output/'status.json',{'status':'needs_attention','error':str(exc).replace(key,'[REDACTED]'),'updated_at':time.time()});raise SystemExit(2)


if __name__=='__main__':main()
