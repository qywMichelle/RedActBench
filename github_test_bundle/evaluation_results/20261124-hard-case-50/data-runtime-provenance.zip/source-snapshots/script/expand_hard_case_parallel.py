"""Expand the existing cohort without changing routes, prompts or saved case bindings."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import signal
import sys
import time

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'script'))
import accelerate_hard_cases as base
from hard_case_bench import write, sha


class ExpandedHelpers(base.Helpers):
    def choose(self, model):
        with self.guard:
            available = []
            for entry in self.session['episodes']:
                run = self.root / model / 'runs' / entry['collection_id']
                if str(run) not in self.claimed and not (run / 'run_config.json').exists():
                    available.append((entry, run))
            if not available:
                return None
            entry, run = available[len(available) // 2]
            self.claimed.add(str(run))
            return entry, run

    def save(self):
        primary = json.loads((self.root / 'status.json').read_text())
        observed = base.memory(self.root)
        actual_workers = 0
        by_model = {}
        for pid in observed:
            try:
                argv = [a.decode(errors='replace') for a in Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0') if a]
                if '--output' in argv and 'run' in argv:
                    path = Path(argv[argv.index('--output') + 1])
                    if path.parent.name == 'runs':
                        actual_workers += 1
                        by_model[path.parent.parent.name] = by_model.get(path.parent.parent.name, 0) + 1
            except OSError:
                pass
        with self.guard:
            write(self.root / 'expanded-status.json', dict(primary, expanded_helper_pid=os.getpid(),
                expanded_helper_workers=self.states, expanded_helper_active_processes=len(self.children),
                combined_case_processes=actual_workers, combined_workers_by_model=by_model,
                total_rss_mib=round(sum(observed.values()) / 1024**2, 2), maximum_combined_workers=32,
                local_relay_timeout_seconds=1200, expanded_updated_at=time.time()))

    def run(self):
        allocation = {'opus-5.5': 2, 'gemini-3.8-flash': 2, 'gpt-6.1-sol': 2, 'kimi-3.1-pro': 8}
        with ThreadPoolExecutor(max_workers=14) as pool:
            futures = [pool.submit(self.worker, model, index) for model, count in allocation.items() for index in range(count)]
            while any(not f.done() for f in futures):
                self.save()
                base.STOP.wait(5)
            for f in futures:
                f.result()
        self.save()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--credential-socket')
    args = p.parse_args()
    root = args.output.resolve()
    session = json.loads((root / 'session-binding.json').read_text())
    if sha(root / 'runner/redact_bench.py') != session['runner_sha256']:
        raise ValueError('Original frozen runner changed')
    if args.credential_socket:
        import socket
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.connect(args.credential_socket)
            value = b''
            while len(value) <= 1024:
                chunk = client.recv(1024)
                if not chunk:
                    break
                value += chunk
        if not value or len(value) > 1024:
            raise ValueError('Credential delivery failed')
        os.environ['REDACT_API_KEY'] = value.decode()
    signal.signal(signal.SIGTERM, lambda *_: base.STOP.set())
    signal.signal(signal.SIGINT, lambda *_: base.STOP.set())
    write(root / 'expanded-binding.json', {'version': 'middle-unstarted-cases-32-slots-v1',
        'source_sha256': sha(Path(__file__)), 'helper_base_sha256': sha(ROOT / 'script/accelerate_hard_cases.py'),
        'session_sha256': sha(root / 'session-binding.json'), 'additional_workers': 14,
        'allocation': {'opus-5.5': 2, 'gemini-3.8-flash': 2, 'gpt-6.1-sol': 2, 'kimi-3.1-pro': 8},
        'maximum_combined_workers': 32, 'memory_admission_limit_mib': 1280,
        'frozen_model_routes_changed': False, 'history_window_changed': False,
        'inflight_requests_interrupted': False, 'started_at': time.time()})
    ExpandedHelpers(root).run()


if __name__ == '__main__':
    main()
