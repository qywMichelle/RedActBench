"""Give the three faster models independent extra slots on their original cases."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import subprocess
import threading
import time
import sys

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / 'github_test_bundle/eval'))
sys.path.insert(0, str(ROOT / 'script'))
from hard_case_bench import write, sha
import run_hard_case_50 as original
STOP = threading.Event()


def memory(root):
    values = {}
    prefix = str(root).encode()
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():
            continue
        try:
            argv = (p / 'cmdline').read_bytes().split(b'\0')
            if not any(a == prefix or a.startswith(prefix + b'/') for a in argv):
                continue
            values[int(p.name)] = next(int(s.split()[1]) * 1024 for s in (p / 'status').read_text().splitlines() if s.startswith('VmRSS:'))
        except (OSError, StopIteration):
            pass
    return values


class Helpers:
    def __init__(self, root):
        self.root = root
        self.session = json.loads((root / 'session-binding.json').read_text())
        self.guard = threading.Lock()
        self.claimed, self.children, self.states = set(), {}, {}

    def choose(self, model):
        with self.guard:
            for entry in reversed(self.session['episodes']):
                run = self.root / model / 'runs' / entry['collection_id']
                identity = str(run)
                if identity not in self.claimed and not (run / 'run_config.json').exists():
                    self.claimed.add(identity)
                    return entry, run
        return None

    def execute(self, command, log, index):
        while not STOP.is_set():
            with self.guard:
                observed = memory(self.root)
                outstanding = sum(max(0, 48 * 1024**2 - observed.get(pid, 0)) for pid in self.children)
                if sum(observed.values()) + outstanding + 176 * 1024**2 <= 1280 * 1024**2:
                    with log.open('a') as f:
                        child = subprocess.Popen(['prlimit', '--as=536870912', '--core=0', '--', *map(str, command)],
                            cwd=ROOT, env=dict(os.environ, MALLOC_ARENA_MAX='2', PYTHONUNBUFFERED='1'),
                            stdin=subprocess.DEVNULL, stdout=f, stderr=subprocess.STDOUT)
                    self.children[child.pid] = index
                    break
            STOP.wait(1)
        else:
            return 130
        try:
            while child.poll() is None:
                if STOP.wait(1):
                    child.terminate()
                    child.wait(timeout=15)
                    break
            return child.wait()
        finally:
            with self.guard:
                self.children.pop(child.pid, None)

    def worker(self, model, index):
        runner = self.root / 'runner/redact_bench.py'
        while not STOP.is_set():
            item = self.choose(model)
            if item is None:
                return
            entry, run = item
            log = self.root / 'helper-logs' / (model + '-' + str(index) + '.log')
            log.parent.mkdir(exist_ok=True)
            with self.guard:
                self.states[model + '/' + str(index)] = {'case': entry['collection_id'], 'status': 'running'}
            for attempt in range(6):
                command = [original.PYTHON, runner, 'run', '--output', run]
                if (run / 'run_config.json').exists():
                    command += ['--resume']
                else:
                    command += ['--session', self.root / 'session-binding.json', '--model', model, '--case', entry['collection_id']]
                self.execute(command, log, model + '/' + str(index))
                state = json.loads((run / 'state.json').read_text()) if (run / 'state.json').exists() else {}
                if state.get('status') in {'complete', 'request_limit', 'input_budget_exceeded'}:
                    break
                if STOP.wait(15 * (attempt + 1)):
                    break
            if state.get('status') in {'complete', 'request_limit', 'input_budget_exceeded'}:
                if self.execute([original.PYTHON, runner, 'check-run', '--run', run], log, index) == 0:
                    self.execute([original.PYTHON, runner, 'export', '--run', run,
                                  '--output', self.root / model / 'exports' / (entry['collection_id'] + '.zip')], log, index)

    def save(self):
        primary = json.loads((self.root / 'status.json').read_text())
        observed = memory(self.root)
        with self.guard:
            write(self.root / 'acceleration-status.json', dict(primary, helper_pid=os.getpid(),
                helper_workers=self.states, helper_active_processes=len(self.children),
                total_rss_mib=round(sum(observed.values()) / 1024**2, 2),
                maximum_combined_workers=18, local_relay_timeout_seconds=1200))

    def run(self):
        with ThreadPoolExecutor(max_workers=6) as pool:
            futures = [pool.submit(self.worker, model, index) for model in ['opus-5.5', 'gemini-3.8-flash', 'gpt-6.1-sol'] for index in range(2)]
            while any(not f.done() for f in futures):
                self.save()
                STOP.wait(5)
            for f in futures:
                f.result()
        self.save()


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--credential-socket')
    args = p.parse_args()
    if args.credential_socket:
        import socket
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
            client.connect(args.credential_socket)
            key = b''
            while len(key) <= 1024:
                chunk = client.recv(1024)
                if not chunk:
                    break
                key += chunk
            os.environ['REDACT_API_KEY'] = key.decode()
    import signal
    signal.signal(signal.SIGTERM, lambda *_: STOP.set())
    signal.signal(signal.SIGINT, lambda *_: STOP.set())
    Helpers(args.output.resolve()).run()


if __name__ == '__main__':
    main()
