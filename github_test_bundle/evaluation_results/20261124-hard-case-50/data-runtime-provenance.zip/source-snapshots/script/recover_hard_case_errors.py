"""Prioritize abandoned checkpoints without resampling completed hard cases."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import json
import os
from pathlib import Path
import signal
import socket
import sys
import time

PROJECT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT / 'script'))
import accelerate_hard_cases as base
from hard_case_bench import sha, write


def active_runs(root):
    runs = set()
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            argv = [v.decode(errors='replace') for v in (proc / 'cmdline').read_bytes().split(b'\0') if v]
            if str(root / 'runner/redact_bench.py') in argv and 'run' in argv and '--output' in argv:
                runs.add(argv[argv.index('--output') + 1])
        except OSError:
            pass
    return runs


class Recovery(base.Helpers):
    def choose(self, model):
        with self.guard:
            live = active_runs(self.root)
            eligible = []
            for entry in self.session['episodes']:
                run = self.root / model / 'runs' / entry['collection_id']
                statefile = run / 'state.json'
                if str(run) in self.claimed or str(run) in live or not statefile.exists():
                    continue
                state = json.loads(statefile.read_text())
                if state.get('status') == 'infrastructure_error' and time.time() - state.get('updated_at', 0) > 600:
                    eligible.append((state.get('requests', 0), entry, run))
            if eligible:
                _, entry, run = max(eligible, key=lambda item: item[0])
                self.claimed.add(str(run))
                return entry, run
        return None

    def execute(self, command, log, index):
        log = self.root / 'priority-recovery-logs' / log.name
        log.parent.mkdir(exist_ok=True)
        return super().execute(command, log, index)

    def model_worker(self, model):
        while not base.STOP.is_set():
            self.worker(model, 0)
            if all((self.root / model / 'exports' / (e['collection_id'] + '.zip')).exists()
                   for e in self.session['episodes']):
                return
            if base.STOP.wait(30):
                return
            # A later transient error can be recovered again under the same binding.
            with self.guard:
                self.claimed.clear()

    def save(self):
        with self.guard:
            write(self.root / 'priority-recovery-status.json', {'status': 'running', 'pid': os.getpid(),
                'workers': self.states, 'active_recovery_processes': len(self.children),
                'combined_case_processes': len(active_runs(self.root)), 'maximum_combined_workers': 35,
                'total_rss_mib': round(sum(base.memory(self.root).values()) / 1024**2, 2),
                'memory_admission_limit_mib': 1280, 'updated_at': time.time()})

    def run(self):
        with ThreadPoolExecutor(max_workers=3) as pool:
            futures = [pool.submit(self.model_worker, model) for model in
                       ['opus-5.5', 'gemini-3.8-flash', 'gpt-6.1-sol']]
            while any(not f.done() for f in futures):
                self.save()
                base.STOP.wait(5)
            for future in futures:
                future.result()
        self.save()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--credential-socket', required=True)
    args = parser.parse_args(); root = args.output.resolve()
    session = json.loads((root / 'session-binding.json').read_text())
    if sha(root / 'runner/redact_bench.py') != session['runner_sha256']:
        raise ValueError('Frozen runner changed')
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
        client.connect(args.credential_socket); key = bytearray()
        while len(key) <= 1024:
            chunk = client.recv(1024)
            if not chunk:
                break
            key.extend(chunk)
    if not key or len(key) > 1024:
        raise ValueError('Credential delivery failed')
    os.environ['REDACT_API_KEY'] = key.decode()
    signal.signal(signal.SIGTERM, lambda *_: base.STOP.set())
    write(root / 'priority-recovery-binding.json', {'source_sha256': sha(Path(__file__)),
        'session_sha256': sha(root / 'session-binding.json'), 'additional_case_slots': 3,
        'maximum_combined_workers': 35, 'memory_admission_limit_mib': 1280,
        'selection': 'inactive infrastructure_error older than 600 seconds, most requests first',
        'model_routes_changed': False, 'history_changed': False, 'started_at': time.time()})
    Recovery(root).run()


if __name__ == '__main__':
    main()
