"""Quota-aware relay with a shared-key budget and bounded in-relay retries."""
import argparse
import hmac
import json
import os
from pathlib import Path
import re
import signal
import socket
import threading
import time
import urllib.error
import urllib.request

import hard_token_broker as base


def tokens(usage):
    incoming = usage.get('input_tokens', usage.get('prompt_tokens', usage.get('promptTokenCount', 0))) or 0
    if 'input_tokens' in usage:
        incoming += usage.get('cache_creation_input_tokens', 0) + usage.get('cache_read_input_tokens', 0)
    outgoing = usage.get('output_tokens', usage.get('completion_tokens', usage.get('candidatesTokenCount', 0))) or 0
    outgoing += usage.get('thoughtsTokenCount', 0)
    total = max(incoming + outgoing, usage.get('total_tokens', usage.get('totalTokenCount', 0)) or 0)
    return incoming, total


class Broker(base.Broker):
    def __init__(self, address, key, root, routes):
        super().__init__(address, key, root, routes)
        self.RequestHandlerClass = Handler
        self.shared_budget = 850000
        self.last_limit = 0.
        self.legacy = (root / 'upstream-requests-token-aware.jsonl').open()
        self.sync_legacy()
        status = root / 'token-broker-status.json'
        if status.exists():
            previous = json.loads(status.read_text())
            for model, amount in previous.get('reserved_tokens', {}).items():
                if model in self.charges:
                    accounted = sum(v['tokens'] for v in self.charges[model].values())
                    self.charges[model]['legacy-inflight-buffer'] = {
                        'tokens': max(0, amount - accounted), 'pending': False,
                        'expires': time.monotonic() + 60}

    def sync_legacy(self):
        # Account for responses still draining from the previous relay.
        position = self.legacy.tell()
        while True:
            line = self.legacy.readline()
            if not line or not line.endswith('\n'):
                self.legacy.seek(position)
                break
            position = self.legacy.tell()
            row = json.loads(line)
            finished = row['started_at'] + row['seconds']
            if row.get('status') == 200 and finished > time.time() - 60:
                model = row['model_key']
                self.charges[model]['legacy-' + str(position)] = {
                    'tokens': tokens(row.get('usage', {}))[1], 'pending': False,
                    'expires': time.monotonic() + max(0, 60 - (time.time() - finished))}

    def reserve(self, model, text, output_tokens):
        import uuid
        identity = uuid.uuid4().hex
        with self.condition:
            while not base.old.STOP.is_set():
                self.sync_legacy()
                now = time.monotonic()
                for m in self.charges:
                    self.charges[m] = {k: v for k, v in self.charges[m].items()
                                       if v['pending'] or v['expires'] > now}
                estimated = int(len(text) * self.factors[model] * 1.15) + output_tokens
                model_used = sum(v['tokens'] for v in self.charges[model].values())
                total_used = sum(v['tokens'] for entries in self.charges.values() for v in entries.values())
                if now >= self.cooldown[model] and model_used + estimated <= 900000 and total_used + estimated <= self.shared_budget:
                    self.charges[model][identity] = {'tokens': estimated, 'pending': True, 'expires': now + 60}
                    return identity
                self.condition.wait(1)
        raise InterruptedError('Broker stopped')

    def complete(self, model, identity, usage, text_chars, retry_after=None):
        incoming, total = tokens(usage)
        super().complete(model, identity, {'input_tokens': incoming, 'output_tokens': total - incoming},
                         text_chars, retry_after=retry_after)
        with self.condition:
            if retry_after is not None:
                self.last_limit = time.monotonic()
                self.shared_budget = max(500000, int(self.shared_budget * .95))
            elif time.monotonic() - self.last_limit > 120:
                self.shared_budget = min(900000, self.shared_budget + 2500)

    def record(self, row):
        with self.guard, (self.output / 'upstream-requests-token-aware-v2.jsonl').open('a') as stream:
            stream.write(base.compact(row).replace(self.key, '[REDACTED]') + '\n')


class Handler(base.old.Handler):
    def do_POST(self):
        if self.path != '/v1/chat/completions' or not hmac.compare_digest(self.headers.get('Authorization', ''), 'Bearer ' + self.server.key):
            self.reply(401, {'error': 'Invalid local request'})
            return
        started = time.monotonic()
        row = {'started_at': time.time(), 'case': self.headers.get('X-Hard-Case'), 'status': 502,
               'transport_revision': 'token-aware-v2', 'retry_events': [], 'token_wait_seconds': 0.}
        model = identity = None
        try:
            length = int(self.headers['Content-Length'])
            if not 0 < length <= 4 * 1024**2:
                raise ValueError('Request byte budget exceeded')
            local = json.loads(self.rfile.read(length))
            model = local['model']; route = self.server.routes[model]
            native = base.old.translate(route, local); text = local['messages'][0]['content']
            row.update(model_key=model, routed_model=route['model'], protocol=route['protocol'],
                       prompt_characters=len(text), local_request_sha256=base.digest(local),
                       upstream_request_sha256=base.digest(native))
            headers = {'Authorization': 'Bearer ' + self.server.key, 'Content-Type': 'application/json'}
            if route['protocol'] == 'messages':
                headers.update({'x-api-key': self.server.key, 'anthropic-version': '2023-06-01'})
            for attempt in range(12):
                wait = time.monotonic(); identity = self.server.reserve(model, text, local['max_tokens'])
                row['token_wait_seconds'] += round(time.monotonic() - wait, 3)
                try:
                    request = urllib.request.Request(route['endpoint'], base.compact(native).encode(), headers)
                    with urllib.request.urlopen(request, timeout=600) as response:
                        raw = json.load(response)
                    visible, reported, usage, finish = base.old.normalize(route, raw)
                    self.server.complete(model, identity, usage, len(text)); identity = None
                    row.update(status=200, reported_model=reported, usage=usage, finish_reason=finish, attempts=attempt + 1)
                    self.reply(200, {'model': reported, 'choices': [{'message': {'content': visible, 'role': 'assistant'},
                                                                 'finish_reason': finish}], 'usage': usage})
                    break
                except urllib.error.HTTPError as error:
                    message = error.read(2000).decode(errors='replace').replace(self.server.key, '[REDACTED]')
                    match = re.search(r'retry after (\d+) seconds', message, re.I)
                    delay = int(match.group(1)) if match else 30
                    self.server.complete(model, identity, {}, len(text), retry_after=delay); identity = None
                    row.update(status=error.code, attempts=attempt + 1)
                    row['retry_events'].append({'status': error.code, 'retry_after_seconds': delay, 'error': message})
                    if error.code != 429 or attempt == 11 or time.monotonic() - started > 900:
                        self.reply(error.code, {'error': message})
                        break
        except Exception as error:
            if identity and model:
                self.server.complete(model, identity, {}, 0, retry_after=5)
            row.update(status=502, error=type(error).__name__ + ': ' + str(error).replace(self.server.key, '[REDACTED]'))
            self.reply(502, {'error': row['error']})
        finally:
            row['seconds'] = round(time.monotonic() - started, 3)
            self.server.record(row)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--port', type=int, default=18952)
    parser.add_argument('--credential-socket', required=True)
    args = parser.parse_args(); root = args.output.resolve()
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
        client.connect(args.credential_socket); key = bytearray()
        while len(key) <= 1024:
            chunk = client.recv(1024)
            if not chunk:
                break
            key.extend(chunk)
    if not key or len(key) > 1024:
        raise ValueError('Credential delivery failed')
    signal.signal(signal.SIGTERM, lambda *_: base.old.STOP.set())
    threading.stack_size(1024**2)
    session = json.loads((root / 'session-binding.json').read_text())
    server = Broker(('127.0.0.1', args.port), key.decode(), root, session['model_routes'])
    threading.Thread(target=server.serve_forever, daemon=True).start()
    while not base.old.STOP.wait(5):
        with server.condition:
            base.write(root / 'token-broker-v2-status.json', {'pid': os.getpid(), 'status': 'running',
                'port': args.port, 'model_window_budget': 900000, 'shared_key_window_budget': server.shared_budget,
                'reserved_tokens': {m: sum(v['tokens'] for v in entries.values()) for m, entries in server.charges.items()},
                'input_factors': server.factors, 'updated_at': time.time()})
    server.shutdown(); server.server_close()


if __name__ == '__main__':
    main()
