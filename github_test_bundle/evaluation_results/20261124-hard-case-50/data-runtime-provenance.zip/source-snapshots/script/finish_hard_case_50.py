"""Recover any residual hard cases after the original worker pools have drained."""
import argparse
from concurrent.futures import ThreadPoolExecutor
import fcntl
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import threading
import time
import zipfile

PROJECT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT / 'script'))
from accelerate_hard_cases import memory
from hard_case_bench import sha, write

TERMINAL = {'complete', 'request_limit', 'input_budget_exceeded'}
CONTROLLERS = {'run_hard_case_50.py', 'accelerate_hard_cases.py', 'expand_hard_case_parallel.py'}
STOP = threading.Event()


def controllers(root):
    found = []
    for proc in Path('/proc').glob('[0-9]*'):
        try:
            argv = [a.decode(errors='replace') for a in (proc / 'cmdline').read_bytes().split(b'\0') if a]
            if str(root) in argv and any(Path(a).name in CONTROLLERS for a in argv):
                found.append(int(proc.name))
        except OSError:
            pass
    return found


class Finisher:
    def __init__(self, root):
        self.root = root
        self.session = json.loads((root / 'session-binding.json').read_text())
        self.runner = root / 'runner/redact_bench.py'
        if sha(self.runner) != self.session['runner_sha256']:
            raise ValueError('Frozen runner changed')
        self.python = PROJECT / 'github_test_bundle/.venv/bin/python'
        self.guard = threading.Lock()
        self.children = {}
        self.errors = {}

    def save(self, status):
        counts, exports = {}, {}
        for model in self.session['model_routes']:
            counts[model] = {}
            for state in (self.root / model / 'runs').glob('*/state.json'):
                value = json.loads(state.read_text())['status']
                counts[model][value] = counts[model].get(value, 0) + 1
            exports[model] = len(list((self.root / model / 'exports').glob('*.zip')))
        with self.guard:
            write(self.root / 'completion-status.json', {'status': status, 'pid': os.getpid(),
                'original_controllers': controllers(self.root), 'by_model': counts, 'exported_cases': exports,
                'recovery_processes': self.children, 'errors': self.errors,
                'history_window': 20, 'semantic_scoring': False, 'updated_at': time.time()})

    def execute(self, args, run):
        while not STOP.is_set():
            with self.guard:
                observed = memory(self.root)
                pending = sum(max(0, 48 * 1024**2 - observed.get(pid, 0)) for pid in self.children)
                if sum(observed.values()) + pending + 176 * 1024**2 <= 1280 * 1024**2:
                    log = self.root / 'recovery-logs' / (run.parent.parent.name + '-' + run.name + '.log')
                    log.parent.mkdir(exist_ok=True)
                    with log.open('a') as output:
                        child = subprocess.Popen(['prlimit', '--as=536870912', '--core=0', '--',
                            str(self.python), str(self.runner), *map(str, args)], cwd=PROJECT,
                            env=dict(os.environ, MALLOC_ARENA_MAX='2', PYTHONUNBUFFERED='1'),
                            stdin=subprocess.DEVNULL, stdout=output, stderr=subprocess.STDOUT)
                    self.children[child.pid] = str(run.relative_to(self.root))
                    break
            STOP.wait(1)
        else:
            return 130
        try:
            interrupted = False
            while child.poll() is None:
                if STOP.wait(1) and not interrupted:
                    child.terminate()  # The runner journals the in-flight response before stopping.
                    interrupted = True
            return child.returncode
        finally:
            with self.guard:
                self.children.pop(child.pid, None)

    def finish(self, model, episode):
        run = self.root / model / 'runs' / episode['collection_id']
        identity = str(run.relative_to(self.root))
        attempt = 0
        while not STOP.is_set():
            state = json.loads((run / 'state.json').read_text()) if (run / 'state.json').exists() else {}
            if state.get('status') in TERMINAL:
                break
            args = ['run', '--output', run]
            if (run / 'run_config.json').exists():
                args += ['--resume']
            else:
                args += ['--session', self.root / 'session-binding.json', '--model', model,
                         '--case', episode['collection_id']]
            self.execute(args, run)
            state = json.loads((run / 'state.json').read_text()) if (run / 'state.json').exists() else {}
            if state.get('status') in TERMINAL:
                break
            error = state.get('error', '')
            # Persistent configuration/authentication failures need attention, not repeated paid calls.
            if any(s in error for s in ['HTTP Error 401', 'HTTP Error 403', 'SHA mismatch', 'Binding mismatch']):
                with self.guard:
                    self.errors[identity] = error
                return
            attempt += 1
            for _ in range(min(600, 15 * attempt)):
                if STOP.wait(1):
                    return
        if STOP.is_set():
            return
        archive = self.root / model / 'exports' / (episode['collection_id'] + '.zip')
        if archive.exists():
            return
        if self.execute(['check-run', '--run', run], run) != 0:
            with self.guard:
                self.errors[identity] = 'check-run failed; see recovery log'
            return
        if self.execute(['export', '--run', run, '--output', archive], run) != 0:
            with self.guard:
                self.errors[identity] = 'export failed; see recovery log'

    def run(self):
        # Reserve the original 32 slots until their pools exit. This watcher adds no live case slots.
        while controllers(self.root) and not STOP.is_set():
            self.save('waiting_for_original_pools')
            STOP.wait(30)
        if STOP.is_set():
            return
        write(self.root / 'completion-recovery-start.json', {'started_at': time.time(),
            'frozen_session_sha256': sha(self.root / 'session-binding.json'), 'maximum_workers': 8,
            'original_controllers_drained': True, 'memory_admission_limit_mib': 1280})
        with ThreadPoolExecutor(max_workers=8) as pool:
            futures = [pool.submit(self.finish, model, entry) for entry in self.session['episodes']
                       for model in self.session['model_routes']]
            while any(not f.done() for f in futures):
                self.save('recovering')
                STOP.wait(5)
            for future in futures:
                future.result()
        if STOP.is_set():
            self.save('stopped')
            return
        complete = not self.errors and all(len(list((self.root / model / 'exports').glob('*.zip'))) == 50
                                           for model in self.session['model_routes'])
        if complete:
            for model in self.session['model_routes']:
                archive = self.root / (model + '-all50.zip')
                if not archive.exists():
                    temporary = archive.with_suffix('.zip.partial')
                    with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_STORED) as bundle:
                        for trace in sorted((self.root / model / 'exports').glob('*.zip')):
                            bundle.write(trace, 'exports/' + trace.name)
                    os.replace(temporary, archive)
        self.save('behavior_complete' if complete else 'needs_attention')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--credential-socket', required=True)
    args = parser.parse_args()
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
        client.connect(args.credential_socket)
        key = bytearray()
        while len(key) <= 1024:
            chunk = client.recv(1024)
            if not chunk:
                break
            key.extend(chunk)
    if not key or len(key) > 1024:
        raise ValueError('Credential delivery failed')
    os.environ['REDACT_API_KEY'] = key.decode()
    signal.signal(signal.SIGTERM, lambda *_: STOP.set())
    signal.signal(signal.SIGINT, lambda *_: STOP.set())
    root = args.output.resolve()
    with (root / '.completion-watcher.lock').open('a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        write(root / 'completion-binding.json', {'source_sha256': sha(Path(__file__)),
            'frozen_session_sha256': sha(root / 'session-binding.json'), 'started_at': time.time(),
            'native_routes_changed': False, 'history_changed': False,
            'only_recover_after_original_pools_exit': True})
        Finisher(root).run()


if __name__ == '__main__':
    main()
