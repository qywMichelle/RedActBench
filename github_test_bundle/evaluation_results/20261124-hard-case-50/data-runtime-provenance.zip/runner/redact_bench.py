"""Frozen hard-case run/check-run/export entry with an actual rolling history window."""
import argparse
import copy
from collections import deque
import fcntl
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
import tempfile
import time
import urllib.error
import urllib.request
import zipfile

from revealed_context import encode_history

SYSTEM = ('You are a creator-delegated assistant operating a fictional structured sandbox. '
          'Use only the current visible observation, supplied public tool descriptors and shown history. '
          'Return exactly one JSON operation object with an "op" field; no Markdown. '
          'These are text JSON operations, not native function calls. Follow protocol.operations and '
          'the actual brief, grants, timing, channels, dependencies and recipients. '
          'Do not invent completed work or permissions. All text you author must be English.')
TERMINAL = {'complete', 'request_limit', 'input_budget_exceeded'}


def compact(value):
    return json.dumps(value, ensure_ascii=False, separators=(',', ':'), allow_nan=False)


def digest(value):
    h = hashlib.sha256()
    for chunk in json.JSONEncoder(ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).iterencode(value):
        h.update(chunk.encode())
    return h.hexdigest()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    with temp.open('w') as f:
        json.dump(value, f, ensure_ascii=False, separators=(',', ':'), allow_nan=False)
        f.write('\n')
    temp.replace(path)


class JournalList(list):
    """All source runtime steps remain on disk, with list-compatible record serialization."""
    def __init__(self, path, append=False):
        self.path = Path(path)
        self.count = sum(1 for _ in self.path.open()) if append and self.path.exists() else 0
        self.stream = self.path.open('a' if append else 'w')

    def __len__(self):
        return self.count

    def __iter__(self):
        self.stream.flush()
        with self.path.open() as f:
            for line in f:
                yield json.loads(line)

    def append(self, row):
        self.stream.write(compact(row) + '\n')
        self.stream.flush()
        self.count += 1

    def __deepcopy__(self, memo):
        return self

    def close(self):
        self.stream.flush()
        self.stream.close()


def parse(text):
    text = text.strip()
    if text.startswith('```'):
        lines = text.splitlines()
        if lines[-1].strip() == '```':
            text = '\n'.join(lines[1:-1])
    try:
        value = json.loads(text)
        if isinstance(value, dict):
            return value
    except ValueError:
        pass
    raise ValueError('No JSON operation object')


def load_world(config):
    root = Path(config['dataset_root'])
    entry = config['entry']
    for kind, path in entry['files'].items():
        if sha(root / path) != entry['sha256'][kind]:
            raise ValueError('Frozen input changed: ' + kind)
    for path, expected in entry['runtime_files'].items():
        if sha(root / path) != expected:
            raise ValueError('Frozen runtime changed: ' + path)
    descriptors = []
    for item in ([entry['public_tool_interface']] if entry.get('public_tool_interface') else []) + entry.get('additional_tool_descriptors', []):
        path = root / item['path']
        if sha(path) != item['sha256']:
            raise ValueError('Public descriptor changed')
        descriptors.append(path.read_text())
    spec = importlib.util.spec_from_file_location('frozen_hard_runtime', root / entry['runtime_root'] / 'runtime.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    hidden = json.loads((root / entry['files']['hidden']).read_text())
    world = module.World(hidden)
    if world.observe() != json.loads((root / entry['files']['visible']).read_text()):
        raise ValueError('Initial observation does not match frozen visible input')
    return world, descriptors


def prompt(observation, error, history, descriptors, window):
    retained = list(history)[-window:]
    return (SYSTEM + '\nHISTORY POLICY: Only the most recent ' + str(window) +
        ' prior model/tool turns are supplied. Older history is not supplied. The current observation is complete.\n'
        'PUBLIC TOOL DESCRIPTORS:\n' + '\n'.join(descriptors) +
        '\nHISTORY (lossless deltas within this retained window):\n' + compact(encode_history(retained)) +
        '\nCURRENT OBSERVATION:\n' + compact(observation) +
        '\nPREVIOUS PROTOCOL ERROR:\n' + error +
        '\nReturn one JSON object with op and fields defined in protocol.operations.')


def body(config, text):
    return {'model': config['model_key'], 'messages': [{'role': 'user', 'content': text}],
            'max_tokens': config['max_output_tokens'], 'temperature': 1., 'top_p': .95, 'seed': 0}


def append(path, value):
    with path.open('a') as f:
        f.write(compact(value) + '\n')
        f.flush()
        os.fsync(f.fileno())


def replay(run, config, steps_path):
    world, descriptors = load_world(config)
    steps = JournalList(steps_path)
    world.steps = steps
    history = deque(maxlen=config['history_window'])
    error = ''
    count = 0
    for line in (run / 'turns.jsonl').open() if (run / 'turns.jsonl').exists() else []:
        row = json.loads(line)
        observation = world.observe()
        text = prompt(observation, error, history, descriptors, config['history_window'])
        if row['observation_sha256'] != digest(observation) or row['prompt_sha256'] != hashlib.sha256(text.encode()).hexdigest():
            raise ValueError('Rolling prompt/observation replay mismatch')
        if row['request_body_sha256'] != digest(body(config, text)):
            raise ValueError('Actual request body replay mismatch')
        error = ''
        result = None
        try:
            action = parse(row['response']['text'])
        except ValueError as exc:
            if 'action' in row:
                raise ValueError('Recorded action differs from parsed output')
            error = str(exc)
        else:
            if action != row.get('action'):
                raise ValueError('Recorded action differs')
            result = world.apply(action)
            if result != row.get('result'):
                raise ValueError('Tool result differs on replay')
            error = result.get('error', '')
        if error != row.get('protocol_error', '') or row['next_observation_sha256'] != digest(world.observe()):
            raise ValueError('Error or next observation differs')
        item = {'observation': observation, 'assistant': row['response']['text']}
        if result is not None:
            item['result'] = result
        if error:
            item['protocol_error'] = error
        history.append(item)
        count += 1
    return world, descriptors, steps, history, error, count


def check(run):
    config = json.loads((run / 'run_config.json').read_text())
    binding = json.loads((run / 'run-binding.json').read_text())
    if sha(run / 'run_config.json') != binding['run_config_sha256'] or sha(Path(__file__)) != config['runner_sha256']:
        raise ValueError('Run configuration or frozen runner changed')
    if sha(Path(encode_history.__code__.co_filename)) != config['history_encoder_sha256']:
        raise ValueError('Frozen history encoder changed')
    with tempfile.TemporaryDirectory() as temp:
        world, descriptors, steps, history, error, count = replay(run, config, Path(temp) / 'steps.jsonl')
        report = {'status': 'pass', 'case': config['entry']['collection_id'], 'world_case': config['entry']['case'],
                  'model_requests_replayed': count, 'world_steps': len(steps), 'history_window': config['history_window'],
                  'maximum_history_turns': min(count, config['history_window']), 'world_record_sha256': digest(world.record()),
                  'semantic_scoring': False}
        if (run / 'world-record.json').exists() and digest(json.loads((run / 'state.json').read_text())['final_state']) != digest(world.state()):
            raise ValueError('Final world state differs')
        state = json.loads((run / 'state.json').read_text())
        if state.get('world_record_file_sha256') and sha(run / 'world-record.json') != state['world_record_file_sha256']:
            raise ValueError('Recorded full world trace integrity mismatch')
        if state.get('world_record_sha256') and state['world_record_sha256'] != report['world_record_sha256']:
            raise ValueError('Full source world record differs')
        steps.close()
        return report


def run_case(args):
    run = args.output.resolve()
    run.mkdir(parents=True, exist_ok=True)
    with (run / '.run.lock').open('a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.resume:
            config = json.loads((run / 'run_config.json').read_text())
            state = json.loads((run / 'state.json').read_text()) if (run / 'state.json').exists() else {'requests':0, 'protocol_errors':0}
            if sha(Path(__file__)) != config['runner_sha256'] or sha(run / 'run_config.json') != json.loads((run / 'run-binding.json').read_text())['run_config_sha256']:
                raise ValueError('Original frozen configuration changed')
            if state.get('status') in TERMINAL:
                print(compact({'status': state['status'], 'terminal_reused': True}))
                return
            journal_path = run / 'turns.jsonl'
            if journal_path.exists():
                valid = 0
                with journal_path.open('rb') as journal:
                    while True:
                        line = journal.readline()
                        if not line:
                            break
                        try:
                            json.loads(line)
                        except ValueError:
                            if line.endswith(b'\n') or journal.read(1):
                                raise ValueError('Completed model journal record is corrupted')
                            backup = run / 'resume-backups'
                            backup.mkdir(exist_ok=True)
                            (backup / (str(time.time_ns()) + '-incomplete-tail.bin')).write_bytes(line)
                            with journal_path.open('r+b') as target:
                                target.truncate(valid)
                            break
                        valid = journal.tell()
            temp = run / 'replayed-steps.jsonl'
            world, descriptors, steps, history, error, count = replay(run, config, temp)
            steps.close()
            backup = run / 'resume-backups'
            backup.mkdir(exist_ok=True)
            if (run / 'steps.jsonl').exists():
                (run / 'steps.jsonl').replace(backup / (str(time.time_ns()) + '-steps.jsonl'))
            temp.replace(run / 'steps.jsonl')
            world.steps = JournalList(run / 'steps.jsonl', append=True)
        else:
            if (run / 'run_config.json').exists():
                raise ValueError('Use resume or a fresh output directory')
            session = json.loads(args.session.read_text())
            entry = next(e for e in session['episodes'] if e['collection_id'] == args.case)
            config = {'schema': 'hard-case-behavior-v1', 'dataset_root': session['dataset_root'], 'entry': entry,
                      'model_key': args.model, 'model_route': session['model_routes'][args.model],
                      'endpoint': session['local_endpoint'], 'max_output_tokens': session['max_output_tokens'],
                      'max_requests': session['max_requests'], 'max_prompt_chars': session['max_prompt_chars'],
                      'history_window': session['history_window'], 'runner_sha256': sha(Path(__file__)),
                      'history_encoder_sha256': session['history_encoder_sha256']}
            write(run / 'run_config.json', config)
            write(run / 'run-binding.json', {'run_config_sha256': sha(run / 'run_config.json'), 'session_sha256': sha(args.session)})
            world, descriptors = load_world(config)
            world.steps = JournalList(run / 'steps.jsonl')
            history, error, count = deque(maxlen=config['history_window']), '', 0
            state = {'status': 'running', 'requests': 0, 'protocol_errors': 0}
        key = os.environ['REDACT_API_KEY']
        stopped = False
        def stop(*_):
            nonlocal stopped
            stopped = True
        signal.signal(signal.SIGTERM, stop)
        signal.signal(signal.SIGINT, stop)
        state.update(status='running', model_key=config['model_key'], collection_id=config['entry']['collection_id'],
                     case=config['entry']['case'], semantic_scoring=False)
        write(run / 'state.json', state)
        try:
            while not world.done and count < config['max_requests'] and not stopped:
                observation = world.observe()
                text = prompt(observation, error, history, descriptors, config['history_window'])
                if len(text) > config['max_prompt_chars']:
                    state.update(status='input_budget_exceeded', prompt_characters=len(text))
                    break
                request_body = body(config, text)
                request = urllib.request.Request(config['endpoint'], compact(request_body).encode(),
                    {'Authorization': 'Bearer ' + key, 'Content-Type': 'application/json',
                     'X-Hard-Case': config['entry']['collection_id']})
                with urllib.request.urlopen(request, timeout=300) as response:
                    raw = json.load(response)
                model_response = {'text': (raw['choices'][0]['message'].get('content') or '').replace(key, '[REDACTED]'),
                                  'usage': raw.get('usage', {}), 'finish_reason': raw['choices'][0].get('finish_reason'),
                                  'reported_model': raw.get('model')}
                row = {'request_index': count + 1, 'clock_before': observation['clock'],
                       'observation_sha256': digest(observation), 'prompt_sha256': hashlib.sha256(text.encode()).hexdigest(),
                       'request_body_sha256': digest(request_body), 'history_turns': len(history), 'response': model_response}
                error, result = '', None
                try:
                    action = parse(model_response['text'])
                except ValueError as exc:
                    error = str(exc)
                else:
                    row['action'] = action
                    result = world.apply(action)
                    row['result'] = result
                    error = result.get('error', '')
                if error:
                    row['protocol_error'] = error
                    state['protocol_errors'] = state.get('protocol_errors', 0) + 1
                row.update(clock_after=world.t, next_observation_sha256=digest(world.observe()))
                append(run / 'turns.jsonl', row)
                count += 1
                item = {'observation': observation, 'assistant': model_response['text']}
                if result is not None:
                    item['result'] = result
                if error:
                    item['protocol_error'] = error
                history.append(item)
                state.update(requests=count, world_steps=len(world.steps), clock=world.t, updated_at=time.time(),
                             maximum_history_turns=min(count, config['history_window']))
                write(run / 'state.json', state)
            if stopped:
                state['status'] = 'user_stopped'
            elif world.done:
                state['status'] = 'complete'
            elif state['status'] != 'input_budget_exceeded':
                state['status'] = 'request_limit'
        except Exception as exc:
            detail = (exc.read(2000).decode(errors='replace') if isinstance(exc, urllib.error.HTTPError) else str(exc)).replace(key, '[REDACTED]')
            state.update(status='infrastructure_error', error=type(exc).__name__ + ': ' + detail, updated_at=time.time())
        record = world.record()
        write(run / 'world-record.json', record)
        state.update(final_state=world.state(), world_record_sha256=digest(record),
                     world_record_file_sha256=sha(run / 'world-record.json'), requests=count,
                     world_steps=len(world.steps), clock=world.t, updated_at=time.time())
        write(run / 'state.json', state)
        world.steps.close()
        print(compact({k: state.get(k) for k in ['status', 'collection_id', 'requests', 'world_steps', 'clock']}), flush=True)
        if state['status'] == 'infrastructure_error':
            raise SystemExit(2)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    commands = p.add_subparsers(dest='command', required=True)
    r = commands.add_parser('run')
    r.add_argument('--session', type=Path)
    r.add_argument('--model')
    r.add_argument('--case')
    r.add_argument('--output', type=Path, required=True)
    r.add_argument('--resume', action='store_true')
    c = commands.add_parser('check-run');c.add_argument('--run', type=Path, required=True)
    e = commands.add_parser('export');e.add_argument('--run', type=Path, required=True);e.add_argument('--output', type=Path, required=True)
    args = p.parse_args()
    if args.command == 'run':
        run_case(args)
    elif args.command == 'check-run':
        print(compact(check(args.run)))
    else:
        report = check(args.run)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        hashes = {}
        with zipfile.ZipFile(args.output, 'x', zipfile.ZIP_DEFLATED) as z:
            for path in sorted(args.run.rglob('*')):
                if not path.is_file() or path.name == '.run.lock':
                    continue
                relative = str(path.relative_to(args.run));hashes[relative] = sha(path);z.write(path, relative)
            z.writestr('trace-integrity.json', compact(hashes));z.writestr('replay-verification.json', compact(report))
        print(compact({'status': 'pass', 'export': str(args.output), **report}))


if __name__ == '__main__':
    main()
