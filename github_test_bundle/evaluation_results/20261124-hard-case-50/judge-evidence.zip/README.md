本轮按原项目v2评分协议评审四模型各50条、共200条hard case。裁判gpt-6.1-sol-science；全部候选调用和实际交付均保留，候选模型身份与作者参考轨迹不进入评分输入。六维锚点与GCR/TSR/LCR计算沿用原项目。关键边界按冻结rubric原文映射并保留源指针。GPT候选属于同模型自动评审，汇总中单独标记；所有评分尚未经人工确认。
16个case工作者上限，最多8个上游调用；内存准入1280 MiB，每子进程地址空间512 MiB。响应头Retry-After/Ratelimit-Reset优先于错误文本，拒绝请求也保留一分钟预算，避免密集重试。
status.json为进度；summary.json和score-report.md为汇总；各模型目录保留judge-inputs、judgments、raw-responses、case-status和packet-bindings。完整评分结束后生成judge-evidence.zip。
